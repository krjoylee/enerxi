"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Switch } from "@/components/ui/switch"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Checkbox } from "@/components/ui/checkbox"
import { Progress } from "@/components/ui/progress"
import {
  User,
  Heart,
  Activity,
  Shield,
  CheckCircle,
  AlertCircle,
  Calendar,
  Weight,
  Ruler,
  Target,
  ArrowLeft,
} from "lucide-react"
import Link from "next/link"

export default function ProfilePage() {
  const [profileCompletion, setProfileCompletion] = useState(65)
  const [consentGiven, setConsentGiven] = useState(false)
  const [externalSync, setExternalSync] = useState({
    inbody: false,
    healthCheckup: false,
    fitness: false,
  })

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Link href="/">
                <Button variant="ghost" size="sm">
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  돌아가기
                </Button>
              </Link>
              <div className="flex items-center gap-3">
                <div className="flex items-center justify-center w-10 h-10 bg-primary rounded-lg">
                  <User className="w-6 h-6 text-primary-foreground" />
                </div>
                <div>
                  <h1 className="text-xl font-bold text-card-foreground">건강 프로필</h1>
                  <p className="text-sm text-muted-foreground">개인 건강 정보 관리</p>
                </div>
              </div>
            </div>
            <Badge variant="outline" className="text-accent border-accent">
              완성도 {profileCompletion}%
            </Badge>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto space-y-8">
          {/* Profile Completion */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-card-foreground">
                <Target className="w-5 h-5 text-primary" />
                프로필 완성도
              </CardTitle>
              <CardDescription>더 정확한 건강 관리를 위해 프로필을 완성해주세요</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">진행률</span>
                  <span className="font-medium text-foreground">{profileCompletion}%</span>
                </div>
                <Progress value={profileCompletion} className="h-2" />
                <div className="flex flex-wrap gap-2 mt-4">
                  <Badge variant="secondary" className="text-xs">
                    <CheckCircle className="w-3 h-3 mr-1" />
                    기본 정보
                  </Badge>
                  <Badge variant="secondary" className="text-xs">
                    <CheckCircle className="w-3 h-3 mr-1" />
                    신체 정보
                  </Badge>
                  <Badge variant="outline" className="text-xs">
                    <AlertCircle className="w-3 h-3 mr-1" />
                    건강 이력
                  </Badge>
                  <Badge variant="outline" className="text-xs">
                    <AlertCircle className="w-3 h-3 mr-1" />
                    외부 연동
                  </Badge>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Privacy Consent */}
          <Card className="border-accent/20">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-card-foreground">
                <Shield className="w-5 h-5 text-accent" />
                개인정보 동의
              </CardTitle>
              <CardDescription>건강 데이터 수집 및 활용에 대한 동의가 필요합니다</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center space-x-2">
                <Switch id="consent" checked={consentGiven} onCheckedChange={setConsentGiven} />
                <Label htmlFor="consent" className="text-sm">
                  건강 데이터 수집 및 맞춤형 서비스 제공에 동의합니다
                </Label>
              </div>
              {consentGiven && (
                <div className="p-3 bg-accent/10 rounded-lg border border-accent/20">
                  <p className="text-sm text-accent font-medium">동의해주셔서 감사합니다!</p>
                  <p className="text-xs text-muted-foreground mt-1">
                    수집된 데이터는 개인 건강 관리 목적으로만 사용되며, 언제든지 철회할 수 있습니다.
                  </p>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Health Profile Tabs */}
          <Tabs defaultValue="basic" className="w-full">
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="basic">기본 정보</TabsTrigger>
              <TabsTrigger value="physical">신체 정보</TabsTrigger>
              <TabsTrigger value="health">건강 이력</TabsTrigger>
              <TabsTrigger value="sync">외부 연동</TabsTrigger>
            </TabsList>

            {/* Basic Information */}
            <TabsContent value="basic">
              <Card>
                <CardHeader>
                  <CardTitle className="text-card-foreground">기본 정보</CardTitle>
                  <CardDescription>개인 식별 및 기본 건강 정보를 입력하세요</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="grid md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="name">이름</Label>
                      <Input id="name" placeholder="홍길동" className="bg-input" />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="employee-id">사번</Label>
                      <Input id="employee-id" placeholder="EMP001" className="bg-input" disabled />
                    </div>
                  </div>

                  <div className="grid md:grid-cols-3 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="age">나이</Label>
                      <Input id="age" type="number" placeholder="30" className="bg-input" />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="gender">성별</Label>
                      <Select>
                        <SelectTrigger className="bg-input">
                          <SelectValue placeholder="선택하세요" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="male">남성</SelectItem>
                          <SelectItem value="female">여성</SelectItem>
                          <SelectItem value="other">기타</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="department">부서</Label>
                      <Input id="department" placeholder="개발팀" className="bg-input" />
                    </div>
                  </div>

                  <Button className="w-full bg-primary hover:bg-primary/90 text-primary-foreground">
                    기본 정보 저장
                  </Button>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Physical Information */}
            <TabsContent value="physical">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-card-foreground">
                    <Weight className="w-5 h-5 text-primary" />
                    신체 정보
                  </CardTitle>
                  <CardDescription>정확한 영양 권장량 계산을 위한 신체 정보를 입력하세요</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="grid md:grid-cols-2 gap-6">
                    <div className="space-y-4">
                      <div className="space-y-2">
                        <Label htmlFor="height" className="flex items-center gap-2">
                          <Ruler className="w-4 h-4" />키 (cm)
                        </Label>
                        <Input id="height" type="number" placeholder="170" className="bg-input" />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="weight" className="flex items-center gap-2">
                          <Weight className="w-4 h-4" />
                          몸무게 (kg)
                        </Label>
                        <Input id="weight" type="number" placeholder="70" className="bg-input" />
                      </div>
                    </div>

                    <div className="space-y-4">
                      <div className="p-4 bg-muted rounded-lg">
                        <h4 className="font-medium text-foreground mb-2">계산된 BMI</h4>
                        <div className="text-2xl font-bold text-primary">24.2</div>
                        <p className="text-sm text-muted-foreground">정상 범위</p>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="activity-level">활동 수준</Label>
                    <Select>
                      <SelectTrigger className="bg-input">
                        <SelectValue placeholder="일상 활동 수준을 선택하세요" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="sedentary">좌식 생활 (운동 거의 안함)</SelectItem>
                        <SelectItem value="light">가벼운 활동 (주 1-3회 운동)</SelectItem>
                        <SelectItem value="moderate">보통 활동 (주 3-5회 운동)</SelectItem>
                        <SelectItem value="active">활발한 활동 (주 6-7회 운동)</SelectItem>
                        <SelectItem value="very-active">매우 활발 (하루 2회 운동)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <Button className="w-full bg-primary hover:bg-primary/90 text-primary-foreground">
                    신체 정보 저장
                  </Button>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Health History */}
            <TabsContent value="health">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-card-foreground">
                    <Heart className="w-5 h-5 text-accent" />
                    건강 이력
                  </CardTitle>
                  <CardDescription>알레르기, 질병, 식이 제한 등 건강 관련 정보를 입력하세요</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="space-y-4">
                    <div>
                      <Label className="text-base font-medium">알레르기</Label>
                      <p className="text-sm text-muted-foreground mb-3">해당하는 알레르기를 모두 선택하세요</p>
                      <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                        {["견과류", "유제품", "계란", "갑각류", "생선", "콩", "밀", "기타"].map((allergy) => (
                          <div key={allergy} className="flex items-center space-x-2">
                            <Checkbox id={allergy} />
                            <Label htmlFor={allergy} className="text-sm">
                              {allergy}
                            </Label>
                          </div>
                        ))}
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="medical-conditions">기존 질병 (선택사항)</Label>
                      <Textarea
                        id="medical-conditions"
                        placeholder="당뇨병, 고혈압, 심장병 등 기존 질병이 있다면 입력하세요"
                        className="bg-input"
                        rows={3}
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="dietary-restrictions">식이 제한</Label>
                      <Textarea
                        id="dietary-restrictions"
                        placeholder="채식주의, 종교적 제약, 기타 식이 제한사항을 입력하세요"
                        className="bg-input"
                        rows={3}
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="health-goals">건강 목표</Label>
                      <Select>
                        <SelectTrigger className="bg-input">
                          <SelectValue placeholder="주요 건강 목표를 선택하세요" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="maintain">현재 체중 유지</SelectItem>
                          <SelectItem value="lose">체중 감량</SelectItem>
                          <SelectItem value="gain">체중 증가</SelectItem>
                          <SelectItem value="muscle">근육량 증가</SelectItem>
                          <SelectItem value="health">전반적 건강 개선</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <Button className="w-full bg-accent hover:bg-accent/90 text-accent-foreground">건강 이력 저장</Button>
                </CardContent>
              </Card>
            </TabsContent>

            {/* External Sync */}
            <TabsContent value="sync">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-card-foreground">
                    <Link className="w-5 h-5 text-chart-3" />
                    외부 서비스 연동
                  </CardTitle>
                  <CardDescription>
                    외부 건강 서비스와 연동하여 더 정확한 데이터를 자동으로 가져올 수 있습니다
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  {/* InBody Integration */}
                  <div className="flex items-center justify-between p-4 border border-border rounded-lg">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 bg-chart-1/20 rounded-lg flex items-center justify-center">
                        <Activity className="w-5 h-5 text-chart-1" />
                      </div>
                      <div>
                        <h4 className="font-medium text-foreground">InBody 연동</h4>
                        <p className="text-sm text-muted-foreground">체성분 분석 데이터 자동 동기화</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      {externalSync.inbody && (
                        <Badge variant="secondary" className="text-xs">
                          <CheckCircle className="w-3 h-3 mr-1" />
                          연동됨
                        </Badge>
                      )}
                      <Switch
                        checked={externalSync.inbody}
                        onCheckedChange={(checked) => setExternalSync((prev) => ({ ...prev, inbody: checked }))}
                      />
                    </div>
                  </div>

                  {/* Health Checkup Integration */}
                  <div className="flex items-center justify-between p-4 border border-border rounded-lg">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 bg-chart-2/20 rounded-lg flex items-center justify-center">
                        <Calendar className="w-5 h-5 text-chart-2" />
                      </div>
                      <div>
                        <h4 className="font-medium text-foreground">건강검진 연동</h4>
                        <p className="text-sm text-muted-foreground">정기 건강검진 결과 자동 업데이트</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      {externalSync.healthCheckup && (
                        <Badge variant="secondary" className="text-xs">
                          <CheckCircle className="w-3 h-3 mr-1" />
                          연동됨
                        </Badge>
                      )}
                      <Switch
                        checked={externalSync.healthCheckup}
                        onCheckedChange={(checked) => setExternalSync((prev) => ({ ...prev, healthCheckup: checked }))}
                      />
                    </div>
                  </div>

                  {/* Fitness App Integration */}
                  <div className="flex items-center justify-between p-4 border border-border rounded-lg">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 bg-chart-3/20 rounded-lg flex items-center justify-center">
                        <Heart className="w-5 h-5 text-chart-3" />
                      </div>
                      <div>
                        <h4 className="font-medium text-foreground">피트니스 앱 연동</h4>
                        <p className="text-sm text-muted-foreground">운동량 및 칼로리 소모 데이터 연동</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      {externalSync.fitness && (
                        <Badge variant="secondary" className="text-xs">
                          <CheckCircle className="w-3 h-3 mr-1" />
                          연동됨
                        </Badge>
                      )}
                      <Switch
                        checked={externalSync.fitness}
                        onCheckedChange={(checked) => setExternalSync((prev) => ({ ...prev, fitness: checked }))}
                      />
                    </div>
                  </div>

                  <div className="p-4 bg-muted/50 rounded-lg">
                    <h4 className="font-medium text-foreground mb-2">연동 혜택</h4>
                    <ul className="text-sm text-muted-foreground space-y-1">
                      <li>• 수동 입력 없이 자동으로 건강 데이터 업데이트</li>
                      <li>• 더 정확한 개인 맞춤형 영양 권장량 계산</li>
                      <li>• 실시간 건강 상태 모니터링 및 알림</li>
                      <li>• 장기적인 건강 트렌드 분석</li>
                    </ul>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </main>
    </div>
  )
}
