"use client"

import type React from "react"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import Link from "next/link"
import Image from "next/image"
import { useState, useEffect } from "react"

const mockHealthData = {
  height: 175, // cm
  weight: 70, // kg
  gender: "M",
  birthYear: 1990,
  activityLevel: "보통",
  bloodPressure: { systolic: 120, diastolic: 80, lastMeasured: "2024-01-15" },
  bloodSugar: { value: 95, lastMeasured: "2024-01-15" },
  personalizedTargets: {
    dailyCalories: 2050,
    dailySugar: 25,
    dailySodium: 400,
  },
}

const mockWellnessStats = {
  todayIntake: { calories: 1650, sugar: 18, sodium: 320 },
  wellnessScore: "B+",
  wellnessPoints: 1250,
  activeProgram: "금연 관리 프로그램",
  monthlyOverrides: { used: 1, total: 3 },
  favoriteSnacks: [
    { name: "그래놀라바", icon: "🥜" },
    { name: "요거트", icon: "🥛" },
    { name: "사과", icon: "🍎" },
  ],
}

const mockSnackDatabase = [
  {
    id: 1,
    name: "허니버터칩",
    calories: 230,
    sugar: 8,
    sodium: 180,
    image:
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/%ED%97%88%EB%8B%88%EB%B2%84%ED%84%B0%EC%B9%A9.jpg-oeawjMAutLDk8ubgueiilGkHcDxSLZ.jpeg",
  },
  {
    id: 2,
    name: "초코파이",
    calories: 168,
    sugar: 15,
    sodium: 95,
    image:
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/%EC%B4%88%EC%BD%94%ED%8C%8C%EC%9D%B4.jpg-3b5ZXP0YvMwpqa9HBI8D8zH45GAeUC.jpeg",
  },
  {
    id: 3,
    name: "바나나킥",
    calories: 142,
    sugar: 6,
    sodium: 125,
    image:
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/%EB%B0%94%EB%82%98%EB%82%98%ED%82%A5.jpg-JMnDQHw1EsZuIocRbGCUtU6flut0IJ.jpeg",
  },
  {
    id: 4,
    name: "새우깡",
    calories: 155,
    sugar: 2,
    sodium: 220,
    image:
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/%EC%83%88%EC%9A%B0%EA%B9%A1.jpg-ABctZ5GAee5QGCBlYCshJZiBeBD0h7.jpeg",
  },
]

const recommendedDailyValues = {
  calories: 2000,
  sugar: 50,
  sodium: 2300,
}

interface ChatMessage {
  id: string
  content: string
  isUser: boolean
  timestamp: Date
}

const saveUserDataToStorage = (userId, userData) => {
  try {
    const storageKey = `user_data_${userId}`
    // Ensure we save the complete user data with all required fields
    const dataToSave = {
      ...userData,
      id: userId,
      lastUpdated: new Date().toISOString(),
    }
    localStorage.setItem(storageKey, JSON.stringify(dataToSave))
    console.log("[v0] Saved user data to localStorage:", storageKey, dataToSave)
  } catch (error) {
    console.error("[v0] Failed to save to localStorage:", error)
  }
}

const getUserDataFromStorage = (userId) => {
  try {
    const storageKey = `user_data_${userId}`
    const stored = localStorage.getItem(storageKey)
    if (stored) {
      const parsedData = JSON.parse(stored)
      console.log("[v0] Found stored user data for:", storageKey, parsedData)
      return parsedData
    }
    console.log("[v0] No stored data found for:", storageKey)
  } catch (error) {
    console.error("[v0] Failed to load from localStorage:", error)
  }
  return null
}

export default function EmployeeDashboard() {
  const [showScanner, setShowScanner] = useState(false)
  const [showHealthSetup, setShowHealthSetup] = useState(false)
  const [showInBodyLogin, setShowInBodyLogin] = useState(false) // Added InBody login modal state
  const [showGoalModal, setShowGoalModal] = useState(false)
  const [showHistory, setShowHistory] = useState(false)
  const [basket, setBasket] = useState<
    Array<{
      id: number
      name: string
      calories: number
      sugar: number
      sodium: number
      quantity: number
      image: string
    }>
  >([])
  const [showWarning, setShowWarning] = useState(false)
  const [warningType, setWarningType] = useState<string>("")
  const [showFeedback, setShowFeedback] = useState(false)
  const [feedbackText, setFeedbackText] = useState("")
  const [healthData, setHealthData] = useState({
    gender: "male",
    birthYear: 1990,
    activityLevel: "보통",
    bloodPressure: { systolic: 120, diastolic: 80 },
    bloodSugar: { value: 100, status: "정상" },
    inbodyData: {
      bodyFat: 15,
      muscleMass: 35,
      visceralFat: 5,
      bodyWater: 60,
      boneMass: 3.2,
      bmr: 1600,
    },
    personalizedTargets: {
      dailyCalories: 2000,
      dailySugar: 50,
      dailySodium: 2300,
    },
  })
  const [inBodyCredentials, setInBodyCredentials] = useState({
    phone: "",
    password: "",
  })
  const [showChatbot, setShowChatbot] = useState(false)
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([
    {
      id: "1",
      content:
        "안녕하세요! enerXIzer 건강관리 챗봇입니다. 건강에 대해 궁금한 점을 물어보세요. (예: 당, 혈압, 다이어트, 운동) 건의사항이나 기타 문의사항도 언제든 말씀해 주세요.",
      isUser: false,
      timestamp: new Date(),
    },
  ])
  const [chatInput, setChatInput] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [chatScrollRef, setChatScrollRef] = useState<HTMLDivElement | null>(null)
  const [currentUser, setCurrentUser] = useState(null)
  const [isLoadingUser, setIsLoadingUser] = useState(true)
  const [isHealthSetupOpen, setIsHealthSetupOpen] = useState(false)
  const [healthInfo, setHealthInfo] = useState({
    height: "",
    weight: "",
    diabetes: false,
    hypertension: false,
    allergies: "",
  })
  const [userNotFoundError, setUserNotFoundError] = useState(false)

  // BMI 계산 함수
  const calculateBMI = (height: number, weight: number) => {
    if (!height || !weight) return 0
    const heightInM = height / 100
    return (weight / (heightInM * heightInM)).toFixed(1)
  }

  // BMI 상태 판정
  const getBMIStatus = (bmi: number) => {
    if (bmi < 18.5) return { status: "저체중", color: "text-blue-600" }
    if (bmi < 23) return { status: "정상", color: "text-green-600" }
    if (bmi < 25) return { status: "과체중", color: "text-yellow-600" }
    return { status: "비만", color: "text-red-600" }
  }

  // 권장 칼로리 계산 (Harris-Benedict 공식)
  const calculateRecommendedCalories = (
    height: number,
    weight: number,
    age: number,
    gender: string,
    activityLevel: string,
  ) => {
    if (!height || !weight || !age) return 0

    let bmr
    if (gender === "male") {
      bmr = 88.362 + 13.397 * weight + 4.799 * height - 5.677 * age
    } else {
      bmr = 447.593 + 9.247 * weight + 3.098 * height - 4.33 * age
    }

    const activityMultipliers = {
      정적: 1.2,
      가벼운: 1.375,
      보통: 1.55,
      활발한: 1.725,
      매우활발한: 1.9,
    }

    return Math.round(bmr * (activityMultipliers[activityLevel] || 1.55))
  }

  const loadUserData = async (userId: string) => {
    console.log("[v0] Loading user data for userId:", userId)
    setIsLoading(true)
    setIsLoadingUser(true)

    try {
      // First check localStorage
      const storedData = getUserDataFromStorage(userId)
      if (storedData) {
        console.log("[v0] Found stored user data for:", `user_data_${userId}`, storedData)
        console.log("[v0] Using stored user data:", storedData)
        setCurrentUser(storedData)
        setIsLoading(false)
        setIsLoadingUser(false)
        return
      }

      console.log("[v0] No stored data found for:", `user_data_${userId}`)

      const allLocalUsers = []
      for (let i = 1; i <= 10; i++) {
        const localUser = getUserDataFromStorage(i.toString())
        if (localUser) {
          allLocalUsers.push(localUser)
        }
      }

      const response = await fetch(`/api/users?employeeId=${userId}`, {
        headers: {
          "x-local-users": JSON.stringify(allLocalUsers),
        },
      })
      const data = await response.json()

      console.log("[v0] API response data:", JSON.stringify(data).substring(0, 200) + "...")

      if (data.users && data.users.length > 0) {
        const user = data.users.find((u: any) => u.id === userId)
        console.log("[v0] Found user:", user ? user.name : "undefined")

        if (user) {
          setCurrentUser(user)
          setUserNotFoundError(false)
        } else {
          setCurrentUser(null)
          setUserNotFoundError(true)
        }
      } else {
        console.log("[v0] User not found, showing error message")
        setCurrentUser(null)
        setUserNotFoundError(true)
      }
    } catch (error) {
      console.error("[v0] Failed to load user data:", error)
      setCurrentUser(null)
      setUserNotFoundError(true)
    } finally {
      setIsLoading(false)
      setIsLoadingUser(false)
    }
  }

  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search)
    const userId = urlParams.get("userId") || "1"
    console.log("[v0] URL userId parameter:", userId)
    loadUserData(userId)
  }, [])

  useEffect(() => {
    if (chatScrollRef) {
      chatScrollRef.scrollTop = chatScrollRef.scrollHeight
    }
  }, [chatMessages, chatScrollRef])

  const calculatePersonalizedTargets = (userData) => {
    const age = new Date().getFullYear() - (userData.birthYear || 1990)
    const height = userData.height || 170
    const weight = userData.weight || 70
    const gender = userData.gender || "male"
    const activityLevel = userData.activityLevel || "보통"

    // Harris-Benedict equation for BMR
    let bmr
    if (gender === "male") {
      bmr = 88.362 + 13.397 * weight + 4.799 * height - 5.677 * age
    } else {
      bmr = 447.593 + 9.247 * weight + 3.098 * height - 4.33 * age
    }

    // Activity multiplier
    const activityMultipliers = {
      낮음: 1.2,
      보통: 1.55,
      높음: 1.725,
      "매우 높음": 1.9,
    }

    const dailyCalories = Math.round(bmr * (activityMultipliers[activityLevel] || 1.55))
    const dailySugar = Math.round((dailyCalories * 0.1) / 4) // 10% of calories from sugar
    const dailySodium = 2300 // WHO recommendation

    return {
      dailyCalories,
      dailySugar,
      dailySodium,
    }
  }

  useEffect(() => {
    if (currentUser) {
      setHealthInfo({
        height: currentUser.height ? String(currentUser.height) : "",
        weight: currentUser.weight ? String(currentUser.weight) : "",
        diabetes: currentUser.diabetes || false,
        hypertension: currentUser.hypertension || false,
        allergies: Array.isArray(currentUser.allergies) ? currentUser.allergies.join(", ") : "",
      })

      setHealthData({
        ...healthData,
        height: currentUser.height || 175,
        weight: currentUser.weight || 70,
        age: currentUser.age || 30,
        gender: currentUser.gender || "male",
        birthYear: currentUser.birthYear || 1990,
        activityLevel: currentUser.activityLevel || "moderate",
        bloodPressure: {
          systolic: currentUser.bloodPressure?.systolic || 120,
          diastolic: currentUser.bloodPressure?.diastolic || 80,
        },
        bloodSugar: {
          value: currentUser.bloodSugar?.value || 100,
        },
        diabetes: currentUser.diabetes || false,
        hypertension: currentUser.hypertension || false,
        allergies: Array.isArray(currentUser.allergies) ? currentUser.allergies : [],
        personalizedTargets: calculatePersonalizedTargets(currentUser),
      })
    }
  }, [currentUser])

  const generateHealthResponse = (inputText: string): string | null => {
    const lowerInput = inputText.toLowerCase()

    if (
      lowerInput.includes("당") ||
      lowerInput.includes("당뇨") ||
      lowerInput.includes("설탕") ||
      lowerInput.includes("혈당")
    ) {
      return "당 수치가 걱정되시는군요. 전반적인 건강을 위해 설탕과 정제 탄수화물 섭취를 줄이는 것이 좋습니다. 간식을 선택할 때도 당분이 적은 견과류나 과일을 추천드립니다."
    } else if (
      lowerInput.includes("혈압") ||
      lowerInput.includes("고혈압") ||
      lowerInput.includes("나트륨") ||
      lowerInput.includes("소금")
    ) {
      return "고혈압이 걱정되시는군요. 나트륨(소금) 섭취를 줄이고, 칼륨이 풍부한 채소와 과일을 드시는 것을 추천합니다. 간식도 저염 제품을 선택해 보세요."
    } else if (
      lowerInput.includes("다이어트") ||
      lowerInput.includes("체중") ||
      lowerInput.includes("살") ||
      lowerInput.includes("비만")
    ) {
      return "체중 관리에 관심이 있으시군요. 균형 잡힌 식단과 적절한 운동이 중요합니다. 간식은 칼로리가 낮고 영양가 높은 것을 선택하시고, 하루 섭취량을 기록해 보세요."
    } else if (lowerInput.includes("콜레스테롤") || lowerInput.includes("지방")) {
      return "콜레스테롤 관리가 필요하시군요. 포화지방과 트랜스지방이 적은 식품을 선택하시고, 견과류나 올리브오일 같은 건강한 지방을 섭취하세요."
    } else if (lowerInput.includes("운동") || lowerInput.includes("활동")) {
      return "규칙적인 운동은 건강 관리의 핵심입니다. 주 3-4회, 30분 이상의 유산소 운동을 추천드리며, 간식 섭취 후에는 가벼운 산책도 도움이 됩니다."
    } else if (lowerInput.includes("안녕") || lowerInput.includes("반가")) {
      return "안녕하세요! 반갑습니다. enerXIzer 건강관리 챗봇입니다. 건강과 관련된 궁금한 점이나 간식 관련 문의사항이 있으시면 언제든 말씀해 주세요."
    }

    return null
  }

  const sendMessageToMISO = async (message: string) => {
    try {
      const healthResponse = generateHealthResponse(message)

      if (healthResponse) {
        let currentResponse = ""
        const words = healthResponse.split(" ")

        for (let i = 0; i < words.length; i++) {
          currentResponse += (i > 0 ? " " : "") + words[i]
          setChatMessages((prev) => {
            const newMessages = [...prev]
            const lastMessage = newMessages[newMessages.length - 1]
            if (lastMessage && !lastMessage.isUser) {
              lastMessage.content = currentResponse
            }
            return newMessages
          })
          await new Promise((resolve) => setTimeout(resolve, 50))
        }

        return healthResponse
      }

      const response = await fetch("/api/chat", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          message: message,
          user: currentUser?.employeeId || "EMP001",
        }),
      })

      if (!response.ok) {
        throw new Error("API 호출에 실패했습니다.")
      }

      const reader = response.body?.getReader()
      if (!reader) {
        throw new Error("스트림을 읽을 수 없습니다.")
      }

      let botResponse = ""
      const decoder = new TextDecoder()

      while (true) {
        const { done, value } = await reader.read()
        if (done) break

        const chunk = decoder.decode(value)
        const lines = chunk.split("\n")

        for (const line of lines) {
          if (line.startsWith("data: ")) {
            try {
              const data = JSON.parse(line.slice(6))
              if (data.event === "message" && data.answer) {
                botResponse += data.answer
                setChatMessages((prev) => {
                  const newMessages = [...prev]
                  const lastMessage = newMessages[newMessages.length - 1]
                  if (lastMessage && !lastMessage.isUser) {
                    lastMessage.content = botResponse
                  }
                  return newMessages
                })
              }
            } catch (e) {}
          }
        }
      }

      return botResponse
    } catch (error) {
      console.error("MISO API 오류:", error)
      const fallbackResponse =
        "죄송합니다. 일시적인 오류가 발생했습니다. 건강 관련 질문이시라면 '당', '혈압', '다이어트' 등의 키워드로 다시 질문해 주세요."

      setChatMessages((prev) => {
        const newMessages = [...prev]
        const lastMessage = newMessages[newMessages.length - 1]
        if (lastMessage && !lastMessage.isUser) {
          lastMessage.content = fallbackResponse
        }
        return newMessages
      })

      return fallbackResponse
    }
  }

  const handleSendMessage = async () => {
    if (!chatInput.trim() || isLoading) return

    const userMessage: ChatMessage = {
      id: Date.now().toString(),
      content: chatInput.trim(),
      isUser: true,
      timestamp: new Date(),
    }

    setChatMessages((prev) => [...prev, userMessage])
    setChatInput("")
    setIsLoading(true)

    const botMessage: ChatMessage = {
      id: (Date.now() + 1).toString(),
      content: "",
      isUser: false,
      timestamp: new Date(),
    }
    setChatMessages((prev) => [...prev, botMessage])

    await sendMessageToMISO(userMessage.content)
    setIsLoading(false)
  }

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault()
      handleSendMessage()
    }
  }

  const basketTotals = basket.reduce(
    (acc, item) => ({
      calories: acc.calories + item.calories * item.quantity,
      sugar: acc.sugar + item.sugar * item.quantity,
      sodium: acc.sodium + item.sodium * item.quantity,
    }),
    { calories: 0, sugar: 0, sodium: 0 },
  )

  const remainingOverrides = mockWellnessStats.monthlyOverrides.total - mockWellnessStats.monthlyOverrides.used

  const addToBasket = (snack: (typeof mockSnackDatabase)[0]) => {
    const existingItem = basket.find((item) => item.id === snack.id)
    if (existingItem) {
      setBasket(basket.map((item) => (item.id === snack.id ? { ...item, quantity: item.quantity + 1 } : item)))
    } else {
      setBasket([...basket, { ...snack, quantity: 1 }])
    }
  }

  const updateQuantity = (id: number, change: number) => {
    setBasket(
      basket
        .map((item) => {
          if (item.id === id) {
            const newQuantity = Math.max(0, item.quantity + change)
            return newQuantity === 0 ? null : { ...item, quantity: newQuantity }
          }
          return item
        })
        .filter(Boolean) as typeof basket,
    )
  }

  const checkNutritionLimits = () => {
    const exceeded = []
    const targets = healthData.personalizedTargets || { dailyCalories: 2000, dailySugar: 50, dailySodium: 2300 }

    if (basketTotals.calories > targets.dailyCalories) exceeded.push("칼로리")
    if (basketTotals.sugar > targets.dailySugar) exceeded.push("당")
    if (basketTotals.sodium > targets.dailySodium) exceeded.push("나트륨")

    if (exceeded.length > 0) {
      setWarningType(exceeded.join(", "))
      setShowWarning(true)
    } else {
      processOrder()
    }
  }

  const processOrder = () => {
    setBasket([])
    setShowScanner(false)
    setShowWarning(false)
  }

  const useOverride = () => {
    if (remainingOverrides > 0) {
      processOrder()
    }
  }

  const handleHealthInfoSave = async (healthData) => {
    try {
      const urlParams = new URLSearchParams(window.location.search)
      const userId = urlParams.get("userId") || "1"

      console.log("[v0] Saving health info:", healthData)

      const height = Number.parseFloat(healthData.height)
      const weight = Number.parseFloat(healthData.weight)
      const bmi = weight / (height / 100) ** 2

      let bmiCategory = "정상"
      if (bmi < 18.5) bmiCategory = "저체중"
      else if (bmi >= 25) bmiCategory = "과체중"
      else if (bmi >= 30) bmiCategory = "비만"

      const updatedUserData = {
        ...currentUser,
        age: Number.parseInt(healthData.age),
        height,
        weight,
        bmi: Math.round(bmi * 100) / 100,
        bmiCategory,
        diabetes: healthData.diabetes,
        hypertension: healthData.hypertension,
        allergies: healthData.allergies || [],
        gender: healthData.gender,
        birthYear: healthData.birthYear,
        activityLevel: healthData.activityLevel,
        bloodPressure: healthData.bloodPressure,
        bloodSugar: healthData.bloodSugar,
      }

      saveUserDataToStorage(userId, updatedUserData)
      setCurrentUser(updatedUserData)

      console.log("[v0] Health info saved successfully")
      setShowHealthSetup(false)

      try {
        const response = await fetch(`/api/users`, {
          method: "PUT",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            id: userId,
            ...healthData,
          }),
        })

        if (response.ok) {
          console.log("[v0] Server save successful")
        } else {
          console.log("[v0] Server save failed, but localStorage saved")
        }
      } catch (serverError) {
        console.log("[v0] Server save error, but localStorage saved:", serverError)
      }
    } catch (error) {
      console.error("[v0] Failed to save health info:", error)
    }
  }

  if (userNotFoundError) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center p-4">
        <div className="bg-white rounded-2xl shadow-xl p-8 max-w-md w-full text-center">
          <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <svg className="w-8 h-8 text-red-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.964-.833-2.732 0L3.732 16.5c-.77.833.192 2.5 1.732 2.5z"
              />
            </svg>
          </div>
          <h2 className="text-xl font-bold text-gray-900 mb-2">사용자를 찾을 수 없습니다</h2>
          <p className="text-gray-600 mb-6">
            입력하신 사번에 해당하는 사용자가 존재하지 않습니다. 다른 사번을 입력해 주세요.
          </p>
          <button
            onClick={() => (window.location.href = "/")}
            className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2 rounded-lg transition-colors"
          >
            로그인 페이지로 돌아가기
          </button>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#F8FAFC] to-[#F1F5F9]">
      <header className="bg-white/80 backdrop-blur-md border-b border-[#E2E8F0] shadow-sm sticky top-0 z-10">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <Image src="/images/enerxizer-logo.png" alt="enerXIzer" width={180} height={40} className="h-10 w-auto" />
            </div>
            <div className="flex items-center gap-3">
              <Badge className="bg-[#0A1F44] text-white border-0 px-3 py-1 text-sm font-medium">직원 모드</Badge>
              <Link href="/">
                <Button className="bg-white border border-[#CBD5E1] text-[#475569] hover:bg-[#F8FAFC] hover:border-[#94A3B8] transition-all duration-200 shadow-sm">
                  🚪 로그아웃
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        <div className="max-w-7xl mx-auto">
          <Card className="bg-white/90 backdrop-blur-sm border border-[#E2E8F0] shadow-xl rounded-3xl mb-8 overflow-hidden">
            <CardContent className="p-8">
              <div className="flex flex-col lg:flex-row items-start gap-8">
                <div className="flex-shrink-0">
                  {isLoadingUser ? (
                    <div className="flex items-center justify-center p-8">
                      <div className="animate-spin rounded-full h-12 w-12 border-4 border-[#0A1F44] border-t-transparent"></div>
                    </div>
                  ) : (
                    currentUser && (
                      <div className="relative">
                        <Image
                          src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-yNEEDttMegxicSCSlGnVvsOc5iXJtY.png"
                          alt="Profile"
                          width={140}
                          height={140}
                          className="rounded-full border-4 border-white shadow-2xl ring-4 ring-[#E2E8F0]"
                        />
                        <div className="absolute -bottom-2 -right-2 w-8 h-8 bg-[#10B981] rounded-full border-4 border-white flex items-center justify-center">
                          <span className="text-white text-xs">✓</span>
                        </div>
                      </div>
                    )
                  )}
                </div>

                <div className="flex-1 space-y-6">
                  {isLoadingUser ? (
                    <div className="flex items-center justify-center p-8">
                      <div className="animate-spin rounded-full h-12 w-12 border-4 border-[#0A1F44] border-t-transparent"></div>
                    </div>
                  ) : (
                    currentUser && (
                      <div className="space-y-2">
                        <h1 className="text-3xl font-bold text-[#0F172A] tracking-tight">{currentUser.name}</h1>
                        <p className="text-[#64748B] text-lg font-medium">
                          {currentUser.employeeId} • {currentUser.team}
                        </p>
                      </div>
                    )
                  )}

                  <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                    <div className="bg-gradient-to-br from-white to-[#F8FAFC] p-5 rounded-2xl border border-[#E2E8F0] shadow-lg hover:shadow-xl transition-all duration-300">
                      <div className="flex items-center justify-between mb-3">
                        <p className="text-sm text-[#64748B] font-semibold">일일 칼로리</p>
                        <span className="text-2xl">🔥</span>
                      </div>
                      <p className="text-2xl font-bold text-[#0F172A] mb-2">
                        {mockWellnessStats.todayIntake.calories}
                        <span className="text-lg text-[#64748B] font-normal">
                          /{healthData.personalizedTargets?.dailyCalories || 2000}
                        </span>
                      </p>
                      <Progress
                        value={
                          (mockWellnessStats.todayIntake.calories /
                            (healthData.personalizedTargets?.dailyCalories || 2000)) *
                          100
                        }
                        className="h-2 bg-[#F1F5F9]"
                      />
                    </div>

                    <div className="bg-gradient-to-br from-white to-[#F0FDF4] p-5 rounded-2xl border border-[#E2E8F0] shadow-lg hover:shadow-xl transition-all duration-300">
                      <div className="flex items-center justify-between mb-3">
                        <p className="text-sm text-[#64748B] font-semibold">웰니스 점수</p>
                        <span className="text-2xl">⭐</span>
                      </div>
                      <p className="text-2xl font-bold text-[#0F172A] mb-1">{mockWellnessStats.wellnessScore}</p>
                      <p className="text-sm text-[#10B981] font-semibold">{mockWellnessStats.wellnessPoints}점</p>
                    </div>

                    <div className="bg-gradient-to-br from-white to-[#FEF7FF] p-5 rounded-2xl border border-[#E2E8F0] shadow-lg hover:shadow-xl transition-all duration-300">
                      <div className="flex items-center justify-between mb-3">
                        <p className="text-sm text-[#64748B] font-semibold">월 예외권</p>
                        <span className="text-2xl">🎫</span>
                      </div>
                      <p className="text-2xl font-bold text-[#0F172A]">
                        {remainingOverrides}
                        <span className="text-lg text-[#64748B] font-normal">/3</span>
                      </p>
                    </div>

                    <div className="bg-gradient-to-br from-white to-[#F0F9FF] p-5 rounded-2xl border border-[#E2E8F0] shadow-lg hover:shadow-xl transition-all duration-300">
                      <div className="flex items-center justify-between mb-3">
                        <p className="text-sm text-[#64748B] font-semibold">활성 프로그램</p>
                        <span className="text-2xl">💪</span>
                      </div>
                      <p className="text-sm font-semibold text-[#0F172A] leading-tight">
                        {mockWellnessStats.activeProgram}
                      </p>
                    </div>
                  </div>
                </div>

                <div className="flex-shrink-0">
                  <Button
                    onClick={() => setShowHealthSetup(true)}
                    className="bg-gradient-to-r from-[#0A1F44] to-[#1E3A8A] text-white hover:from-[#1E3A8A] hover:to-[#3B82F6] transition-all duration-300 shadow-lg hover:shadow-xl px-6 py-3 text-base font-semibold rounded-xl"
                  >
                    신체정보 입력
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>

          <div className="grid md:grid-cols-3 gap-6 mb-10">
            <Card
              className="group bg-white/90 backdrop-blur-sm border border-[#E2E8F0] shadow-xl rounded-3xl hover:shadow-2xl hover:scale-[1.02] transition-all duration-300 cursor-pointer overflow-hidden"
              onClick={() => setShowScanner(true)}
            >
              <CardHeader className="text-center bg-gradient-to-br from-[#0A1F44] to-[#1E3A8A] text-white rounded-t-3xl p-8">
                <div className="w-20 h-20 bg-white/20 backdrop-blur-sm rounded-2xl flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform duration-300">
                  <span className="text-3xl">📱</span>
                </div>
                <CardTitle className="text-2xl text-white font-bold mb-2">간식 스캔하기</CardTitle>
                <CardDescription className="text-white/90 text-base">
                  바코드를 스캔하여 간식을 선택하세요
                </CardDescription>
              </CardHeader>
            </Card>

            <Link href="/diary">
              <Card className="group bg-white/90 backdrop-blur-sm border border-[#E2E8F0] shadow-xl rounded-3xl hover:shadow-2xl hover:scale-[1.02] transition-all duration-300 cursor-pointer overflow-hidden">
                <CardHeader className="text-center bg-gradient-to-br from-[#0A1F44] to-[#1E3A8A] text-white rounded-t-3xl p-8">
                  <div className="w-20 h-20 bg-white/20 backdrop-blur-sm rounded-2xl flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform duration-300">
                    <span className="text-3xl">📊</span>
                  </div>
                  <CardTitle className="text-2xl text-white font-bold mb-2">간식 다이어리</CardTitle>
                  <CardDescription className="text-white/90 text-base">
                    월별 간식 섭취 현황을 확인하세요
                  </CardDescription>
                </CardHeader>
              </Card>
            </Link>

            <Link href="/wellness">
              <Card className="group bg-white/90 backdrop-blur-sm border border-[#E2E8F0] shadow-xl rounded-3xl hover:shadow-2xl hover:scale-[1.02] transition-all duration-300 cursor-pointer overflow-hidden">
                <CardHeader className="text-center bg-gradient-to-br from-[#0A1F44] to-[#1E3A8A] text-white rounded-t-3xl p-8">
                  <div className="w-20 h-20 bg-white/20 backdrop-blur-sm rounded-2xl flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform duration-300">
                    <span className="text-3xl">💪</span>
                  </div>
                  <CardTitle className="text-2xl text-white font-bold mb-2">웰니스 프로그램</CardTitle>
                  <CardDescription className="text-white/90 text-base">건강 증진 프로그램에 참여하세요</CardDescription>
                </CardHeader>
              </Card>
            </Link>
          </div>

          <div className="grid md:grid-cols-2 gap-6 mb-8">
            <Card className="bg-white/90 backdrop-blur-sm border border-[#E2E8F0] shadow-xl rounded-3xl hover:shadow-2xl transition-all duration-300">
              <CardHeader className="pb-6">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-gradient-to-br from-[#F59E0B] to-[#D97706] rounded-2xl flex items-center justify-center shadow-lg">
                    <span className="text-white text-xl">💡</span>
                  </div>
                  <CardTitle className="text-xl font-bold text-[#0F172A]">개인 웰니스 팁</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <div className="bg-gradient-to-br from-[#FEF3C7] to-[#FDE68A] p-6 rounded-2xl border border-[#F3E8FF] shadow-inner">
                  <p className="text-[#92400E] leading-relaxed font-medium mb-3">
                    오늘 나트륨 섭취량이 목표의 80%입니다. 저녁은 싱겁게 드시는 걸 추천해요. 🧂
                  </p>
                  <div className="flex items-center gap-2">
                    <div className="w-6 h-6 bg-[#10B981] rounded-full flex items-center justify-center">
                      <span className="text-white text-xs">AI</span>
                    </div>
                    <p className="text-sm text-[#10B981] font-semibold">AI 건강 어시스턴트</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-white/90 backdrop-blur-sm border border-[#E2E8F0] shadow-xl rounded-3xl hover:shadow-2xl transition-all duration-300">
              <CardHeader className="pb-6">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 bg-gradient-to-br from-[#10B981] to-[#059669] rounded-2xl flex items-center justify-center shadow-lg">
                      <span className="text-white text-xl">🍎</span>
                    </div>
                    <CardTitle className="text-xl font-bold text-[#0F172A]">최근 간식 섭취</CardTitle>
                  </div>
                  <Link
                    href="/diary"
                    className="text-sm text-[#10B981] hover:text-[#059669] font-semibold transition-colors px-3 py-1 rounded-lg hover:bg-[#F0FDF4]"
                  >
                    더 보기 →
                  </Link>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {[
                    { name: "허니버터칩", calories: 230, time: "14:30" },
                    { name: "초코파이", calories: 168, time: "11:15" },
                    { name: "바나나킥", calories: 142, time: "09:45" },
                  ].map((snack, index) => (
                    <div
                      key={index}
                      className="flex items-center gap-4 p-4 rounded-2xl hover:bg-gradient-to-r hover:from-[#F8FAFC] hover:to-[#F1F5F9] transition-all duration-200 border border-transparent hover:border-[#E2E8F0]"
                    >
                      <div className="w-12 h-12 bg-gradient-to-br from-[#8B5CF6] to-[#7C3AED] rounded-xl flex items-center justify-center shadow-lg">
                        <span className="text-white text-lg">🍪</span>
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="font-semibold text-[#0F172A] truncate">{snack.name}</p>
                        <p className="text-sm text-[#64748B]">{snack.calories}kcal</p>
                      </div>
                      <span className="text-sm text-[#64748B] font-semibold bg-[#F8FAFC] px-3 py-1 rounded-lg">
                        {snack.time}
                      </span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card className="bg-white/90 backdrop-blur-sm border border-[#E2E8F0] shadow-xl rounded-3xl hover:shadow-2xl transition-all duration-300">
              <CardHeader className="pb-6">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-gradient-to-br from-[#8B5CF6] to-[#7C3AED] rounded-2xl flex items-center justify-center shadow-lg">
                    <span className="text-white text-xl">🏅</span>
                  </div>
                  <CardTitle className="text-xl font-bold text-[#0F172A]">리워드 현황</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  <div className="flex items-center justify-between p-4 bg-gradient-to-r from-[#F8FAFC] to-[#F1F5F9] rounded-2xl">
                    <span className="text-[#64748B] font-semibold">웰니스 점수</span>
                    <span className="font-bold text-2xl text-[#0F172A]">{mockWellnessStats.wellnessPoints}점</span>
                  </div>
                  <div className="flex items-center justify-between p-4 bg-gradient-to-r from-[#F0FDF4] to-[#DCFCE7] rounded-2xl">
                    <span className="text-[#64748B] font-semibold">등급</span>
                    <Badge className="bg-gradient-to-r from-[#10B981] to-[#059669] text-white border-0 px-4 py-2 text-base font-bold shadow-lg">
                      {mockWellnessStats.wellnessScore}
                    </Badge>
                  </div>
                  <div className="bg-gradient-to-br from-[#FEF7FF] to-[#F3E8FF] p-5 rounded-2xl border border-[#E9D5FF]">
                    <p className="text-[#7C3AED] font-bold mb-4">획득 배지</p>
                    <div className="flex gap-3">
                      <div className="flex items-center gap-2 bg-white px-4 py-2 rounded-xl border border-[#E2E8F0] shadow-sm hover:shadow-md transition-shadow">
                        <span className="text-lg">🚶</span>
                        <span className="text-sm font-semibold text-[#0F172A]">걷기 챌린지</span>
                      </div>
                      <div className="flex items-center gap-2 bg-white px-4 py-2 rounded-xl border border-[#E2E8F0] shadow-sm hover:shadow-md transition-shadow">
                        <span className="text-lg">🥗</span>
                        <span className="text-sm font-semibold text-[#0F172A]">건강 식단</span>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-white/90 backdrop-blur-sm border border-[#E2E8F0] shadow-xl rounded-3xl hover:shadow-2xl transition-all duration-300">
              <CardHeader className="pb-6">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-gradient-to-br from-[#EF4444] to-[#DC2626] rounded-2xl flex items-center justify-center shadow-lg">
                    <span className="text-white text-xl">📢</span>
                  </div>
                  <CardTitle className="text-xl font-bold text-[#0F172A]">공지사항</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {[
                    {
                      title: "이번 주: 혈압 관리 캠페인",
                      date: "2024.01.15",
                      type: "캠페인",
                      color: "from-[#EF4444] to-[#DC2626]",
                    },
                    {
                      title: "사내 걷기 대회 신청하세요",
                      date: "2024.01.12",
                      type: "이벤트",
                      color: "from-[#10B981] to-[#059669]",
                    },
                    {
                      title: "건강검진 일정 안내",
                      date: "2024.01.10",
                      type: "안내",
                      color: "from-[#0A1F44] to-[#1E3A8A]",
                    },
                  ].map((notice, index) => (
                    <div
                      key={index}
                      className="p-4 rounded-2xl border border-[#E2E8F0] hover:shadow-lg transition-all duration-200 cursor-pointer bg-gradient-to-r from-white to-[#F8FAFC]"
                    >
                      <div className="flex items-start justify-between gap-3">
                        <div className="flex-1">
                          <p className="font-semibold text-[#0F172A] mb-2 leading-tight">{notice.title}</p>
                          <p className="text-sm text-[#64748B]">{notice.date}</p>
                        </div>
                        <Badge
                          className={`bg-gradient-to-r ${notice.color} text-white border-0 px-3 py-1 text-xs font-semibold shadow-lg`}
                        >
                          {notice.type}
                        </Badge>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <div className="fixed bottom-6 right-6 z-40">
        <Button
          onClick={() => setShowChatbot(true)}
          className="w-16 h-16 rounded-full bg-gradient-to-r from-[#0A1F44] to-[#10B981] hover:from-[#0A1F44]/90 hover:to-[#10B981]/90 text-white shadow-2xl hover:shadow-3xl transition-all duration-300 hover:scale-110"
        >
          <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8" viewBox="0 0 20 20" fill="currentColor">
            <path
              fillRule="evenodd"
              d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z"
              clipRule="evenodd"
            />
          </svg>
        </Button>
      </div>

      {showScanner && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-3xl shadow-2xl max-w-4xl w-full max-h-[90vh] overflow-hidden">
            <div className="bg-gradient-to-r from-[#0A1F44] to-[#1E3A8A] text-white p-6">
              <div className="flex items-center justify-between">
                <h2 className="text-2xl font-bold">간식 스캔하기</h2>
                <Button
                  onClick={() => setShowScanner(false)}
                  className="bg-white/20 hover:bg-white/30 text-white border-0 rounded-xl"
                >
                  ✕
                </Button>
              </div>
            </div>

            <div className="p-6 max-h-[70vh] overflow-y-auto">
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <h3 className="text-lg font-bold text-[#0F172A] mb-4">간식 선택</h3>

                  <div className="grid grid-cols-2 gap-4">
                    {mockSnackDatabase.map((snack) => (
                      <div
                        key={snack.id}
                        className="bg-gradient-to-br from-white to-[#F8FAFC] border border-[#E2E8F0] rounded-2xl p-4 hover:shadow-lg transition-all duration-200 cursor-pointer"
                        onClick={() => addToBasket(snack)}
                      >
                        <div className="w-full h-24 bg-[#F1F5F9] rounded-xl mb-3 flex items-center justify-center overflow-hidden">
                          <img
                            src={snack.image || "/placeholder.svg"}
                            alt={snack.name}
                            className="w-full h-full object-cover rounded-xl"
                          />
                        </div>
                        <h4 className="font-semibold text-[#0F172A] mb-2">{snack.name}</h4>
                        <div className="space-y-1 text-sm text-[#64748B]">
                          <p>{snack.calories}kcal</p>
                          <p>당 {snack.sugar}g</p>
                          <p>나트륨 {snack.sodium}mg</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                <div>
                  <h3 className="text-lg font-bold text-[#0F172A] mb-4">선택한 간식</h3>
                  {basket.length === 0 ? (
                    <div className="bg-[#F8FAFC] border-2 border-dashed border-[#CBD5E1] rounded-2xl p-8 text-center">
                      <p className="text-[#64748B]">간식을 선택해주세요</p>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {basket.map((item) => (
                        <div key={item.id} className="bg-white border border-[#E2E8F0] rounded-2xl p-4 shadow-sm">
                          <div className="flex items-center justify-between">
                            <div>
                              <h4 className="font-semibold text-[#0F172A]">{item.name}</h4>
                              <p className="text-sm text-[#64748B]">{item.calories * item.quantity}kcal</p>
                            </div>
                            <div className="flex items-center gap-2">
                              <Button
                                onClick={() => updateQuantity(item.id, -1)}
                                className="w-8 h-8 p-0 bg-[#F1F5F9] hover:bg-[#E2E8F0] text-[#64748B] border-0 rounded-lg"
                              >
                                -
                              </Button>
                              <span className="w-8 text-center font-semibold">{item.quantity}</span>
                              <Button
                                onClick={() => updateQuantity(item.id, 1)}
                                className="w-8 h-8 p-0 bg-[#F1F5F9] hover:bg-[#E2E8F0] text-[#64748B] border-0 rounded-lg"
                              >
                                +
                              </Button>
                            </div>
                          </div>
                        </div>
                      ))}

                      <div className="bg-gradient-to-br from-[#F0FDF4] to-[#DCFCE7] border border-[#BBF7D0] rounded-2xl p-4">
                        <h4 className="font-bold text-[#0F172A] mb-3">영양 정보 합계</h4>
                        <div className="space-y-3">
                          <div className="flex justify-between items-center">
                            <span className="text-sm text-[#64748B]">칼로리</span>
                            <div className="text-right">
                              <span
                                className={`font-bold ${basketTotals.calories > recommendedDailyValues.calories ? "text-red-600" : "text-[#0F172A]"}`}
                              >
                                {basketTotals.calories}kcal
                              </span>
                              <span
                                className={`text-xs ml-2 ${basketTotals.calories > recommendedDailyValues.calories ? "text-red-500" : "text-[#64748B]"}`}
                              >
                                / {recommendedDailyValues.calories}kcal (
                                {Math.round((basketTotals.calories / recommendedDailyValues.calories) * 100)}%)
                              </span>
                            </div>
                          </div>
                          <div className="flex justify-between items-center">
                            <span className="text-sm text-[#64748B]">당</span>
                            <div className="text-right">
                              <span
                                className={`font-bold ${basketTotals.sugar > recommendedDailyValues.sugar ? "text-red-600" : "text-[#0F172A]"}`}
                              >
                                {basketTotals.sugar}g
                              </span>
                              <span
                                className={`text-xs ml-2 ${basketTotals.sugar > recommendedDailyValues.sugar ? "text-red-500" : "text-[#64748B]"}`}
                              >
                                / {recommendedDailyValues.sugar}g (
                                {Math.round((basketTotals.sugar / recommendedDailyValues.sugar) * 100)}%)
                              </span>
                            </div>
                          </div>
                          <div className="flex justify-between items-center">
                            <span className="text-sm text-[#64748B]">나트륨</span>
                            <div className="text-right">
                              <span
                                className={`font-bold ${basketTotals.sodium > recommendedDailyValues.sodium ? "text-red-600" : "text-[#0F172A]"}`}
                              >
                                {basketTotals.sodium}mg
                              </span>
                              <span
                                className={`text-xs ml-2 ${basketTotals.sodium > recommendedDailyValues.sodium ? "text-red-500" : "text-[#64748B]"}`}
                              >
                                / {recommendedDailyValues.sodium}mg (
                                {Math.round((basketTotals.sodium / recommendedDailyValues.sodium) * 100)}%)
                              </span>
                            </div>
                          </div>
                        </div>
                      </div>

                      <Button
                        onClick={checkNutritionLimits}
                        className="w-full bg-gradient-to-r from-[#10B981] to-[#059669] hover:from-[#059669] hover:to-[#047857] text-white font-semibold py-3 rounded-xl shadow-lg"
                      >
                        에너지 충전하기
                      </Button>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {showWarning && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-3xl shadow-2xl max-w-md w-full">
            <div className="bg-gradient-to-r from-[#EF4444] to-[#DC2626] text-white p-6 rounded-t-3xl">
              <h3 className="text-xl font-bold">영양 기준 초과 알림</h3>
            </div>
            <div className="p-6">
              <p className="text-[#0F172A] mb-6">
                선택한 간식이 일일 <strong>{warningType}</strong> 권장량을 초과합니다.
              </p>
              <div className="flex gap-3">
                <Button
                  onClick={() => setShowWarning(false)}
                  className="flex-1 bg-[#F1F5F9] hover:bg-[#E2E8F0] text-[#64748B] border-0 rounded-xl"
                >
                  취소
                </Button>
                <Button
                  onClick={useOverride}
                  disabled={remainingOverrides === 0}
                  className="flex-1 bg-gradient-to-r from-[#F59E0B] to-[#D97706] hover:from-[#D97706] hover:to-[#B45309] text-white border-0 rounded-xl disabled:opacity-50"
                >
                  예외권 사용 ({remainingOverrides}개 남음)
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}

      {showHealthSetup && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-3xl shadow-2xl max-w-4xl w-full max-h-[90vh] overflow-hidden">
            <div className="bg-gradient-to-r from-[#0A1F44] to-[#1E3A8A] text-white p-6">
              <div className="flex items-center justify-between">
                <h2 className="text-2xl font-bold">개인 건강 정보 설정</h2>
                <Button
                  onClick={() => setShowHealthSetup(false)}
                  className="bg-white/20 hover:bg-white/30 text-white border-0 rounded-xl"
                >
                  ✕
                </Button>
              </div>
            </div>

            <div className="p-6 max-h-[70vh] overflow-y-auto">
              <div className="space-y-8">
                {/* 기본 신체 정보 */}
                <div className="bg-gradient-to-r from-blue-50 to-indigo-50 p-6 rounded-2xl">
                  <h3 className="text-lg font-bold text-[#0F172A] mb-4 flex items-center">
                    <span className="w-8 h-8 bg-blue-500 text-white rounded-full flex items-center justify-center text-sm mr-3">
                      1
                    </span>
                    기본 신체 정보
                  </h3>
                  <div className="grid md:grid-cols-4 gap-4">
                    <div>
                      <label className="block text-sm font-semibold text-[#0F172A] mb-2">성별</label>
                      <select
                        value={healthData.gender}
                        onChange={(e) => setHealthData({ ...healthData, gender: e.target.value })}
                        className="w-full p-3 border border-[#E2E8F0] rounded-xl focus:ring-2 focus:ring-[#10B981] focus:border-transparent"
                      >
                        <option value="male">남성</option>
                        <option value="female">여성</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-sm font-semibold text-[#0F172A] mb-2">출생년도</label>
                      <input
                        type="number"
                        value={healthData.birthYear}
                        onChange={(e) => setHealthData({ ...healthData, birthYear: Number.parseInt(e.target.value) })}
                        className="w-full p-3 border border-[#E2E8F0] rounded-xl focus:ring-2 focus:ring-[#10B981] focus:border-transparent"
                        placeholder="1990"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-semibold text-[#0F172A] mb-2">키 (cm)</label>
                      <input
                        type="number"
                        value={healthInfo.height}
                        onChange={(e) => setHealthInfo({ ...healthInfo, height: e.target.value })}
                        className="w-full p-3 border border-[#E2E8F0] rounded-xl focus:ring-2 focus:ring-[#10B981] focus:border-transparent"
                        placeholder="175"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-semibold text-[#0F172A] mb-2">몸무게 (kg)</label>
                      <input
                        type="number"
                        value={healthInfo.weight}
                        onChange={(e) => setHealthInfo({ ...healthInfo, weight: e.target.value })}
                        className="w-full p-3 border border-[#E2E8F0] rounded-xl focus:ring-2 focus:ring-[#10B981] focus:border-transparent"
                        placeholder="70"
                      />
                    </div>
                  </div>

                  {/* BMI 계산 결과 */}
                  {healthInfo.height && healthInfo.weight && (
                    <div className="mt-4 p-4 bg-white rounded-xl border border-[#E2E8F0]">
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-medium text-[#64748B]">BMI</span>
                        <div className="text-right">
                          <span className="text-2xl font-bold text-[#0F172A]">
                            {calculateBMI(Number.parseFloat(healthInfo.height), Number.parseFloat(healthInfo.weight))}
                          </span>
                          <span
                            className={`ml-2 text-sm font-medium ${getBMIStatus(Number.parseFloat(calculateBMI(Number.parseFloat(healthInfo.height), Number.parseFloat(healthInfo.weight)))).color}`}
                          >
                            {
                              getBMIStatus(
                                Number.parseFloat(
                                  calculateBMI(
                                    Number.parseFloat(healthInfo.height),
                                    Number.parseFloat(healthInfo.weight),
                                  ),
                                ),
                              ).status
                            }
                          </span>
                        </div>
                      </div>
                    </div>
                  )}
                </div>

                {/* 활동량 및 권장 칼로리 */}
                <div className="bg-gradient-to-r from-green-50 to-emerald-50 p-6 rounded-2xl">
                  <h3 className="text-lg font-bold text-[#0F172A] mb-4 flex items-center">
                    <span className="w-8 h-8 bg-green-500 text-white rounded-full flex items-center justify-center text-sm mr-3">
                      2
                    </span>
                    활동량 및 권장 칼로리
                  </h3>
                  <div className="grid md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-semibold text-[#0F172A] mb-2">활동량</label>
                      <select
                        value={healthData.activityLevel}
                        onChange={(e) => setHealthData({ ...healthData, activityLevel: e.target.value })}
                        className="w-full p-3 border border-[#E2E8F0] rounded-xl focus:ring-2 focus:ring-[#10B981] focus:border-transparent"
                      >
                        <option value="정적">정적 (사무직, 거의 운동 안함)</option>
                        <option value="가벼운">가벼운 (주 1-3회 가벼운 운동)</option>
                        <option value="보통">보통 (주 3-5회 중간 강도 운동)</option>
                        <option value="활발한">활발한 (주 6-7회 강한 운동)</option>
                        <option value="매우활발한">매우 활발한 (하루 2회 운동 또는 육체노동)</option>
                      </select>
                    </div>
                    <div className="flex items-end">
                      <div className="w-full p-4 bg-white rounded-xl border border-[#E2E8F0]">
                        <div className="text-center">
                          <span className="text-sm font-medium text-[#64748B]">일일 권장 칼로리</span>
                          <div className="text-3xl font-bold text-green-600 mt-1">
                            {calculateRecommendedCalories(
                              Number.parseFloat(healthInfo.height) || 175,
                              Number.parseFloat(healthInfo.weight) || 70,
                              new Date().getFullYear() - healthData.birthYear,
                              healthData.gender,
                              healthData.activityLevel,
                            )}
                            <span className="text-sm text-[#64748B] ml-1">kcal</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                {/* 혈압 및 혈당 */}
                <div className="bg-gradient-to-r from-red-50 to-pink-50 p-6 rounded-2xl">
                  <h3 className="text-lg font-bold text-[#0F172A] mb-4 flex items-center">
                    <span className="w-8 h-8 bg-red-500 text-white rounded-full flex items-center justify-center text-sm mr-3">
                      3
                    </span>
                    혈압 및 혈당
                  </h3>
                  <div className="grid md:grid-cols-3 gap-4">
                    <div>
                      <label className="block text-sm font-semibold text-[#0F172A] mb-2">수축기 혈압 (mmHg)</label>
                      <input
                        type="number"
                        value={healthData.bloodPressure.systolic || ""}
                        onChange={(e) =>
                          setHealthData({
                            ...healthData,
                            bloodPressure: {
                              ...healthData.bloodPressure,
                              systolic: Number.parseInt(e.target.value) || 0,
                            },
                          })
                        }
                        className="w-full p-3 border border-[#E2E8F0] rounded-xl focus:ring-2 focus:ring-[#10B981] focus:border-transparent"
                        placeholder="120"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-semibold text-[#0F172A] mb-2">이완기 혈압 (mmHg)</label>
                      <input
                        type="number"
                        value={healthData.bloodPressure.diastolic || ""}
                        onChange={(e) =>
                          setHealthData({
                            ...healthData,
                            bloodPressure: {
                              ...healthData.bloodPressure,
                              diastolic: Number.parseInt(e.target.value) || 0,
                            },
                          })
                        }
                        className="w-full p-3 border border-[#E2E8F0] rounded-xl focus:ring-2 focus:ring-[#10B981] focus:border-transparent"
                        placeholder="80"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-semibold text-[#0F172A] mb-2">공복혈당 (mg/dL)</label>
                      <input
                        type="number"
                        value={healthData.bloodSugar.value || ""}
                        onChange={(e) =>
                          setHealthData({
                            ...healthData,
                            bloodSugar: { value: Number.parseInt(e.target.value) || 0 },
                          })
                        }
                        className="w-full p-3 border border-[#E2E8F0] rounded-xl focus:ring-2 focus:ring-[#10B981] focus:border-transparent"
                        placeholder="100"
                      />
                    </div>
                  </div>
                </div>

                {/* 인바디 정보 */}
                <div className="bg-gradient-to-r from-purple-50 to-violet-50 p-6 rounded-2xl">
                  <h3 className="text-lg font-bold text-[#0F172A] mb-4 flex items-center">
                    <span className="w-8 h-8 bg-purple-500 text-white rounded-full flex items-center justify-center text-sm mr-3">
                      4
                    </span>
                    인바디 정보 (선택사항)
                  </h3>
                  <div className="grid md:grid-cols-3 gap-4">
                    <div>
                      <label className="block text-sm font-semibold text-[#0F172A] mb-2">체지방률 (%)</label>
                      <input
                        type="number"
                        value={healthData.inbodyData.bodyFat}
                        onChange={(e) =>
                          setHealthData({
                            ...healthData,
                            inbodyData: { ...healthData.inbodyData, bodyFat: Number.parseFloat(e.target.value) },
                          })
                        }
                        className="w-full p-3 border border-[#E2E8F0] rounded-xl focus:ring-2 focus:ring-[#10B981] focus:border-transparent"
                        placeholder="15"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-semibold text-[#0F172A] mb-2">근육량 (kg)</label>
                      <input
                        type="number"
                        value={healthData.inbodyData.muscleMass}
                        onChange={(e) =>
                          setHealthData({
                            ...healthData,
                            inbodyData: { ...healthData.inbodyData, muscleMass: Number.parseFloat(e.target.value) },
                          })
                        }
                        className="w-full p-3 border border-[#E2E8F0] rounded-xl focus:ring-2 focus:ring-[#10B981] focus:border-transparent"
                        placeholder="35"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-semibold text-[#0F172A] mb-2">내장지방 레벨</label>
                      <input
                        type="number"
                        value={healthData.inbodyData.visceralFat}
                        onChange={(e) =>
                          setHealthData({
                            ...healthData,
                            inbodyData: { ...healthData.inbodyData, visceralFat: Number.parseFloat(e.target.value) },
                          })
                        }
                        className="w-full p-3 border border-[#E2E8F0] rounded-xl focus:ring-2 focus:ring-[#10B981] focus:border-transparent"
                        placeholder="5"
                      />
                    </div>
                  </div>
                </div>
              </div>

              <div className="mt-8 flex gap-3">
                <Button
                  onClick={() => setShowHealthSetup(false)}
                  className="flex-1 bg-[#F1F5F9] hover:bg-[#E2E8F0] text-[#64748B] border-0 rounded-xl"
                >
                  취소
                </Button>
                <Button
                  onClick={() => {
                    const formData = {
                      height: healthInfo.height,
                      weight: healthInfo.weight,
                      age: new Date().getFullYear() - healthData.birthYear,
                      diabetes: healthInfo.diabetes,
                      hypertension: healthInfo.hypertension,
                      allergies: healthInfo.allergies
                        ? healthInfo.allergies
                            .split(",")
                            .map((a) => a.trim())
                            .filter((a) => a)
                        : [],
                      gender: healthData.gender,
                      birthYear: healthData.birthYear,
                      activityLevel: healthData.activityLevel,
                      bloodPressure: healthData.bloodPressure,
                      bloodSugar: healthData.bloodSugar,
                      inbodyData: healthData.inbodyData,
                      bmi: calculateBMI(Number.parseFloat(healthInfo.height), Number.parseFloat(healthInfo.weight)),
                      recommendedCalories: calculateRecommendedCalories(
                        Number.parseFloat(healthInfo.height) || 175,
                        Number.parseFloat(healthInfo.weight) || 70,
                        new Date().getFullYear() - healthData.birthYear,
                        healthData.gender,
                        healthData.activityLevel,
                      ),
                    }
                    handleHealthInfoSave(formData)
                  }}
                  className="flex-1 bg-gradient-to-r from-[#10B981] to-[#059669] hover:from-[#059669] hover:to-[#047857] text-white border-0 rounded-xl"
                >
                  건강 정보 저장
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}

      {showChatbot && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-3xl shadow-2xl max-w-2xl w-full max-h-[80vh] overflow-hidden">
            <div className="bg-gradient-to-r from-[#0A1F44] to-[#1E3A8A] text-white p-6">
              <div className="flex items-center justify-between">
                <h2 className="text-2xl font-bold">AI 건강 어시스턴트</h2>
                <Button
                  onClick={() => setShowChatbot(false)}
                  className="bg-white/20 hover:bg-white/30 text-white border-0 rounded-xl"
                >
                  ✕
                </Button>
              </div>
            </div>

            <div className="flex flex-col h-[60vh]">
              <div ref={setChatScrollRef} className="flex-1 overflow-y-auto p-6 space-y-4">
                {chatMessages.map((message) => (
                  <div key={message.id} className={`flex ${message.isUser ? "justify-end" : "justify-start"}`}>
                    <div
                      className={`max-w-[80%] p-4 rounded-2xl ${
                        message.isUser
                          ? "bg-gradient-to-r from-[#10B981] to-[#059669] text-white"
                          : "bg-[#F8FAFC] border border-[#E2E8F0] text-[#0F172A]"
                      }`}
                    >
                      <p className="leading-relaxed">{message.content}</p>
                    </div>
                  </div>
                ))}
              </div>

              <div className="p-6 border-t border-[#E2E8F0]">
                <div className="flex gap-3">
                  <input
                    type="text"
                    value={chatInput}
                    onChange={(e) => setChatInput(e.target.value)}
                    onKeyPress={handleKeyPress}
                    placeholder="건강에 대해 궁금한 점을 물어보세요..."
                    className="flex-1 p-3 border border-[#E2E8F0] rounded-xl focus:ring-2 focus:ring-[#10B981] focus:border-transparent"
                    disabled={isLoading}
                  />
                  <Button
                    onClick={handleSendMessage}
                    disabled={isLoading || !chatInput.trim()}
                    className="bg-gradient-to-r from-[#10B981] to-[#059669] hover:from-[#059669] hover:to-[#047857] text-white border-0 rounded-xl px-6"
                  >
                    {isLoading ? "..." : "전송"}
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
