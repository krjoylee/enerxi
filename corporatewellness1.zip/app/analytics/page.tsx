import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  TrendingUp,
  TrendingDown,
  Users,
  ShoppingCart,
  DollarSign,
  AlertTriangle,
  Download,
  Filter,
} from "lucide-react"

// Sample analytics data
const consumptionTrends = [
  { month: "1월", consumption: 1200, cost: 480000, employees: 85 },
  { month: "2월", consumption: 1350, cost: 540000, employees: 92 },
  { month: "3월", consumption: 1180, cost: 472000, employees: 88 },
  { month: "4월", consumption: 1420, cost: 568000, employees: 95 },
  { month: "5월", consumption: 1380, cost: 552000, employees: 93 },
  { month: "6월", consumption: 1500, cost: 600000, employees: 98 },
]

const categoryDistribution = [
  { name: "과자류", value: 35, color: "#0891b2" },
  { name: "음료", value: 28, color: "#ec4899" },
  { name: "견과류", value: 18, color: "#10b981" },
  { name: "초콜릿", value: 12, color: "#f59e0b" },
  { name: "기타", value: 7, color: "#8b5cf6" },
]

const popularSnacks = [
  { name: "허니버터칩", consumption: 245, trend: "up", change: 12 },
  { name: "초코파이", consumption: 198, trend: "up", change: 8 },
  { name: "아메리카노", consumption: 187, trend: "down", change: -5 },
  { name: "바나나킥", consumption: 156, trend: "up", change: 15 },
  { name: "오레오", consumption: 134, trend: "down", change: -3 },
]

const healthMetrics = [
  { metric: "평균 일일 칼로리", value: "1,245", target: "1,500", status: "good" },
  { metric: "평균 당 섭취량", value: "45g", target: "50g", status: "good" },
  { metric: "평균 나트륨 섭취량", value: "1,890mg", target: "2,000mg", status: "warning" },
  { metric: "권장량 초과 직원", value: "12명", target: "< 10명", status: "alert" },
]

export default function AnalyticsPage() {
  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">데이터 분석</h1>
            <p className="text-gray-600 mt-1">enerXIzer 이용 현황 및 건강 지표 분석</p>
          </div>
          <div className="flex gap-3">
            <Button variant="outline" className="gap-2 bg-transparent">
              <Filter className="w-4 h-4" />
              필터
            </Button>
            <Button className="gap-2 bg-primary hover:bg-primary/90">
              <Download className="w-4 h-4" />
              리포트 다운로드
            </Button>
          </div>
        </div>

        <Tabs defaultValue="overview" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="overview">전체 현황</TabsTrigger>
            <TabsTrigger value="consumption">소비 분석</TabsTrigger>
            <TabsTrigger value="health">건강 지표</TabsTrigger>
            <TabsTrigger value="predictions">예측 분석</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-6">
            {/* KPI Cards */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">월간 이용자</CardTitle>
                  <Users className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">98명</div>
                  <p className="text-xs text-muted-foreground">
                    <span className="text-green-600">+5.4%</span> 전월 대비
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">월간 소비량</CardTitle>
                  <ShoppingCart className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">1,500개</div>
                  <p className="text-xs text-muted-foreground">
                    <span className="text-green-600">+8.7%</span> 전월 대비
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">월간 비용</CardTitle>
                  <DollarSign className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">₩600,000</div>
                  <p className="text-xs text-muted-foreground">
                    <span className="text-green-600">+8.7%</span> 전월 대비
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">폐기율</CardTitle>
                  <AlertTriangle className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">3.2%</div>
                  <p className="text-xs text-muted-foreground">
                    <span className="text-red-600">-1.8%</span> 전월 대비
                  </p>
                </CardContent>
              </Card>
            </div>

            {/* Charts */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>월별 소비 추이</CardTitle>
                  <CardDescription>최근 6개월 간식 소비량 및 비용</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="h-[300px] flex items-end justify-between gap-2 p-4">
                    {consumptionTrends.map((data, index) => (
                      <div key={data.month} className="flex flex-col items-center gap-2 flex-1">
                        <div className="flex flex-col items-center gap-1">
                          <div
                            className="w-full bg-primary rounded-t-sm"
                            style={{ height: `${(data.consumption / 1500) * 200}px` }}
                          />
                          <div
                            className="w-full bg-secondary rounded-t-sm"
                            style={{ height: `${(data.employees / 100) * 150}px` }}
                          />
                        </div>
                        <div className="text-xs text-center">
                          <div className="font-medium">{data.month}</div>
                          <div className="text-gray-600">{data.consumption}개</div>
                          <div className="text-gray-600">{data.employees}명</div>
                        </div>
                      </div>
                    ))}
                  </div>
                  <div className="flex justify-center gap-6 mt-4">
                    <div className="flex items-center gap-2">
                      <div className="w-3 h-3 bg-primary rounded"></div>
                      <span className="text-sm">소비량</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="w-3 h-3 bg-secondary rounded"></div>
                      <span className="text-sm">이용자 수</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>카테고리별 소비 분포</CardTitle>
                  <CardDescription>간식 종류별 소비 비율</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {categoryDistribution.map((category) => (
                      <div key={category.name} className="space-y-2">
                        <div className="flex justify-between items-center">
                          <span className="text-sm font-medium">{category.name}</span>
                          <span className="text-sm text-gray-600">{category.value}%</span>
                        </div>
                        <div className="w-full bg-gray-200 rounded-full h-3">
                          <div
                            className="h-3 rounded-full"
                            style={{
                              width: `${category.value}%`,
                              backgroundColor: category.color,
                            }}
                          />
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="consumption" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>인기 간식 순위</CardTitle>
                  <CardDescription>이번 달 가장 많이 소비된 간식</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {popularSnacks.map((snack, index) => (
                      <div key={snack.name} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                        <div className="flex items-center gap-3">
                          <div className="w-8 h-8 bg-primary text-white rounded-full flex items-center justify-center text-sm font-bold">
                            {index + 1}
                          </div>
                          <div>
                            <p className="font-medium">{snack.name}</p>
                            <p className="text-sm text-gray-600">{snack.consumption}개 소비</p>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          {snack.trend === "up" ? (
                            <TrendingUp className="w-4 h-4 text-green-600" />
                          ) : (
                            <TrendingDown className="w-4 h-4 text-red-600" />
                          )}
                          <span
                            className={`text-sm font-medium ${snack.trend === "up" ? "text-green-600" : "text-red-600"}`}
                          >
                            {snack.change > 0 ? "+" : ""}
                            {snack.change}%
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>시간대별 이용 패턴</CardTitle>
                  <CardDescription>하루 중 enerXIzer 이용 빈도</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="h-[300px] flex items-end justify-between gap-2 p-4">
                    {[
                      { time: "09:00", usage: 45 },
                      { time: "10:00", usage: 78 },
                      { time: "11:00", usage: 92 },
                      { time: "12:00", usage: 156 },
                      { time: "13:00", usage: 134 },
                      { time: "14:00", usage: 89 },
                      { time: "15:00", usage: 112 },
                      { time: "16:00", usage: 98 },
                      { time: "17:00", usage: 67 },
                    ].map((data) => (
                      <div key={data.time} className="flex flex-col items-center gap-2 flex-1">
                        <div
                          className="w-full bg-primary rounded-t-sm"
                          style={{ height: `${(data.usage / 156) * 200}px` }}
                        />
                        <div className="text-xs text-center">
                          <div className="font-medium">{data.time}</div>
                          <div className="text-gray-600">{data.usage}</div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="health" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {healthMetrics.map((metric) => (
                <Card key={metric.metric}>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium">{metric.metric}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">{metric.value}</div>
                    <div className="flex items-center justify-between mt-2">
                      <p className="text-xs text-gray-600">목표: {metric.target}</p>
                      <Badge
                        variant={
                          metric.status === "good"
                            ? "default"
                            : metric.status === "warning"
                              ? "secondary"
                              : "destructive"
                        }
                      >
                        {metric.status === "good" ? "양호" : metric.status === "warning" ? "주의" : "위험"}
                      </Badge>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            <Card>
              <CardHeader>
                <CardTitle>건강 지표 추이</CardTitle>
                <CardDescription>직원들의 월별 평균 영양소 섭취량</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  {[
                    { label: "칼로리", data: [1180, 1220, 1190, 1260, 1240, 1245], color: "bg-blue-500", max: 1300 },
                    { label: "당분 (g)", data: [42, 45, 41, 48, 46, 45], color: "bg-green-500", max: 50 },
                    {
                      label: "나트륨 (mg)",
                      data: [1750, 1820, 1780, 1890, 1860, 1890],
                      color: "bg-orange-500",
                      max: 2000,
                    },
                  ].map((metric) => (
                    <div key={metric.label} className="space-y-2">
                      <div className="flex justify-between items-center">
                        <span className="font-medium">{metric.label}</span>
                        <span className="text-sm text-gray-600">현재: {metric.data[metric.data.length - 1]}</span>
                      </div>
                      <div className="flex items-end gap-1 h-16">
                        {metric.data.map((value, index) => (
                          <div key={index} className="flex-1 flex flex-col items-center gap-1">
                            <div
                              className={`w-full ${metric.color} rounded-t-sm`}
                              style={{ height: `${(value / metric.max) * 60}px` }}
                            />
                            <span className="text-xs text-gray-500">{index + 1}월</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="predictions" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>다음 달 예상 소비량</CardTitle>
                  <CardDescription>AI 기반 소비 패턴 예측</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex justify-between items-center p-4 bg-blue-50 rounded-lg">
                      <div>
                        <p className="font-medium">예상 총 소비량</p>
                        <p className="text-2xl font-bold text-blue-700">1,620개</p>
                      </div>
                      <div className="text-right">
                        <p className="text-sm text-gray-600">신뢰도</p>
                        <p className="text-lg font-semibold">87%</p>
                      </div>
                    </div>
                    <div className="flex justify-between items-center p-4 bg-green-50 rounded-lg">
                      <div>
                        <p className="font-medium">예상 비용</p>
                        <p className="text-2xl font-bold text-green-700">₩648,000</p>
                      </div>
                      <div className="text-right">
                        <p className="text-sm text-gray-600">절약 가능</p>
                        <p className="text-lg font-semibold">₩52,000</p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>재고 관리 권장사항</CardTitle>
                  <CardDescription>AI 추천 구매 계획</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex justify-between items-center p-3 border rounded-lg">
                      <span className="font-medium">허니버터칩</span>
                      <Badge className="bg-green-100 text-green-800">+20개 추가</Badge>
                    </div>
                    <div className="flex justify-between items-center p-3 border rounded-lg">
                      <span className="font-medium">초코파이</span>
                      <Badge className="bg-blue-100 text-blue-800">현재 유지</Badge>
                    </div>
                    <div className="flex justify-between items-center p-3 border rounded-lg">
                      <span className="font-medium">아메리카노</span>
                      <Badge className="bg-red-100 text-red-800">-10개 감소</Badge>
                    </div>
                    <div className="flex justify-between items-center p-3 border rounded-lg">
                      <span className="font-medium">바나나킥</span>
                      <Badge className="bg-green-100 text-green-800">+15개 추가</Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
