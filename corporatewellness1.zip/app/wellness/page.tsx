import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Progress } from "@/components/ui/progress"
import { Heart, Cigarette, Activity, Moon, Users, Calendar, ArrowLeft, CheckCircle } from "lucide-react"
import Link from "next/link"

// Sample wellness programs data
const wellnessPrograms = [
  {
    id: 1,
    title: "금연 관리 프로그램",
    description: "체계적인 금연 계획과 전문가 상담을 통해 건강한 금연을 지원합니다.",
    icon: Cigarette,
    duration: "12주",
    participants: 15,
    maxParticipants: 20,
    status: "모집중",
    benefits: ["전문 상담사 1:1 상담", "금연 보조제 지원", "성공 시 인센티브 제공"],
    schedule: "매주 화요일 오후 2시",
    enrolled: false,
  },
  {
    id: 2,
    title: "당뇨 관리 프로그램",
    description: "혈당 관리와 식단 조절을 통한 당뇨 예방 및 관리 프로그램입니다.",
    icon: Heart,
    duration: "8주",
    participants: 8,
    maxParticipants: 15,
    status: "모집중",
    benefits: ["혈당 측정기 제공", "영양사 식단 상담", "운동 처방 제공"],
    schedule: "매주 목요일 오후 3시",
    enrolled: true,
  },
  {
    id: 3,
    title: "불면 테라피",
    description: "수면의 질 개선을 위한 인지행동치료 기반 불면증 관리 프로그램입니다.",
    icon: Moon,
    duration: "6주",
    participants: 12,
    maxParticipants: 12,
    status: "마감",
    benefits: ["수면 일지 작성 지도", "이완 기법 교육", "수면 환경 개선 컨설팅"],
    schedule: "매주 금요일 오후 4시",
    enrolled: false,
  },
  {
    id: 4,
    title: "스트레스 관리 워크샵",
    description: "직장 내 스트레스 해소와 정신 건강 증진을 위한 프로그램입니다.",
    icon: Activity,
    duration: "4주",
    participants: 18,
    maxParticipants: 25,
    status: "모집중",
    benefits: ["명상 및 요가 교육", "스트레스 측정 및 분석", "개인별 관리 방법 제공"],
    schedule: "매주 수요일 오후 5시",
    enrolled: false,
  },
]

const myPrograms = [
  {
    title: "당뇨 관리 프로그램",
    progress: 62,
    week: "5주차",
    nextSession: "2024-06-20 15:00",
    status: "진행중",
  },
]

export default function WellnessPage() {
  return (
    <div className="min-h-screen bg-slate-50 p-6">
      <div className="max-w-6xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Link href="/">
              <Button variant="outline" size="sm">
                <ArrowLeft className="w-4 h-4 mr-2" />
                홈으로
              </Button>
            </Link>
            <div>
              <h1 className="text-3xl font-bold text-slate-900">GS 웰니스 프로그램</h1>
              <p className="text-slate-600 mt-1">직원 건강 증진을 위한 다양한 웰니스 프로그램에 참여하세요</p>
            </div>
          </div>
        </div>

        <Tabs defaultValue="available" className="space-y-6">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="available">참여 가능한 프로그램</TabsTrigger>
            <TabsTrigger value="my-programs">내 프로그램</TabsTrigger>
            <TabsTrigger value="completed">완료한 프로그램</TabsTrigger>
          </TabsList>

          <TabsContent value="available" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {wellnessPrograms.map((program) => {
                const IconComponent = program.icon
                return (
                  <Card key={program.id} className="relative">
                    <CardHeader>
                      <div className="flex items-start justify-between">
                        <div className="flex items-center gap-3">
                          <div className="w-12 h-12 bg-cyan-100 rounded-lg flex items-center justify-center">
                            <IconComponent className="w-6 h-6 text-cyan-700" />
                          </div>
                          <div>
                            <CardTitle className="text-lg">{program.title}</CardTitle>
                            <div className="flex items-center gap-2 mt-1">
                              <Badge
                                variant={
                                  program.status === "모집중"
                                    ? "default"
                                    : program.status === "마감"
                                      ? "secondary"
                                      : "outline"
                                }
                              >
                                {program.status}
                              </Badge>
                              <span className="text-sm text-slate-600">{program.duration}</span>
                            </div>
                          </div>
                        </div>
                        {program.enrolled && (
                          <Badge className="bg-green-100 text-green-800">
                            <CheckCircle className="w-3 h-3 mr-1" />
                            참여중
                          </Badge>
                        )}
                      </div>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <p className="text-slate-600">{program.description}</p>

                      <div className="space-y-2">
                        <div className="flex items-center justify-between text-sm">
                          <span className="text-slate-600">참여 인원</span>
                          <span>
                            {program.participants}/{program.maxParticipants}명
                          </span>
                        </div>
                        <Progress value={(program.participants / program.maxParticipants) * 100} className="h-2" />
                      </div>

                      <div className="space-y-2">
                        <h4 className="font-medium text-sm">프로그램 혜택</h4>
                        <ul className="space-y-1">
                          {program.benefits.map((benefit, index) => (
                            <li key={index} className="text-sm text-slate-600 flex items-center gap-2">
                              <div className="w-1.5 h-1.5 bg-cyan-600 rounded-full" />
                              {benefit}
                            </li>
                          ))}
                        </ul>
                      </div>

                      <div className="flex items-center gap-2 text-sm text-slate-600">
                        <Calendar className="w-4 h-4" />
                        {program.schedule}
                      </div>

                      <div className="pt-2">
                        {program.enrolled ? (
                          <Button disabled className="w-full">
                            <CheckCircle className="w-4 h-4 mr-2" />
                            참여중
                          </Button>
                        ) : program.status === "마감" ? (
                          <Button disabled variant="secondary" className="w-full">
                            마감
                          </Button>
                        ) : (
                          <Button className="w-full bg-cyan-700 hover:bg-cyan-800">
                            <Users className="w-4 h-4 mr-2" />
                            프로그램 신청
                          </Button>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                )
              })}
            </div>
          </TabsContent>

          <TabsContent value="my-programs" className="space-y-6">
            {myPrograms.length > 0 ? (
              <div className="space-y-6">
                {myPrograms.map((program, index) => (
                  <Card key={index}>
                    <CardHeader>
                      <div className="flex items-center justify-between">
                        <CardTitle className="text-xl">{program.title}</CardTitle>
                        <Badge className="bg-blue-100 text-blue-800">{program.status}</Badge>
                      </div>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="space-y-2">
                        <div className="flex items-center justify-between">
                          <span className="text-sm font-medium">진행률</span>
                          <span className="text-sm text-slate-600">
                            {program.week} ({program.progress}%)
                          </span>
                        </div>
                        <Progress value={program.progress} className="h-3" />
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="p-4 bg-slate-50 rounded-lg">
                          <p className="text-sm font-medium mb-1">다음 세션</p>
                          <p className="text-lg font-bold text-cyan-700">{program.nextSession}</p>
                        </div>
                        <div className="p-4 bg-slate-50 rounded-lg">
                          <p className="text-sm font-medium mb-1">현재 단계</p>
                          <p className="text-lg font-bold text-slate-900">{program.week}</p>
                        </div>
                      </div>

                      <div className="flex gap-3">
                        <Button className="flex-1 bg-cyan-700 hover:bg-cyan-800">세션 참여하기</Button>
                        <Button variant="outline" className="flex-1 bg-transparent">
                          진행 상황 보기
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : (
              <Card>
                <CardContent className="text-center py-12">
                  <Activity className="w-12 h-12 text-slate-400 mx-auto mb-4" />
                  <h3 className="text-lg font-medium text-slate-900 mb-2">참여중인 프로그램이 없습니다</h3>
                  <p className="text-slate-600 mb-4">건강 증진을 위한 다양한 웰니스 프로그램에 참여해보세요.</p>
                  <Button className="bg-cyan-700 hover:bg-cyan-800">프로그램 둘러보기</Button>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="completed" className="space-y-6">
            <Card>
              <CardContent className="text-center py-12">
                <CheckCircle className="w-12 h-12 text-slate-400 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-slate-900 mb-2">완료한 프로그램이 없습니다</h3>
                <p className="text-slate-600 mb-4">프로그램을 완료하면 여기에서 확인할 수 있습니다.</p>
                <Button className="bg-cyan-700 hover:bg-cyan-800">프로그램 시작하기</Button>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
