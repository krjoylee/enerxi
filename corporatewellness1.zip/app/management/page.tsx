"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Checkbox } from "@/components/ui/checkbox"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Search, Plus, Edit, Trash2, Users, Package, BarChart3, Download, Upload } from "lucide-react"
import { toast } from "@/hooks/use-toast"

interface User {
  id: number
  name: string
  employee_id: string
  department: string
  position: string
  email: string
  phone: string
  birth_date: string
  gender: string
  height: number
  weight: number
  bmi: number
  diabetes: boolean
  hypertension: boolean
  allergies: string
  dietary_restrictions: string
  created_at: string
  updated_at: string
}

interface Product {
  id: number
  name: string
  category: string
  brand: string
  barcode: string
  price: number
  calories_per_100g: number
  protein_per_100g: number
  fat_per_100g: number
  carbs_per_100g: number
  sodium_per_100g: number
  sugar: number
  serving_size: number
  calories_per_serving: number
  protein_percentage: number
  fat_percentage: number
  carbs_percentage: number
  health_rating: string
  allergens: string
  ingredients: string
  image_url: string
  is_active: boolean
  created_at: string
  updated_at: string
}

interface InventoryItem {
  id: number
  product_id: number
  product_name: string
  current_stock: number
  minimum_stock: number
  maximum_stock: number
  reorder_point: number
  last_restock_date: string
  last_restock_quantity: number
  total_consumed: number
  location: string
  expiry_date: string
  supplier: string
  cost_per_unit: number
  created_at: string
  updated_at: string
}

interface OrderLog {
  id: number
  product_id: number
  product_name: string
  order_type: string
  quantity_ordered: number
  order_date: string
  expected_delivery: string
  actual_delivery: string
  status: string
  supplier: string
  total_cost: number
  notes: string
  ordered_by: string
}

const mockProducts = [
  { id: 1, name: "생수 500ml" },
  { id: 2, name: "탄산수 350ml" },
  { id: 3, name: "비타민워터 500ml" },
]

const mockInventory = [
  {
    id: 1,
    productName: "생수 500ml",
    currentStock: 50,
    minStock: 20,
    maxStock: 100,
    reorderPoint: 30,
    unitCost: 500,
    supplier: "샘물상회",
  },
  {
    id: 2,
    productName: "탄산수 350ml",
    currentStock: 15,
    minStock: 10,
    maxStock: 50,
    reorderPoint: 20,
    unitCost: 800,
    supplier: "톡톡음료",
  },
  {
    id: 3,
    productName: "비타민워터 500ml",
    currentStock: 80,
    minStock: 30,
    maxStock: 120,
    reorderPoint: 40,
    unitCost: 1200,
    supplier: "비타민뱅크",
  },
]

const mockOrders = [
  {
    id: 101,
    items: [{ productId: 1, quantity: 30 }],
    supplier: "샘물상회",
    orderDate: "2024-01-20",
    totalAmount: 15000,
    status: "completed",
  },
  {
    id: 102,
    items: [{ productId: 2, quantity: 20 }],
    supplier: "톡톡음료",
    orderDate: "2024-01-22",
    totalAmount: 16000,
    status: "pending",
  },
  {
    id: 103,
    items: [{ productId: 3, quantity: 40 }],
    supplier: "비타민뱅크",
    orderDate: "2024-01-25",
    totalAmount: 48000,
    status: "completed",
  },
  {
    id: 104,
    items: [{ productId: 1, quantity: 10 }],
    supplier: "샘물상회",
    orderDate: "2024-01-28",
    totalAmount: 5000,
    status: "pending",
  },
]

export default function ManagementDashboard() {
  const [activeTab, setActiveTab] = useState("users")
  const [users, setUsers] = useState<User[]>([])
  const [products, setProducts] = useState<Product[]>([])
  const [inventory, setInventory] = useState<InventoryItem[]>([])
  const [orders, setOrders] = useState<OrderLog[]>([])
  const [inventorySearchTerm, setInventorySearchTerm] = useState("")
  const [inventoryCurrentPage, setInventoryCurrentPage] = useState(1)
  const [inventoryTotalPages, setInventoryTotalPages] = useState(1)
  const [orderCurrentPage, setOrderCurrentPage] = useState(1)
  const [orderTotalPages, setOrderTotalPages] = useState(1)
  const [isAddInventoryOpen, setIsAddInventoryOpen] = useState(false)
  const [isManualOrderOpen, setIsManualOrderOpen] = useState(false)
  const [editingInventory, setEditingInventory] = useState<InventoryItem | null>(null)
  const [inventoryFormData, setInventoryFormData] = useState({
    product_id: "",
    product_name: "",
    current_stock: "",
    minimum_stock: "",
    maximum_stock: "",
    reorder_point: "",
    location: "",
    expiry_date: "",
    supplier: "",
    cost_per_unit: "",
  })
  const [orderFormData, setOrderFormData] = useState({
    product_id: "",
    product_name: "",
    quantity_ordered: "",
    supplier: "",
    expected_delivery: "",
    notes: "",
  })
  const [inventorySubTab, setInventorySubTab] = useState("stock")

  const [productSearchTerm, setProductSearchTerm] = useState("")
  const [selectedCategory, setSelectedCategory] = useState("")
  const [productCurrentPage, setProductCurrentPage] = useState(1)
  const [productTotalPages, setProductTotalPages] = useState(1)
  const [isAddProductOpen, setIsAddProductOpen] = useState(false)
  const [editingProduct, setEditingProduct] = useState<Product | null>(null)
  const [productFormData, setProductFormData] = useState({
    name: "",
    category: "",
    brand: "",
    barcode: "",
    price: "",
    calories_per_100g: "",
    protein_per_100g: "",
    fat_per_100g: "",
    carbs_per_100g: "",
    sodium_per_100g: "",
    sugar: "",
    serving_size: "",
    health_rating: "",
    allergens: "",
    ingredients: "",
    image_url: "",
    is_active: true,
  })

  const [loading, setLoading] = useState(false)
  const [searchTerm, setSearchTerm] = useState("")
  const [currentPage, setCurrentPage] = useState(1)
  const [totalPages, setTotalPages] = useState(1)
  const [isAddUserOpen, setIsAddUserOpen] = useState(false)
  const [editingUser, setEditingUser] = useState<User | null>(null)
  const [formData, setFormData] = useState({
    name: "",
    employee_id: "",
    department: "",
    position: "",
    email: "",
    phone: "",
    birth_date: "",
    gender: "",
    height: "",
    weight: "",
    diabetes: false,
    hypertension: false,
    allergies: "",
    dietary_restrictions: "",
  })

  const [showInventoryForm, setShowInventoryForm] = useState(false)
  const [showOrderForm, setShowOrderForm] = useState(false)

  const [csvUploadOpen, setCsvUploadOpen] = useState(false)
  const [csvType, setCsvType] = useState<"users" | "products" | "inventory">("users")
  const [csvFile, setCsvFile] = useState<File | null>(null)
  const [csvUploading, setCsvUploading] = useState(false)

  // CSV Download function
  const handleCSVDownload = async (type: "users" | "products" | "inventory") => {
    try {
      const response = await fetch(`/api/csv?type=${type}`)
      if (!response.ok) throw new Error("Download failed")

      const blob = await response.blob()
      const url = window.URL.createObjectURL(blob)
      const a = document.createElement("a")
      a.href = url
      a.download = `${type}.csv`
      document.body.appendChild(a)
      a.click()
      window.URL.revokeObjectURL(url)
      document.body.removeChild(a)

      toast({
        title: "성공",
        description: `${type} 데이터가 다운로드되었습니다.`,
      })
    } catch (error) {
      toast({
        title: "오류",
        description: "CSV 다운로드에 실패했습니다.",
        variant: "destructive",
      })
    }
  }

  // CSV Upload function
  const handleCSVUpload = async () => {
    if (!csvFile) {
      toast({
        title: "오류",
        description: "파일을 선택해주세요.",
        variant: "destructive",
      })
      return
    }

    setCsvUploading(true)
    try {
      const formData = new FormData()
      formData.append("file", csvFile)

      const response = await fetch(`/api/csv?type=${csvType}`, {
        method: "POST",
        body: formData,
      })

      const result = await response.json()

      if (!response.ok) {
        throw new Error(result.error || "Upload failed")
      }

      toast({
        title: "성공",
        description: result.message,
      })

      setCsvUploadOpen(false)
      setCsvFile(null)

      // Refresh data based on type
      if (csvType === "users") fetchUsers()
      else if (csvType === "products") fetchProducts()
      else if (csvType === "inventory") fetchInventory()
    } catch (error: any) {
      toast({
        title: "오류",
        description: error.message || "CSV 업로드에 실패했습니다.",
        variant: "destructive",
      })
    } finally {
      setCsvUploading(false)
    }
  }

  // Open CSV upload dialog
  const openCSVUpload = (type: "users" | "products" | "inventory") => {
    setCsvType(type)
    setCsvUploadOpen(true)
  }

  // Fetch users
  const fetchUsers = async () => {
    setLoading(true)
    try {
      const response = await fetch(`/api/users?page=${currentPage}&search=${searchTerm}`)
      const data = await response.json()
      setUsers(data.users)
      setTotalPages(data.totalPages)
    } catch (error) {
      toast({
        title: "오류",
        description: "사용자 데이터를 불러오는데 실패했습니다.",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  const fetchProducts = async () => {
    setLoading(true)
    try {
      const categoryParam = selectedCategory === "all" ? "" : selectedCategory
      const response = await fetch(
        `/api/products?page=${productCurrentPage}&search=${productSearchTerm}&category=${categoryParam}`,
      )
      const data = await response.json()
      setProducts(data.products)
      setProductTotalPages(data.totalPages)
    } catch (error) {
      toast({
        title: "오류",
        description: "품목 데이터를 불러오는데 실패했습니다.",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  const fetchInventory = async () => {
    setLoading(true)
    try {
      const response = await fetch(`/api/inventory?page=${inventoryCurrentPage}&search=${inventorySearchTerm}`)
      const data = await response.json()
      setInventory(data.inventory)
      setInventoryTotalPages(data.totalPages)
    } catch (error) {
      toast({
        title: "오류",
        description: "재고 데이터를 불러오는데 실패했습니다.",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  const fetchOrders = async () => {
    setLoading(true)
    try {
      const response = await fetch(`/api/inventory?type=orders&page=${orderCurrentPage}`)
      const data = await response.json()
      setOrders(data.orders)
      setOrderTotalPages(data.totalPages)
    } catch (error) {
      toast({
        title: "오류",
        description: "주문 데이터를 불러오는데 실패했습니다.",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchUsers()
  }, [currentPage, searchTerm])

  useEffect(() => {
    if (activeTab === "products") {
      fetchProducts()
    }
  }, [activeTab, productCurrentPage, productSearchTerm, selectedCategory])

  useEffect(() => {
    if (activeTab === "inventory") {
      fetchInventory()
      fetchOrders()
    }
  }, [activeTab, inventoryCurrentPage, inventorySearchTerm, orderCurrentPage])

  // Calculate BMI
  const calculateBMI = (height: number, weight: number) => {
    if (height && weight) {
      return Math.round((weight / Math.pow(height / 100, 2)) * 100) / 100
    }
    return 0
  }

  const calculateCaloriesPerServing = (caloriesPer100g: number, servingSize: number) => {
    if (caloriesPer100g && servingSize) {
      return Math.round((caloriesPer100g * servingSize) / 100)
    }
    return 0
  }

  const calculateNutrientPercentage = (nutrientPer100g: number, caloriesPer100g: number, caloriesPerGram: number) => {
    if (nutrientPer100g && caloriesPer100g) {
      return Math.round(((nutrientPer100g * caloriesPerGram * 100) / caloriesPer100g) * 100) / 100
    }
    return 0
  }

  // Handle form submission
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)

    try {
      const method = editingUser ? "PUT" : "POST"
      const userData = {
        ...formData,
        height: Number.parseFloat(formData.height),
        weight: Number.parseFloat(formData.weight),
        ...(editingUser && { id: editingUser.id }),
      }

      const response = await fetch("/api/users", {
        method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(userData),
      })

      if (response.ok) {
        toast({
          title: "성공",
          description: editingUser ? "사용자 정보가 수정되었습니다." : "새 사용자가 추가되었습니다.",
        })
        setIsAddUserOpen(false)
        setEditingUser(null)
        resetForm()
        fetchUsers()
      }
    } catch (error) {
      toast({
        title: "오류",
        description: "사용자 정보 저장에 실패했습니다.",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  const handleProductSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)

    try {
      const method = editingProduct ? "PUT" : "POST"
      const productData = {
        ...productFormData,
        price: Number.parseFloat(productFormData.price),
        calories_per_100g: Number.parseInt(productFormData.calories_per_100g),
        protein_per_100g: Number.parseFloat(productFormData.protein_per_100g),
        fat_per_100g: Number.parseFloat(productFormData.fat_per_100g),
        carbs_per_100g: Number.parseFloat(productFormData.carbs_per_100g),
        sodium_per_100g: Number.parseFloat(productFormData.sodium_per_100g),
        sugar: Number.parseFloat(productFormData.sugar),
        serving_size: Number.parseFloat(productFormData.serving_size),
        ...(editingProduct && { id: editingProduct.id }),
      }

      const response = await fetch("/api/products", {
        method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(productData),
      })

      if (response.ok) {
        toast({
          title: "성공",
          description: editingProduct ? "품목 정보가 수정되었습니다." : "새 품목이 추가되었습니다.",
        })
        setIsAddProductOpen(false)
        setEditingProduct(null)
        resetProductForm()
        fetchProducts()
      }
    } catch (error) {
      toast({
        title: "오류",
        description: "품목 정보 저장에 실패했습니다.",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  const handleInventorySubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)

    try {
      const method = editingInventory ? "PUT" : "POST"
      const inventoryData = {
        ...inventoryFormData,
        product_id: Number.parseInt(inventoryFormData.product_id),
        current_stock: Number.parseInt(inventoryFormData.current_stock),
        minimum_stock: Number.parseInt(inventoryFormData.minimum_stock),
        maximum_stock: Number.parseInt(inventoryFormData.maximum_stock),
        reorder_point: Number.parseInt(inventoryFormData.reorder_point),
        cost_per_unit: Number.parseFloat(inventoryFormData.cost_per_unit),
        ...(editingInventory && { id: editingInventory.id }),
      }

      const response = await fetch("/api/inventory", {
        method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(inventoryData),
      })

      if (response.ok) {
        toast({
          title: "성공",
          description: editingInventory ? "재고 정보가 수정되었습니다." : "새 재고 항목이 추가되었습니다.",
        })
        setIsAddInventoryOpen(false)
        setEditingInventory(null)
        resetInventoryForm()
        fetchInventory()
      }
    } catch (error) {
      toast({
        title: "오류",
        description: "재고 정보 저장에 실패했습니다.",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  const handleOrderSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)

    try {
      const orderData = {
        ...orderFormData,
        type: "order",
        order_type: "manual",
        product_id: Number.parseInt(orderFormData.product_id),
        quantity_ordered: Number.parseInt(orderFormData.quantity_ordered),
        ordered_by: "admin",
      }

      const response = await fetch("/api/inventory", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(orderData),
      })

      if (response.ok) {
        toast({
          title: "성공",
          description: "수동 발주가 완료되었습니다.",
        })
        setIsManualOrderOpen(false)
        resetOrderForm()
        fetchOrders()
      }
    } catch (error) {
      toast({
        title: "오류",
        description: "발주 처리에 실패했습니다.",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  // Handle delete user
  const handleDeleteUser = async (id: number) => {
    if (!confirm("정말로 이 사용자를 삭제하시겠습니까?")) return

    try {
      const response = await fetch(`/api/users?id=${id}`, { method: "DELETE" })
      if (response.ok) {
        toast({
          title: "성공",
          description: "사용자가 삭제되었습니다.",
        })
        fetchUsers()
      }
    } catch (error) {
      toast({
        title: "오류",
        description: "사용자 삭제에 실패했습니다.",
        variant: "destructive",
      })
    }
  }

  const handleDeleteProduct = async (id: number) => {
    if (!confirm("정말로 이 품목을 삭제하시겠습니까?")) return

    try {
      const response = await fetch(`/api/products?id=${id}`, { method: "DELETE" })
      if (response.ok) {
        toast({
          title: "성공",
          description: "품목이 삭제되었습니다.",
        })
        fetchProducts()
      }
    } catch (error) {
      toast({
        title: "오류",
        description: "품목 삭제에 실패했습니다.",
        variant: "destructive",
      })
    }
  }

  // Reset form
  const resetForm = () => {
    setFormData({
      name: "",
      employee_id: "",
      department: "",
      position: "",
      email: "",
      phone: "",
      birth_date: "",
      gender: "",
      height: "",
      weight: "",
      diabetes: false,
      hypertension: false,
      allergies: "",
      dietary_restrictions: "",
    })
  }

  const resetProductForm = () => {
    setProductFormData({
      name: "",
      category: "",
      brand: "",
      barcode: "",
      price: "",
      calories_per_100g: "",
      protein_per_100g: "",
      fat_per_100g: "",
      carbs_per_100g: "",
      sodium_per_100g: "",
      sugar: "",
      serving_size: "",
      health_rating: "",
      allergens: "",
      ingredients: "",
      image_url: "",
      is_active: true,
    })
  }

  const resetInventoryForm = () => {
    setInventoryFormData({
      product_id: "",
      product_name: "",
      current_stock: "",
      minimum_stock: "",
      maximum_stock: "",
      reorder_point: "",
      location: "",
      expiry_date: "",
      supplier: "",
      cost_per_unit: "",
    })
  }

  const resetOrderForm = () => {
    setOrderFormData({
      product_id: "",
      product_name: "",
      quantity_ordered: "",
      supplier: "",
      expected_delivery: "",
      notes: "",
    })
  }

  // Edit user
  const handleEditUser = (user: User) => {
    setEditingUser(user)
    setFormData({
      name: user.name,
      employee_id: user.employee_id,
      department: user.department,
      position: user.position,
      email: user.email,
      phone: user.phone,
      birth_date: user.birth_date,
      gender: user.gender,
      height: user.height.toString(),
      weight: user.weight.toString(),
      diabetes: user.diabetes,
      hypertension: user.hypertension,
      allergies: user.allergies,
      dietary_restrictions: user.dietary_restrictions,
    })
    setIsAddUserOpen(true)
  }

  const handleEditProduct = (product: Product) => {
    setEditingProduct(product)
    setProductFormData({
      name: product.name,
      category: product.category,
      brand: product.brand,
      barcode: product.barcode,
      price: product.price.toString(),
      calories_per_100g: product.calories_per_100g.toString(),
      protein_per_100g: product.protein_per_100g.toString(),
      fat_per_100g: product.fat_per_100g.toString(),
      carbs_per_100g: product.carbs_per_100g.toString(),
      sodium_per_100g: product.sodium_per_100g.toString(),
      sugar: product.sugar.toString(),
      serving_size: product.serving_size.toString(),
      health_rating: product.health_rating,
      allergens: product.allergens,
      ingredients: product.ingredients,
      image_url: product.image_url,
      is_active: product.is_active,
    })
    setIsAddProductOpen(true)
  }

  const handleEditInventory = (item: InventoryItem) => {
    setEditingInventory(item)
    setInventoryFormData({
      product_id: item.product_id.toString(),
      product_name: item.product_name,
      current_stock: item.current_stock.toString(),
      minimum_stock: item.minimum_stock.toString(),
      maximum_stock: item.maximum_stock.toString(),
      reorder_point: item.reorder_point.toString(),
      location: item.location,
      expiry_date: item.expiry_date,
      supplier: item.supplier,
      cost_per_unit: item.cost_per_unit.toString(),
    })
    setIsAddInventoryOpen(true)
  }

  // Get BMI status
  const getBMIStatus = (bmi: number) => {
    if (bmi < 18.5) return { status: "저체중", color: "bg-blue-100 text-blue-800" }
    if (bmi < 25) return { status: "정상", color: "bg-green-100 text-green-800" }
    if (bmi < 30) return { status: "과체중", color: "bg-yellow-100 text-yellow-800" }
    return { status: "비만", color: "bg-red-100 text-red-800" }
  }

  const getHealthRatingColor = (rating: string) => {
    switch (rating) {
      case "매우좋음":
        return "bg-green-100 text-green-800"
      case "좋음":
        return "bg-blue-100 text-blue-800"
      case "보통":
        return "bg-yellow-100 text-yellow-800"
      case "나쁨":
        return "bg-orange-100 text-orange-800"
      case "매우나쁨":
        return "bg-red-100 text-red-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const getStockStatus = (current: number, minimum: number, reorderPoint: number) => {
    if (current <= 0) return { status: "품절", color: "bg-red-100 text-red-800" }
    if (current <= minimum) return { status: "부족", color: "bg-orange-100 text-orange-800" }
    if (current <= reorderPoint) return { status: "발주필요", color: "bg-yellow-100 text-yellow-800" }
    return { status: "충분", color: "bg-green-100 text-green-800" }
  }

  const getOrderStatusColor = (status: string) => {
    switch (status) {
      case "pending":
        return "bg-yellow-100 text-yellow-800"
      case "confirmed":
        return "bg-blue-100 text-blue-800"
      case "delivered":
        return "bg-green-100 text-green-800"
      case "cancelled":
        return "bg-red-100 text-red-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const getOrderStatusText = (status: string) => {
    switch (status) {
      case "pending":
        return "대기중"
      case "confirmed":
        return "확인됨"
      case "delivered":
        return "배송완료"
      case "cancelled":
        return "취소됨"
      default:
        return status
    }
  }

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">통합 관리 시스템</h1>
          <p className="text-gray-600">사용자, 품목, 재고를 효율적으로 관리하세요</p>
        </div>

        {/* Navigation Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-4 mb-6">
            <TabsTrigger value="users" className="flex items-center gap-2">
              <Users className="w-4 h-4" />
              사용자 관리
            </TabsTrigger>
            <TabsTrigger value="products" className="flex items-center gap-2">
              <Package className="w-4 h-4" />
              품목 관리
            </TabsTrigger>
            <TabsTrigger value="inventory" className="flex items-center gap-2">
              <BarChart3 className="w-4 h-4" />
              재고/주문 관리
            </TabsTrigger>
            <TabsTrigger value="analytics" className="flex items-center gap-2">
              <BarChart3 className="w-4 h-4" />
              분석
            </TabsTrigger>
          </TabsList>

          {/* Users Management Tab */}
          <TabsContent value="users" className="space-y-6">
            {/* Controls */}
            <div className="flex flex-col sm:flex-row gap-4 justify-between items-start sm:items-center">
              <div className="flex gap-2 flex-1 max-w-md">
                <div className="relative flex-1">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                  <Input
                    placeholder="이름, 사번, 부서로 검색..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10"
                  />
                </div>
              </div>
              <div className="flex gap-2">
                <Button
                  variant="outline"
                  className="flex items-center gap-2 bg-transparent"
                  onClick={() => openCSVUpload("users")}
                >
                  <Upload className="w-4 h-4" />
                  CSV 업로드
                </Button>
                <Button
                  variant="outline"
                  className="flex items-center gap-2 bg-transparent"
                  onClick={() => handleCSVDownload("users")}
                >
                  <Download className="w-4 h-4" />
                  CSV 다운로드
                </Button>
                <Dialog open={isAddUserOpen} onOpenChange={setIsAddUserOpen}>
                  <DialogTrigger asChild>
                    <Button className="flex items-center gap-2" onClick={resetForm}>
                      <Plus className="w-4 h-4" />
                      사용자 추가
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
                    <DialogHeader>
                      <DialogTitle>{editingUser ? "사용자 정보 수정" : "새 사용자 추가"}</DialogTitle>
                      <DialogDescription>
                        사용자의 기본 정보와 건강 정보를 입력하세요. BMI는 자동으로 계산됩니다.
                      </DialogDescription>
                    </DialogHeader>
                    <form onSubmit={handleSubmit} className="space-y-6">
                      {/* Basic Information */}
                      <div className="space-y-4">
                        <h3 className="text-lg font-semibold">기본 정보</h3>
                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <Label htmlFor="name">이름 *</Label>
                            <Input
                              id="name"
                              value={formData.name}
                              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                              required
                            />
                          </div>
                          <div>
                            <Label htmlFor="employee_id">사번 *</Label>
                            <Input
                              id="employee_id"
                              value={formData.employee_id}
                              onChange={(e) => setFormData({ ...formData, employee_id: e.target.value })}
                              required
                            />
                          </div>
                          <div>
                            <Label htmlFor="department">부서</Label>
                            <Input
                              id="department"
                              value={formData.department}
                              onChange={(e) => setFormData({ ...formData, department: e.target.value })}
                            />
                          </div>
                          <div>
                            <Label htmlFor="position">직급</Label>
                            <Input
                              id="position"
                              value={formData.position}
                              onChange={(e) => setFormData({ ...formData, position: e.target.value })}
                            />
                          </div>
                          <div>
                            <Label htmlFor="email">이메일</Label>
                            <Input
                              id="email"
                              type="email"
                              value={formData.email}
                              onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                            />
                          </div>
                          <div>
                            <Label htmlFor="phone">전화번호</Label>
                            <Input
                              id="phone"
                              value={formData.phone}
                              onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                            />
                          </div>
                          <div>
                            <Label htmlFor="birth_date">생년월일</Label>
                            <Input
                              id="birth_date"
                              type="date"
                              value={formData.birth_date}
                              onChange={(e) => setFormData({ ...formData, birth_date: e.target.value })}
                            />
                          </div>
                          <div>
                            <Label htmlFor="gender">성별</Label>
                            <Select
                              value={formData.gender}
                              onValueChange={(value) => setFormData({ ...formData, gender: value })}
                            >
                              <SelectTrigger>
                                <SelectValue placeholder="성별 선택" />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="남성">남성</SelectItem>
                                <SelectItem value="여성">여성</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>
                        </div>
                      </div>

                      {/* Health Information */}
                      <div className="space-y-4">
                        <h3 className="text-lg font-semibold">건강 정보</h3>
                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <Label htmlFor="height">신장 (cm)</Label>
                            <Input
                              id="height"
                              type="number"
                              value={formData.height}
                              onChange={(e) => setFormData({ ...formData, height: e.target.value })}
                              placeholder="170"
                            />
                          </div>
                          <div>
                            <Label htmlFor="weight">체중 (kg)</Label>
                            <Input
                              id="weight"
                              type="number"
                              value={formData.weight}
                              onChange={(e) => setFormData({ ...formData, weight: e.target.value })}
                              placeholder="70"
                            />
                          </div>
                        </div>
                        {formData.height && formData.weight && (
                          <div className="p-3 bg-blue-50 rounded-lg">
                            <p className="text-sm text-blue-800">
                              계산된 BMI:{" "}
                              <span className="font-semibold">
                                {calculateBMI(Number.parseFloat(formData.height), Number.parseFloat(formData.weight))}
                              </span>
                            </p>
                          </div>
                        )}
                        <div className="space-y-3">
                          <div className="flex items-center space-x-2">
                            <Checkbox
                              id="diabetes"
                              checked={formData.diabetes}
                              onCheckedChange={(checked) => setFormData({ ...formData, diabetes: checked as boolean })}
                            />
                            <Label htmlFor="diabetes">당뇨병</Label>
                          </div>
                          <div className="flex items-center space-x-2">
                            <Checkbox
                              id="hypertension"
                              checked={formData.hypertension}
                              onCheckedChange={(checked) =>
                                setFormData({ ...formData, hypertension: checked as boolean })
                              }
                            />
                            <Label htmlFor="hypertension">고혈압</Label>
                          </div>
                        </div>
                        <div>
                          <Label htmlFor="allergies">알레르기</Label>
                          <Textarea
                            id="allergies"
                            value={formData.allergies}
                            onChange={(e) => setFormData({ ...formData, allergies: e.target.value })}
                            placeholder="견과류, 새우 등"
                          />
                        </div>
                        <div>
                          <Label htmlFor="dietary_restrictions">식이 제한</Label>
                          <Textarea
                            id="dietary_restrictions"
                            value={formData.dietary_restrictions}
                            onChange={(e) => setFormData({ ...formData, dietary_restrictions: e.target.value })}
                            placeholder="비건, 할랄 등"
                          />
                        </div>
                      </div>

                      <div className="flex justify-end gap-2 pt-4">
                        <Button type="button" variant="outline" onClick={() => setIsAddUserOpen(false)}>
                          취소
                        </Button>
                        <Button type="submit" disabled={loading}>
                          {loading ? "저장 중..." : editingUser ? "수정" : "추가"}
                        </Button>
                      </div>
                    </form>
                  </DialogContent>
                </Dialog>
              </div>
            </div>

            {/* Users Table */}
            <Card>
              <CardHeader>
                <CardTitle>사용자 목록</CardTitle>
                <CardDescription>등록된 사용자들의 정보와 건강 데이터를 관리하세요</CardDescription>
              </CardHeader>
              <CardContent>
                {loading ? (
                  <div className="flex justify-center py-8">
                    <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
                  </div>
                ) : (
                  <div className="space-y-4">
                    <div className="grid gap-4">
                      {users.map((user) => {
                        const bmiStatus = getBMIStatus(user.bmi)
                        return (
                          <Card key={user.id} className="p-4">
                            <div className="flex justify-between items-start">
                              <div className="space-y-2 flex-1">
                                <div className="flex items-center gap-3">
                                  <h3 className="font-semibold text-lg">{user.name}</h3>
                                  <Badge variant="outline">{user.employee_id}</Badge>
                                  {user.bmi && (
                                    <Badge className={bmiStatus.color}>
                                      BMI {user.bmi} ({bmiStatus.status})
                                    </Badge>
                                  )}
                                </div>
                                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm text-gray-600">
                                  <div>
                                    <span className="font-medium">부서:</span> {user.department}
                                  </div>
                                  <div>
                                    <span className="font-medium">직급:</span> {user.position}
                                  </div>
                                  <div>
                                    <span className="font-medium">이메일:</span> {user.email}
                                  </div>
                                  <div>
                                    <span className="font-medium">전화:</span> {user.phone}
                                  </div>
                                </div>
                                {(user.diabetes || user.hypertension || user.allergies) && (
                                  <div className="flex gap-2 mt-2">
                                    {user.diabetes && <Badge variant="destructive">당뇨병</Badge>}
                                    {user.hypertension && <Badge variant="destructive">고혈압</Badge>}
                                    {user.allergies && <Badge variant="secondary">알레르기: {user.allergies}</Badge>}
                                  </div>
                                )}
                              </div>
                              <div className="flex gap-2">
                                <Button variant="outline" size="sm" onClick={() => handleEditUser(user)}>
                                  <Edit className="w-4 h-4" />
                                </Button>
                                <Button variant="outline" size="sm" onClick={() => handleDeleteUser(user.id)}>
                                  <Trash2 className="w-4 h-4" />
                                </Button>
                              </div>
                            </div>
                          </Card>
                        )
                      })}
                    </div>

                    {/* Pagination */}
                    {totalPages > 1 && (
                      <div className="flex justify-center gap-2 mt-6">
                        <Button
                          variant="outline"
                          onClick={() => setCurrentPage((prev) => Math.max(1, prev - 1))}
                          disabled={currentPage === 1}
                        >
                          이전
                        </Button>
                        <span className="flex items-center px-4">
                          {currentPage} / {totalPages}
                        </span>
                        <Button
                          variant="outline"
                          onClick={() => setCurrentPage((prev) => Math.min(totalPages, prev + 1))}
                          disabled={currentPage === totalPages}
                        >
                          다음
                        </Button>
                      </div>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="products" className="space-y-6">
            {/* Product Controls */}
            <div className="flex flex-col sm:flex-row gap-4 justify-between items-start sm:items-center">
              <div className="flex gap-2 flex-1 max-w-2xl">
                <div className="relative flex-1">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                  <Input
                    placeholder="품목명, 브랜드, 바코드로 검색..."
                    value={productSearchTerm}
                    onChange={(e) => setProductSearchTerm(e.target.value)}
                    className="pl-10"
                  />
                </div>
                <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                  <SelectTrigger className="w-40">
                    <SelectValue placeholder="카테고리" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">전체</SelectItem>
                    <SelectItem value="스낵">스낵</SelectItem>
                    <SelectItem value="음료">음료</SelectItem>
                    <SelectItem value="과자">과자</SelectItem>
                    <SelectItem value="건강식품">건강식품</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="flex gap-2">
                <Button
                  variant="outline"
                  className="flex items-center gap-2 bg-transparent"
                  onClick={() => openCSVUpload("products")}
                >
                  <Upload className="w-4 h-4" />
                  CSV 업로드
                </Button>
                <Button
                  variant="outline"
                  className="flex items-center gap-2 bg-transparent"
                  onClick={() => handleCSVDownload("products")}
                >
                  <Download className="w-4 h-4" />
                  CSV 다운로드
                </Button>
                <Dialog open={isAddProductOpen} onOpenChange={setIsAddProductOpen}>
                  <DialogTrigger asChild>
                    <Button className="flex items-center gap-2" onClick={resetProductForm}>
                      <Plus className="w-4 h-4" />
                      품목 추가
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
                    <DialogHeader>
                      <DialogTitle>{editingProduct ? "품목 정보 수정" : "새 품목 추가"}</DialogTitle>
                      <DialogDescription>품목의 기본 정보와 영양 정보를 입력하세요.</DialogDescription>
                    </DialogHeader>
                    <form onSubmit={handleProductSubmit} className="space-y-6">
                      {/* Basic Information */}
                      <div className="space-y-4">
                        <h3 className="text-lg font-semibold">기본 정보</h3>
                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <Label htmlFor="name">품목명 *</Label>
                            <Input
                              id="name"
                              value={productFormData.name}
                              onChange={(e) => setProductFormData({ ...productFormData, name: e.target.value })}
                              required
                            />
                          </div>
                          <div>
                            <Label htmlFor="category">카테고리 *</Label>
                            <Input
                              id="category"
                              value={productFormData.category}
                              onChange={(e) => setProductFormData({ ...productFormData, category: e.target.value })}
                              required
                            />
                          </div>
                          <div>
                            <Label htmlFor="brand">브랜드</Label>
                            <Input
                              id="brand"
                              value={productFormData.brand}
                              onChange={(e) => setProductFormData({ ...productFormData, brand: e.target.value })}
                            />
                          </div>
                          <div>
                            <Label htmlFor="barcode">바코드</Label>
                            <Input
                              id="barcode"
                              value={productFormData.barcode}
                              onChange={(e) => setProductFormData({ ...productFormData, barcode: e.target.value })}
                            />
                          </div>
                          <div>
                            <Label htmlFor="price">가격 (원)</Label>
                            <Input
                              id="price"
                              type="number"
                              value={productFormData.price}
                              onChange={(e) => setProductFormData({ ...productFormData, price: e.target.value })}
                              placeholder="1000"
                            />
                          </div>
                        </div>
                      </div>

                      {/* Nutritional Information */}
                      <div className="space-y-4">
                        <h3 className="text-lg font-semibold">영양 정보</h3>
                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <Label htmlFor="calories_per_100g">100g당 칼로리 (kcal)</Label>
                            <Input
                              id="calories_per_100g"
                              type="number"
                              value={productFormData.calories_per_100g}
                              onChange={(e) =>
                                setProductFormData({ ...productFormData, calories_per_100g: e.target.value })
                              }
                              placeholder="50"
                            />
                          </div>
                          <div>
                            <Label htmlFor="protein_per_100g">100g당 단백질 (g)</Label>
                            <Input
                              id="protein_per_100g"
                              type="number"
                              value={productFormData.protein_per_100g}
                              onChange={(e) =>
                                setProductFormData({ ...productFormData, protein_per_100g: e.target.value })
                              }
                              placeholder="10"
                            />
                          </div>
                          <div>
                            <Label htmlFor="fat_per_100g">100g당 지방 (g)</Label>
                            <Input
                              id="fat_per_100g"
                              type="number"
                              value={productFormData.fat_per_100g}
                              onChange={(e) => setProductFormData({ ...productFormData, fat_per_100g: e.target.value })}
                              placeholder="5"
                            />
                          </div>
                          <div>
                            <Label htmlFor="carbs_per_100g">100g당 탄수화물 (g)</Label>
                            <Input
                              id="carbs_per_100g"
                              type="number"
                              value={productFormData.carbs_per_100g}
                              onChange={(e) =>
                                setProductFormData({ ...productFormData, carbs_per_100g: e.target.value })
                              }
                              placeholder="20"
                            />
                          </div>
                          <div>
                            <Label htmlFor="sodium_per_100g">100g당 나트륨 (mg)</Label>
                            <Input
                              id="sodium_per_100g"
                              type="number"
                              value={productFormData.sodium_per_100g}
                              onChange={(e) =>
                                setProductFormData({ ...productFormData, sodium_per_100g: e.target.value })
                              }
                              placeholder="150"
                            />
                          </div>
                          <div>
                            <Label htmlFor="sugar">당분 (g)</Label>
                            <Input
                              id="sugar"
                              type="number"
                              value={productFormData.sugar}
                              onChange={(e) => setProductFormData({ ...productFormData, sugar: e.target.value })}
                              placeholder="10"
                            />
                          </div>
                          <div>
                            <Label htmlFor="serving_size">분량 (g)</Label>
                            <Input
                              id="serving_size"
                              type="number"
                              value={productFormData.serving_size}
                              onChange={(e) => setProductFormData({ ...productFormData, serving_size: e.target.value })}
                              placeholder="100"
                            />
                          </div>
                        </div>
                      </div>

                      {/* Additional Information */}
                      <div className="space-y-4">
                        <h3 className="text-lg font-semibold">추가 정보</h3>
                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <Label htmlFor="health_rating">건강 등급</Label>
                            <Input
                              id="health_rating"
                              value={productFormData.health_rating}
                              onChange={(e) =>
                                setProductFormData({ ...productFormData, health_rating: e.target.value })
                              }
                              placeholder="매우좋음"
                            />
                          </div>
                          <div>
                            <Label htmlFor="allergens">알레르겐</Label>
                            <Input
                              id="allergens"
                              value={productFormData.allergens}
                              onChange={(e) => setProductFormData({ ...productFormData, allergens: e.target.value })}
                              placeholder="견과류, 새우 등"
                            />
                          </div>
                        </div>
                        <div>
                          <Label htmlFor="ingredients">성분</Label>
                          <Textarea
                            id="ingredients"
                            value={productFormData.ingredients}
                            onChange={(e) => setProductFormData({ ...productFormData, ingredients: e.target.value })}
                            placeholder="물, 설탕, 카페인 등"
                          />
                        </div>
                        <div>
                          <Label htmlFor="image_url">이미지 URL</Label>
                          <Input
                            id="image_url"
                            value={productFormData.image_url}
                            onChange={(e) => setProductFormData({ ...productFormData, image_url: e.target.value })}
                            placeholder="https://example.com/image.jpg"
                          />
                        </div>
                      </div>

                      <div className="flex justify-end gap-2 pt-4">
                        <Button type="button" variant="outline" onClick={() => setIsAddProductOpen(false)}>
                          취소
                        </Button>
                        <Button type="submit" disabled={loading}>
                          {loading ? "저장 중..." : editingProduct ? "수정" : "추가"}
                        </Button>
                      </div>
                    </form>
                  </DialogContent>
                </Dialog>
              </div>
            </div>

            {/* Products Table */}
            <Card>
              <CardHeader>
                <CardTitle>품목 목록</CardTitle>
                <CardDescription>등록된 품목들의 정보와 영양 데이터를 관리하세요</CardDescription>
              </CardHeader>
              <CardContent>
                {loading ? (
                  <div className="flex justify-center py-8">
                    <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
                  </div>
                ) : (
                  <div className="space-y-4">
                    <div className="grid gap-4">
                      {products.map((product) => (
                        <Card key={product.id} className="p-4">
                          <div className="flex justify-between items-start">
                            <div className="space-y-2 flex-1">
                              <div className="flex items-center gap-3">
                                <h3 className="font-semibold text-lg">{product.name}</h3>
                                <Badge variant="outline">{product.category}</Badge>
                              </div>
                              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm text-gray-600">
                                <div>
                                  <span className="font-medium">브랜드:</span> {product.brand}
                                </div>
                                <div>
                                  <span className="font-medium">바코드:</span> {product.barcode}
                                </div>
                                <div>
                                  <span className="font-medium">가격:</span> {product.price} 원
                                </div>
                                <div>
                                  <span className="font-medium">100g당 칼로리:</span> {product.calories_per_100g} kcal
                                </div>
                              </div>
                              <div className="flex gap-2 mt-2">
                                <Badge className={getHealthRatingColor(product.health_rating)}>
                                  {product.health_rating}
                                </Badge>
                              </div>
                            </div>
                            <div className="flex gap-2">
                              <Button variant="outline" size="sm" onClick={() => handleEditProduct(product)}>
                                <Edit className="w-4 h-4" />
                              </Button>
                              <Button variant="outline" size="sm" onClick={() => handleDeleteProduct(product.id)}>
                                <Trash2 className="w-4 h-4" />
                              </Button>
                            </div>
                          </div>
                        </Card>
                      ))}
                    </div>

                    {/* Pagination */}
                    {productTotalPages > 1 && (
                      <div className="flex justify-center gap-2 mt-6">
                        <Button
                          variant="outline"
                          onClick={() => setProductCurrentPage((prev) => Math.max(1, prev - 1))}
                          disabled={productCurrentPage === 1}
                        >
                          이전
                        </Button>
                        <span className="flex items-center px-4">
                          {productCurrentPage} / {productTotalPages}
                        </span>
                        <Button
                          variant="outline"
                          onClick={() => setProductCurrentPage((prev) => Math.min(productTotalPages, prev + 1))}
                          disabled={productCurrentPage === productTotalPages}
                        >
                          다음
                        </Button>
                      </div>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="inventory" className="space-y-6">
            {/* Inventory Controls */}
            <div className="flex flex-col sm:flex-row gap-4 justify-between items-start sm:items-center">
              <div className="flex gap-2 flex-1 max-w-md">
                <div className="relative flex-1">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                  <Input
                    placeholder="품목명, 공급업체로 검색..."
                    value={inventorySearchTerm}
                    onChange={(e) => setInventorySearchTerm(e.target.value)}
                    className="pl-10"
                  />
                </div>
              </div>
              <div className="flex gap-2">
                <Button
                  variant="outline"
                  className="flex items-center gap-2 bg-transparent"
                  onClick={() => openCSVUpload("inventory")}
                >
                  <Upload className="w-4 h-4" />
                  CSV 업로드
                </Button>
                <Button
                  variant="outline"
                  className="flex items-center gap-2 bg-transparent"
                  onClick={() => handleCSVDownload("inventory")}
                >
                  <Download className="w-4 h-4" />
                  CSV 다운로드
                </Button>
                <Dialog open={isAddInventoryOpen} onOpenChange={setIsAddInventoryOpen}>
                  <DialogTrigger asChild>
                    <Button className="flex items-center gap-2" onClick={resetInventoryForm}>
                      <Plus className="w-4 h-4" />
                      재고 추가
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
                    <DialogHeader>
                      <DialogTitle>{editingInventory ? "재고 정보 수정" : "새 재고 추가"}</DialogTitle>
                      <DialogDescription>재고의 기본 정보를 입력하세요.</DialogDescription>
                    </DialogHeader>
                    <form onSubmit={handleInventorySubmit} className="space-y-6">
                      {/* Basic Information */}
                      <div className="space-y-4">
                        <h3 className="text-lg font-semibold">기본 정보</h3>
                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <Label htmlFor="product_id">품목 ID *</Label>
                            <Input
                              id="product_id"
                              value={inventoryFormData.product_id}
                              onChange={(e) =>
                                setInventoryFormData({ ...inventoryFormData, product_id: e.target.value })
                              }
                              required
                            />
                          </div>
                          <div>
                            <Label htmlFor="product_name">품목명 *</Label>
                            <Input
                              id="product_name"
                              value={inventoryFormData.product_name}
                              onChange={(e) =>
                                setInventoryFormData({ ...inventoryFormData, product_name: e.target.value })
                              }
                              required
                            />
                          </div>
                          <div>
                            <Label htmlFor="current_stock">현재 재고 *</Label>
                            <Input
                              id="current_stock"
                              type="number"
                              value={inventoryFormData.current_stock}
                              onChange={(e) =>
                                setInventoryFormData({ ...inventoryFormData, current_stock: e.target.value })
                              }
                              placeholder="50"
                              required
                            />
                          </div>
                          <div>
                            <Label htmlFor="minimum_stock">최소 재고 *</Label>
                            <Input
                              id="minimum_stock"
                              type="number"
                              value={inventoryFormData.minimum_stock}
                              onChange={(e) =>
                                setInventoryFormData({ ...inventoryFormData, minimum_stock: e.target.value })
                              }
                              placeholder="20"
                              required
                            />
                          </div>
                          <div>
                            <Label htmlFor="maximum_stock">최대 재고 *</Label>
                            <Input
                              id="maximum_stock"
                              type="number"
                              value={inventoryFormData.maximum_stock}
                              onChange={(e) =>
                                setInventoryFormData({ ...inventoryFormData, maximum_stock: e.target.value })
                              }
                              placeholder="100"
                              required
                            />
                          </div>
                          <div>
                            <Label htmlFor="reorder_point">재고 재주문 점 *</Label>
                            <Input
                              id="reorder_point"
                              type="number"
                              value={inventoryFormData.reorder_point}
                              onChange={(e) =>
                                setInventoryFormData({ ...inventoryFormData, reorder_point: e.target.value })
                              }
                              placeholder="30"
                              required
                            />
                          </div>
                          <div>
                            <Label htmlFor="location">위치</Label>
                            <Input
                              id="location"
                              value={inventoryFormData.location}
                              onChange={(e) => setInventoryFormData({ ...inventoryFormData, location: e.target.value })}
                              placeholder="창고 A"
                            />
                          </div>
                          <div>
                            <Label htmlFor="expiry_date">유통기한</Label>
                            <Input
                              id="expiry_date"
                              type="date"
                              value={inventoryFormData.expiry_date}
                              onChange={(e) =>
                                setInventoryFormData({ ...inventoryFormData, expiry_date: e.target.value })
                              }
                            />
                          </div>
                          <div>
                            <Label htmlFor="supplier">공급업체 *</Label>
                            <Input
                              id="supplier"
                              value={inventoryFormData.supplier}
                              onChange={(e) => setInventoryFormData({ ...inventoryFormData, supplier: e.target.value })}
                              required
                            />
                          </div>
                          <div>
                            <Label htmlFor="cost_per_unit">단위당 비용 (원)</Label>
                            <Input
                              id="cost_per_unit"
                              type="number"
                              value={inventoryFormData.cost_per_unit}
                              onChange={(e) =>
                                setInventoryFormData({ ...inventoryFormData, cost_per_unit: e.target.value })
                              }
                              placeholder="500"
                            />
                          </div>
                        </div>
                      </div>

                      <div className="flex justify-end gap-2 pt-4">
                        <Button type="button" variant="outline" onClick={() => setIsAddInventoryOpen(false)}>
                          취소
                        </Button>
                        <Button type="submit" disabled={loading}>
                          {loading ? "저장 중..." : editingInventory ? "수정" : "추가"}
                        </Button>
                      </div>
                    </form>
                  </DialogContent>
                </Dialog>
              </div>
            </div>

            {/* Inventory Table */}
            <Card>
              <CardHeader>
                <CardTitle>재고 목록</CardTitle>
                <CardDescription>등록된 재고 항목들을 관리하세요</CardDescription>
              </CardHeader>
              <CardContent>
                {loading ? (
                  <div className="flex justify-center py-8">
                    <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
                  </div>
                ) : (
                  <div className="space-y-4">
                    <div className="grid gap-4">
                      {inventory.map((item) => {
                        const stockStatus = getStockStatus(item.current_stock, item.minimum_stock, item.reorder_point)
                        return (
                          <Card key={item.id} className="p-4">
                            <div className="flex justify-between items-start">
                              <div className="space-y-2 flex-1">
                                <div className="flex items-center gap-3">
                                  <h3 className="font-semibold text-lg">{item.product_name}</h3>
                                  <Badge variant="outline">{item.supplier}</Badge>
                                  <Badge className={stockStatus.color}>{stockStatus.status}</Badge>
                                </div>
                                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm text-gray-600">
                                  <div>
                                    <span className="font-medium">현재 재고:</span> {item.current_stock}
                                  </div>
                                  <div>
                                    <span className="font-medium">최소 재고:</span> {item.minimum_stock}
                                  </div>
                                  <div>
                                    <span className="font-medium">최대 재고:</span> {item.maximum_stock}
                                  </div>
                                  <div>
                                    <span className="font-medium">재고 재주문 점:</span> {item.reorder_point}
                                  </div>
                                </div>
                              </div>
                              <div className="flex gap-2">
                                <Button variant="outline" size="sm" onClick={() => handleEditInventory(item)}>
                                  <Edit className="w-4 h-4" />
                                </Button>
                              </div>
                            </div>
                          </Card>
                        )
                      })}
                    </div>

                    {/* Pagination */}
                    {inventoryTotalPages > 1 && (
                      <div className="flex justify-center gap-2 mt-6">
                        <Button
                          variant="outline"
                          onClick={() => setInventoryCurrentPage((prev) => Math.max(1, prev - 1))}
                          disabled={inventoryCurrentPage === 1}
                        >
                          이전
                        </Button>
                        <span className="flex items-center px-4">
                          {inventoryCurrentPage} / {inventoryTotalPages}
                        </span>
                        <Button
                          variant="outline"
                          onClick={() => setInventoryCurrentPage((prev) => Math.min(inventoryTotalPages, prev + 1))}
                          disabled={inventoryCurrentPage === inventoryTotalPages}
                        >
                          다음
                        </Button>
                      </div>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="analytics" className="space-y-6">
            {/* Analytics Content */}
            <div className="flex flex-col sm:flex-row gap-4 justify-between items-start sm:items-center">
              <div className="flex gap-2 flex-1 max-w-md">
                <div className="relative flex-1">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                  <Input
                    placeholder="분석 검색..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10"
                  />
                </div>
              </div>
              <div className="flex gap-2">{/* Additional buttons or controls for analytics can be added here */}</div>
            </div>

            {/* Analytics Table */}
            <Card>
              <CardHeader>
                <CardTitle>분석 결과</CardTitle>
                <CardDescription>사용자와 품목의 분석 데이터를 확인하세요</CardDescription>
              </CardHeader>
              <CardContent>
                {/* Placeholder for analytics table */}
                <p className="text-gray-600">분석 데이터가 여기에 표시됩니다.</p>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
