import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const { message, user } = await request.json()

    if (!message || !user) {
      return NextResponse.json({ error: "메시지와 사용자 정보가 필요합니다." }, { status: 400 })
    }

    const misoEndpoint = process.env.MISO_ENDPOINT
    const misoApiKey = process.env.MISO_API_KEY

    if (!misoEndpoint || !misoApiKey) {
      return NextResponse.json({ error: "MISO API 설정이 필요합니다." }, { status: 500 })
    }

    const response = await fetch(`${misoEndpoint}/workflows/run`, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${misoApiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        inputs: {
          query: message,
        },
        mode: "streaming",
        user: user,
      }),
    })

    if (!response.ok) {
      throw new Error(`MISO API 오류: ${response.status}`)
    }

    const encoder = new TextEncoder()
    const stream = new ReadableStream({
      async start(controller) {
        const reader = response.body?.getReader()
        if (!reader) {
          controller.close()
          return
        }

        const decoder = new TextDecoder()

        try {
          while (true) {
            const { done, value } = await reader.read()
            if (done) break

            const chunk = decoder.decode(value)
            const lines = chunk.split("\n")

            for (const line of lines) {
              if (line.startsWith("data: ")) {
                try {
                  const data = JSON.parse(line.slice(6))

                  // MISO API 응답 형식에 맞게 처리
                  if (data.event === "message" && data.answer) {
                    const sseData = `data: ${JSON.stringify({
                      event: "message",
                      answer: data.answer,
                    })}\n\n`
                    controller.enqueue(encoder.encode(sseData))
                  } else if (data.event === "message_end") {
                    const sseData = `data: ${JSON.stringify({
                      event: "message_end",
                    })}\n\n`
                    controller.enqueue(encoder.encode(sseData))
                  }
                } catch (e) {
                  // JSON 파싱 오류 무시
                }
              }
            }
          }
        } catch (error) {
          console.error("스트림 처리 오류:", error)
        } finally {
          controller.close()
        }
      },
    })

    return new Response(stream, {
      headers: {
        "Content-Type": "text/event-stream",
        "Cache-Control": "no-cache",
        Connection: "keep-alive",
      },
    })
  } catch (error) {
    console.error("챗봇 API 오류:", error)
    return NextResponse.json({ error: "챗봇 서비스에 일시적인 문제가 발생했습니다." }, { status: 500 })
  }
}
