import { type NextRequest, NextResponse } from "next/server"
import { getProducts, createProduct, updateProduct, deleteProduct, type Product } from "@/lib/file-storage"

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const page = Number.parseInt(searchParams.get("page") || "1")
    const limit = Number.parseInt(searchParams.get("limit") || "10")
    const search = searchParams.get("search") || ""
    const category = searchParams.get("category") || ""

    const products = await getProducts()
    let filteredProducts = products

    if (search) {
      filteredProducts = products.filter(
        (product) =>
          product.name.includes(search) || product.brand.includes(search) || product.barcode.includes(search),
      )
    }
    if (category) {
      filteredProducts = filteredProducts.filter((product) => product.category === category)
    }

    const startIndex = (page - 1) * limit
    const endIndex = startIndex + limit
    const paginatedProducts = filteredProducts.slice(startIndex, endIndex)

    return NextResponse.json({
      products: paginatedProducts,
      total: filteredProducts.length,
      page,
      totalPages: Math.ceil(filteredProducts.length / limit),
    })
  } catch (error) {
    return NextResponse.json({ error: "Failed to fetch products" }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const productData = await request.json()

    let caloriesPerServing = 0
    let proteinPercent = 0
    let fatPercent = 0
    let carbsPercent = 0
    let healthRating = 1

    if (productData.servingSize && productData.calories) {
      caloriesPerServing = Math.round((productData.calories * productData.servingSize) / 100)
    }

    if (productData.calories) {
      if (productData.protein) {
        proteinPercent = Math.round(((productData.protein * 4 * 100) / productData.calories) * 100) / 100
      }
      if (productData.fat) {
        fatPercent = Math.round(((productData.fat * 9 * 100) / productData.calories) * 100) / 100
      }
      if (productData.carbs) {
        carbsPercent = Math.round(((productData.carbs * 4 * 100) / productData.calories) * 100) / 100
      }

      // Calculate health rating based on nutritional content
      if (productData.calories < 300 && productData.sugar < 10 && productData.sodium < 500) {
        healthRating = 5
      } else if (productData.calories < 400 && productData.sugar < 15 && productData.sodium < 800) {
        healthRating = 4
      } else if (productData.calories < 500 && productData.sugar < 20 && productData.sodium < 1000) {
        healthRating = 3
      } else if (productData.calories < 600) {
        healthRating = 2
      }
    }

    const newProduct = await createProduct({
      name: productData.name,
      category: productData.category,
      barcode: productData.barcode,
      brand: productData.brand,
      servingSize: productData.servingSize,
      servingUnit: productData.servingUnit,
      calories: productData.calories,
      caloriesPerServing,
      protein: productData.protein,
      fat: productData.fat,
      carbs: productData.carbs,
      sugar: productData.sugar,
      sodium: productData.sodium,
      fiber: productData.fiber,
      proteinPercent,
      fatPercent,
      carbsPercent,
      healthRating,
      imageUrl: productData.imageUrl || "",
    })

    return NextResponse.json(newProduct, { status: 201 })
  } catch (error) {
    return NextResponse.json({ error: "Failed to create product" }, { status: 500 })
  }
}

export async function PUT(request: NextRequest) {
  try {
    const productData = await request.json()

    const updateData: Partial<Product> = { ...productData }

    if (productData.servingSize && productData.calories) {
      updateData.caloriesPerServing = Math.round((productData.calories * productData.servingSize) / 100)
    }

    if (productData.calories) {
      if (productData.protein) {
        updateData.proteinPercent = Math.round(((productData.protein * 4 * 100) / productData.calories) * 100) / 100
      }
      if (productData.fat) {
        updateData.fatPercent = Math.round(((productData.fat * 9 * 100) / productData.calories) * 100) / 100
      }
      if (productData.carbs) {
        updateData.carbsPercent = Math.round(((productData.carbs * 4 * 100) / productData.calories) * 100) / 100
      }

      // Recalculate health rating
      let healthRating = 1
      if (productData.calories < 300 && productData.sugar < 10 && productData.sodium < 500) {
        healthRating = 5
      } else if (productData.calories < 400 && productData.sugar < 15 && productData.sodium < 800) {
        healthRating = 4
      } else if (productData.calories < 500 && productData.sugar < 20 && productData.sodium < 1000) {
        healthRating = 3
      } else if (productData.calories < 600) {
        healthRating = 2
      }
      updateData.healthRating = healthRating
    }

    const updatedProduct = await updateProduct(productData.id, updateData)

    if (!updatedProduct) {
      return NextResponse.json({ error: "Product not found" }, { status: 404 })
    }

    return NextResponse.json(updatedProduct)
  } catch (error) {
    return NextResponse.json({ error: "Failed to update product" }, { status: 500 })
  }
}

export async function DELETE(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const id = searchParams.get("id")

    if (!id) {
      return NextResponse.json({ error: "Product ID is required" }, { status: 400 })
    }

    const deleted = await deleteProduct(id)

    if (!deleted) {
      return NextResponse.json({ error: "Product not found" }, { status: 404 })
    }

    return NextResponse.json({ message: "Product deleted successfully" })
  } catch (error) {
    return NextResponse.json({ error: "Failed to delete product" }, { status: 500 })
  }
}
