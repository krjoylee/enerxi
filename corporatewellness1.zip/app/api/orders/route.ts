import { type NextRequest, NextResponse } from "next/server"
import { getOrders, createOrder, updateOrder, deleteOrder, getOrderById } from "@/lib/file-storage"

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const id = searchParams.get("id")

    if (id) {
      const order = await getOrderById(id)
      if (!order) {
        return NextResponse.json({ error: "Order not found" }, { status: 404 })
      }
      return NextResponse.json(order)
    }

    const orders = await getOrders()
    return NextResponse.json(orders)
  } catch (error) {
    console.error("Error fetching orders:", error)
    return NextResponse.json({ error: "Failed to fetch orders" }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const orderData = await request.json()

    // Generate order number if not provided
    if (!orderData.orderNumber) {
      const orders = await getOrders()
      const orderCount = orders.length + 1
      orderData.orderNumber = `ORD-${new Date().getFullYear()}-${orderCount.toString().padStart(3, "0")}`
    }

    // Calculate total amount
    orderData.totalAmount = orderData.quantity * orderData.unitPrice

    const newOrder = await createOrder(orderData)
    return NextResponse.json(newOrder, { status: 201 })
  } catch (error) {
    console.error("Error creating order:", error)
    return NextResponse.json({ error: "Failed to create order" }, { status: 500 })
  }
}

export async function PUT(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const id = searchParams.get("id")

    if (!id) {
      return NextResponse.json({ error: "Order ID is required" }, { status: 400 })
    }

    const orderData = await request.json()

    // Recalculate total amount if quantity or unit price changed
    if (orderData.quantity && orderData.unitPrice) {
      orderData.totalAmount = orderData.quantity * orderData.unitPrice
    }

    const updatedOrder = await updateOrder(id, orderData)

    if (!updatedOrder) {
      return NextResponse.json({ error: "Order not found" }, { status: 404 })
    }

    return NextResponse.json(updatedOrder)
  } catch (error) {
    console.error("Error updating order:", error)
    return NextResponse.json({ error: "Failed to update order" }, { status: 500 })
  }
}

export async function DELETE(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const id = searchParams.get("id")

    if (!id) {
      return NextResponse.json({ error: "Order ID is required" }, { status: 400 })
    }

    const deleted = await deleteOrder(id)

    if (!deleted) {
      return NextResponse.json({ error: "Order not found" }, { status: 404 })
    }

    return NextResponse.json({ message: "Order deleted successfully" })
  } catch (error) {
    console.error("Error deleting order:", error)
    return NextResponse.json({ error: "Failed to delete order" }, { status: 500 })
  }
}
