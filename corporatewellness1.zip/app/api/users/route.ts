import { type NextRequest, NextResponse } from "next/server"

const USERS_DATA = [
  {
    id: "1",
    name: "김철수",
    employeeId: "EMP001",
    email: "kim.cs@company.com",
    department: "개발팀",
    position: "시니어 개발자",
    age: 32,
    gender: "male" as const,
    height: 175,
    weight: 70,
    bmi: 22.86,
    bmiCategory: "정상",
    diabetes: false,
    hypertension: false,
    allergies: [],
    createdAt: "2024-01-01T00:00:00.000Z",
    updatedAt: "2024-01-01T00:00:00.000Z",
  },
  {
    id: "2",
    name: "이영희",
    employeeId: "EMP002",
    email: "lee.yh@company.com",
    department: "마케팅팀",
    position: "팀장",
    age: 28,
    gender: "female" as const,
    height: 162,
    weight: 55,
    bmi: 20.96,
    bmiCategory: "정상",
    diabetes: false,
    hypertension: false,
    allergies: ["견과류"],
    createdAt: "2024-01-01T00:00:00.000Z",
    updatedAt: "2024-01-01T00:00:00.000Z",
  },
  {
    id: "3",
    name: "박민수",
    employeeId: "EMP003",
    email: "park.ms@company.com",
    department: "인사팀",
    position: "대리",
    age: 35,
    gender: "male" as const,
    height: 180,
    weight: 75,
    bmi: 23.15,
    bmiCategory: "정상",
    diabetes: false,
    hypertension: false,
    allergies: [],
    createdAt: "2024-01-01T00:00:00.000Z",
    updatedAt: "2024-01-01T00:00:00.000Z",
  },
]

export async function GET(request: NextRequest) {
  try {
    console.log("[v0] Starting GET /api/users request")

    const { searchParams } = new URL(request.url)
    const page = Number.parseInt(searchParams.get("page") || "1")
    const limit = Number.parseInt(searchParams.get("limit") || "10")
    const search = searchParams.get("search") || ""
    const employeeId = searchParams.get("employeeId")

    console.log("[v0] Request params - page:", page, "limit:", limit, "search:", search, "employeeId:", employeeId)

    const users = [...USERS_DATA]

    // Check if there are additional users in localStorage (sent via header)
    const localStorageUsers = request.headers.get("x-local-users")
    if (localStorageUsers) {
      try {
        const parsedLocalUsers = JSON.parse(localStorageUsers)
        // Add localStorage users that don't exist in server data
        parsedLocalUsers.forEach((localUser: any) => {
          if (!users.find((u) => u.id === localUser.id)) {
            users.push({
              ...localUser,
              email: localUser.email || `${localUser.employeeId}@company.com`,
              department: localUser.team || localUser.department || "미정",
              position: localUser.position || "직원",
              bmi: localUser.bmi || 0,
              bmiCategory: localUser.bmiCategory || "정상",
              createdAt: localUser.lastUpdated || new Date().toISOString(),
              updatedAt: localUser.lastUpdated || new Date().toISOString(),
            })
          }
        })
      } catch (e) {
        console.log("[v0] Failed to parse localStorage users:", e)
      }
    }

    console.log("[v0] Using merged user data, total users:", users.length)

    if (employeeId) {
      console.log("[v0] Looking for user with employeeId:", employeeId)
      const user = users.find((u) => u.employeeId === employeeId || u.id === employeeId)
      if (user) {
        console.log("[v0] Found user by employeeId:", user.name, "height:", user.height, "weight:", user.weight)
        return NextResponse.json({ users: [user], total: 1, page: 1, totalPages: 1 })
      } else {
        console.log("[v0] No user found for employeeId:", employeeId)
        return NextResponse.json({ users: [], total: 0, page: 1, totalPages: 0 })
      }
    }

    let filteredUsers = users

    if (search) {
      filteredUsers = users.filter(
        (user) => user.name.includes(search) || user.employeeId.includes(search) || user.department.includes(search),
      )
    }

    const startIndex = (page - 1) * limit
    const endIndex = startIndex + limit
    const paginatedUsers = filteredUsers.slice(startIndex, endIndex)

    console.log("[v0] Returning paginated users:", paginatedUsers.length, "users")
    return NextResponse.json({
      users: paginatedUsers,
      total: filteredUsers.length,
      page,
      totalPages: Math.ceil(filteredUsers.length / limit),
    })
  } catch (error) {
    console.error("[v0] Critical error in GET /api/users:", error)
    return NextResponse.json({
      users: USERS_DATA,
      total: USERS_DATA.length,
      page: 1,
      totalPages: 1,
      error: "Using fallback data due to system error",
    })
  }
}

export async function POST(request: NextRequest) {
  try {
    const userData = await request.json()

    let bmi = 0
    let bmiCategory = "정상"

    if (userData.height && userData.weight) {
      bmi = Math.round((userData.weight / Math.pow(userData.height / 100, 2)) * 100) / 100

      if (bmi < 18.5) bmiCategory = "저체중"
      else if (bmi < 25) bmiCategory = "정상"
      else if (bmi < 30) bmiCategory = "과체중"
      else bmiCategory = "비만"
    }

    const newUser = {
      id: String(USERS_DATA.length + 1),
      name: userData.name,
      employeeId: userData.employeeId,
      email: userData.email,
      department: userData.department,
      position: userData.position,
      age: userData.age,
      gender: userData.gender,
      height: userData.height,
      weight: userData.weight,
      bmi,
      bmiCategory,
      diabetes: userData.diabetes || false,
      hypertension: userData.hypertension || false,
      allergies: userData.allergies || [],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    }

    USERS_DATA.push(newUser)

    return NextResponse.json(newUser, { status: 201 })
  } catch (error) {
    return NextResponse.json({ error: "Failed to create user" }, { status: 500 })
  }
}

export async function PUT(request: NextRequest) {
  try {
    console.log("[v0] Starting PUT /api/users request")
    const userData = await request.json()
    console.log("[v0] Received user data for update:", userData)

    const updateData: Partial<(typeof USERS_DATA)[number]> = {
      ...userData,
      height: userData.height ? Number(userData.height) : userData.height,
      weight: userData.weight ? Number(userData.weight) : userData.weight,
      age: userData.age ? Number(userData.age) : userData.age,
    }

    if (updateData.height && updateData.weight) {
      const bmi = Math.round((updateData.weight / Math.pow(updateData.height / 100, 2)) * 100) / 100
      let bmiCategory = "정상"

      if (bmi < 18.5) bmiCategory = "저체중"
      else if (bmi < 25) bmiCategory = "정상"
      else if (bmi < 30) bmiCategory = "과체중"
      else bmiCategory = "비만"

      updateData.bmi = bmi
      updateData.bmiCategory = bmiCategory
      console.log("[v0] Calculated BMI:", bmi, "Category:", bmiCategory)
    }

    const userIndex = USERS_DATA.findIndex((u) => u.id === userData.id)
    console.log("[v0] Looking for user with ID:", userData.id, "Found at index:", userIndex)

    if (userIndex !== -1) {
      const originalUser = { ...USERS_DATA[userIndex] }
      USERS_DATA[userIndex] = { ...USERS_DATA[userIndex], ...updateData, updatedAt: new Date().toISOString() }

      console.log("[v0] User updated successfully")
      console.log("[v0] Original height:", originalUser.height, "New height:", USERS_DATA[userIndex].height)
      console.log("[v0] Original weight:", originalUser.weight, "New weight:", USERS_DATA[userIndex].weight)

      return NextResponse.json(USERS_DATA[userIndex])
    } else {
      console.log("[v0] User not found for update")
      return NextResponse.json({ error: "User not found" }, { status: 404 })
    }
  } catch (error) {
    console.error("[v0] Error in PUT /api/users:", error)
    return NextResponse.json({ error: "Failed to update user" }, { status: 500 })
  }
}

export async function DELETE(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const id = searchParams.get("id")

    if (!id) {
      return NextResponse.json({ error: "User ID is required" }, { status: 400 })
    }

    const userIndex = USERS_DATA.findIndex((u) => u.id === id)

    if (userIndex !== -1) {
      USERS_DATA.splice(userIndex, 1)
      return NextResponse.json({ message: "User deleted successfully" })
    } else {
      return NextResponse.json({ error: "User not found" }, { status: 404 })
    }
  } catch (error) {
    console.error("[v0] Error in DELETE /api/users:", error)
    return NextResponse.json({ error: "Failed to delete user", details: error.message }, { status: 500 })
  }
}
