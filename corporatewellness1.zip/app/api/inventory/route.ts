import { type NextRequest, NextResponse } from "next/server"
import {
  getInventory,
  createInventoryItem,
  updateInventoryItem,
  deleteInventoryItem,
  type InventoryItem,
} from "@/lib/file-storage"

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const page = Number.parseInt(searchParams.get("page") || "1")
    const limit = Number.parseInt(searchParams.get("limit") || "10")

    const inventory = await getInventory()
    const startIndex = (page - 1) * limit
    const endIndex = startIndex + limit
    const paginatedInventory = inventory.slice(startIndex, endIndex)

    return NextResponse.json({
      inventory: paginatedInventory,
      total: inventory.length,
      page,
      totalPages: Math.ceil(inventory.length / limit),
    })
  } catch (error) {
    return NextResponse.json({ error: "Failed to fetch inventory" }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const data = await request.json()

    let status: "in-stock" | "low-stock" | "out-of-stock" = "in-stock"
    if (data.currentStock === 0) {
      status = "out-of-stock"
    } else if (data.currentStock <= data.reorderPoint) {
      status = "low-stock"
    }

    const totalValue = data.currentStock * data.unitCost

    const newInventoryItem = await createInventoryItem({
      productId: data.productId,
      productName: data.productName,
      currentStock: data.currentStock,
      minStock: data.minStock,
      maxStock: data.maxStock,
      reorderPoint: data.reorderPoint,
      supplier: data.supplier,
      lastOrderDate: data.lastOrderDate || new Date().toISOString(),
      lastOrderQuantity: data.lastOrderQuantity || 0,
      unitCost: data.unitCost,
      totalValue,
      status,
    })

    return NextResponse.json(newInventoryItem, { status: 201 })
  } catch (error) {
    return NextResponse.json({ error: "Failed to create inventory item" }, { status: 500 })
  }
}

export async function PUT(request: NextRequest) {
  try {
    const data = await request.json()

    const updateData: Partial<InventoryItem> = { ...data }

    if (data.currentStock !== undefined) {
      let status: "in-stock" | "low-stock" | "out-of-stock" = "in-stock"
      if (data.currentStock === 0) {
        status = "out-of-stock"
      } else if (data.currentStock <= (data.reorderPoint || 0)) {
        status = "low-stock"
      }
      updateData.status = status
    }

    if (data.currentStock !== undefined && data.unitCost !== undefined) {
      updateData.totalValue = data.currentStock * data.unitCost
    }

    const updatedItem = await updateInventoryItem(data.id, updateData)

    if (!updatedItem) {
      return NextResponse.json({ error: "Inventory item not found" }, { status: 404 })
    }

    return NextResponse.json(updatedItem)
  } catch (error) {
    return NextResponse.json({ error: "Failed to update inventory" }, { status: 500 })
  }
}

export async function DELETE(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const id = searchParams.get("id")

    if (!id) {
      return NextResponse.json({ error: "Inventory ID is required" }, { status: 400 })
    }

    const deleted = await deleteInventoryItem(id)

    if (!deleted) {
      return NextResponse.json({ error: "Inventory item not found" }, { status: 404 })
    }

    return NextResponse.json({ message: "Inventory item deleted successfully" })
  } catch (error) {
    return NextResponse.json({ error: "Failed to delete inventory item" }, { status: 500 })
  }
}
