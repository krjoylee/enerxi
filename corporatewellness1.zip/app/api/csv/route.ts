import { type NextRequest, NextResponse } from "next/server"
import { getUsers, getProducts, getInventory, createUser, createProduct, createInventoryItem } from "@/lib/file-storage"

function arrayToCSV(data: any[], headers: string[]): string {
  const csvHeaders = headers.join(",")
  const csvRows = data.map((row) =>
    headers
      .map((header) => {
        const value = row[header]
        // Handle values that might contain commas or quotes
        if (typeof value === "string" && (value.includes(",") || value.includes('"'))) {
          return `"${value.replace(/"/g, '""')}"`
        }
        return value ?? ""
      })
      .join(","),
  )
  return [csvHeaders, ...csvRows].join("\n")
}

function parseCSV(csvText: string): any[] {
  const lines = csvText.trim().split("\n")
  if (lines.length < 2) return []

  const headers = lines[0].split(",").map((h) => h.trim())
  const data = []

  for (let i = 1; i < lines.length; i++) {
    const values = lines[i].split(",").map((v) => v.trim())
    const row: any = {}

    headers.forEach((header, index) => {
      let value = values[index] || ""

      // Remove quotes if present
      if (value.startsWith('"') && value.endsWith('"')) {
        value = value.slice(1, -1).replace(/""/g, '"')
      }

      // Convert numeric values
      if (!isNaN(Number(value)) && value !== "") {
        row[header] = Number(value)
      } else if (value.toLowerCase() === "true") {
        row[header] = true
      } else if (value.toLowerCase() === "false") {
        row[header] = false
      } else {
        row[header] = value
      }
    })

    data.push(row)
  }

  return data
}

export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url)
  const type = searchParams.get("type")

  try {
    let data: any[] = []
    let headers: string[] = []
    let filename = ""

    switch (type) {
      case "users":
        data = await getUsers()
        headers = [
          "id",
          "name",
          "employeeId",
          "department",
          "position",
          "email",
          "age",
          "gender",
          "height",
          "weight",
          "bmi",
          "bmiCategory",
          "diabetes",
          "hypertension",
          "allergies",
        ]
        filename = "users.csv"
        break

      case "products":
        data = await getProducts()
        headers = [
          "id",
          "name",
          "category",
          "brand",
          "barcode",
          "servingSize",
          "servingUnit",
          "calories",
          "caloriesPerServing",
          "protein",
          "fat",
          "carbs",
          "sugar",
          "sodium",
          "fiber",
          "proteinPercent",
          "fatPercent",
          "carbsPercent",
          "healthRating",
          "imageUrl",
        ]
        filename = "products.csv"
        break

      case "inventory":
        data = await getInventory()
        headers = [
          "id",
          "productId",
          "productName",
          "currentStock",
          "minStock",
          "maxStock",
          "reorderPoint",
          "supplier",
          "lastOrderDate",
          "lastOrderQuantity",
          "unitCost",
          "totalValue",
          "status",
        ]
        filename = "inventory.csv"
        break

      default:
        return NextResponse.json({ error: "Invalid type parameter" }, { status: 400 })
    }

    const csvContent = arrayToCSV(data, headers)

    return new NextResponse(csvContent, {
      status: 200,
      headers: {
        "Content-Type": "text/csv",
        "Content-Disposition": `attachment; filename="${filename}"`,
      },
    })
  } catch (error) {
    console.error("CSV export error:", error)
    return NextResponse.json({ error: "CSV export failed" }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  const { searchParams } = new URL(request.url)
  const type = searchParams.get("type")

  try {
    const formData = await request.formData()
    const file = formData.get("file") as File

    if (!file) {
      return NextResponse.json({ error: "No file provided" }, { status: 400 })
    }

    const csvText = await file.text()
    const data = parseCSV(csvText)

    if (data.length === 0) {
      return NextResponse.json({ error: "No valid data found in CSV" }, { status: 400 })
    }

    const validationErrors: string[] = []
    const importedRecords: any[] = []

    switch (type) {
      case "users":
        for (const [index, row] of data.entries()) {
          if (!row.name || !row.employeeId) {
            validationErrors.push(`Row ${index + 2}: Name and Employee ID are required`)
            continue
          }

          // Calculate BMI and category
          let bmi = 0
          let bmiCategory = "정상"
          if (row.height && row.weight) {
            bmi = Math.round((row.weight / Math.pow(row.height / 100, 2)) * 100) / 100
            if (bmi < 18.5) bmiCategory = "저체중"
            else if (bmi < 25) bmiCategory = "정상"
            else if (bmi < 30) bmiCategory = "과체중"
            else bmiCategory = "비만"
          }

          try {
            const newUser = await createUser({
              name: row.name,
              employeeId: row.employeeId,
              email: row.email || "",
              department: row.department || "",
              position: row.position || "",
              age: row.age || 0,
              gender: row.gender || "male",
              height: row.height || 0,
              weight: row.weight || 0,
              bmi,
              bmiCategory,
              diabetes: row.diabetes || false,
              hypertension: row.hypertension || false,
              allergies: row.allergies ? row.allergies.split(";") : [],
            })
            importedRecords.push(newUser)
          } catch (error) {
            validationErrors.push(`Row ${index + 2}: Failed to create user`)
          }
        }
        break

      case "products":
        for (const [index, row] of data.entries()) {
          if (!row.name || !row.category) {
            validationErrors.push(`Row ${index + 2}: Name and Category are required`)
            continue
          }

          // Calculate automatic fields
          let caloriesPerServing = 0
          let proteinPercent = 0
          let fatPercent = 0
          let carbsPercent = 0
          let healthRating = 1

          if (row.servingSize && row.calories) {
            caloriesPerServing = Math.round((row.calories * row.servingSize) / 100)
          }

          if (row.calories) {
            if (row.protein) proteinPercent = Math.round(((row.protein * 4 * 100) / row.calories) * 100) / 100
            if (row.fat) fatPercent = Math.round(((row.fat * 9 * 100) / row.calories) * 100) / 100
            if (row.carbs) carbsPercent = Math.round(((row.carbs * 4 * 100) / row.calories) * 100) / 100

            // Calculate health rating
            if (row.calories < 300 && row.sugar < 10 && row.sodium < 500) healthRating = 5
            else if (row.calories < 400 && row.sugar < 15 && row.sodium < 800) healthRating = 4
            else if (row.calories < 500 && row.sugar < 20 && row.sodium < 1000) healthRating = 3
            else if (row.calories < 600) healthRating = 2
          }

          try {
            const newProduct = await createProduct({
              name: row.name,
              category: row.category,
              barcode: row.barcode || "",
              brand: row.brand || "",
              servingSize: row.servingSize || 0,
              servingUnit: row.servingUnit || "g",
              calories: row.calories || 0,
              caloriesPerServing,
              protein: row.protein || 0,
              fat: row.fat || 0,
              carbs: row.carbs || 0,
              sugar: row.sugar || 0,
              sodium: row.sodium || 0,
              fiber: row.fiber || 0,
              proteinPercent,
              fatPercent,
              carbsPercent,
              healthRating,
              imageUrl: row.imageUrl || "",
            })
            importedRecords.push(newProduct)
          } catch (error) {
            validationErrors.push(`Row ${index + 2}: Failed to create product`)
          }
        }
        break

      case "inventory":
        for (const [index, row] of data.entries()) {
          if (!row.productName || row.currentStock === undefined) {
            validationErrors.push(`Row ${index + 2}: Product name and current stock are required`)
            continue
          }

          // Calculate status and total value
          let status: "in-stock" | "low-stock" | "out-of-stock" = "in-stock"
          if (row.currentStock === 0) status = "out-of-stock"
          else if (row.currentStock <= (row.reorderPoint || 0)) status = "low-stock"

          const totalValue = (row.currentStock || 0) * (row.unitCost || 0)

          try {
            const newInventoryItem = await createInventoryItem({
              productId: row.productId || "",
              productName: row.productName,
              currentStock: row.currentStock,
              minStock: row.minStock || 0,
              maxStock: row.maxStock || 0,
              reorderPoint: row.reorderPoint || 0,
              supplier: row.supplier || "",
              lastOrderDate: row.lastOrderDate || new Date().toISOString(),
              lastOrderQuantity: row.lastOrderQuantity || 0,
              unitCost: row.unitCost || 0,
              totalValue,
              status,
            })
            importedRecords.push(newInventoryItem)
          } catch (error) {
            validationErrors.push(`Row ${index + 2}: Failed to create inventory item`)
          }
        }
        break
    }

    if (validationErrors.length > 0) {
      return NextResponse.json(
        {
          error: "Some records failed validation",
          details: validationErrors,
          imported: importedRecords.length,
        },
        { status: 400 },
      )
    }

    return NextResponse.json({
      message: `Successfully imported ${importedRecords.length} ${type} records`,
      imported: importedRecords.length,
    })
  } catch (error) {
    console.error("CSV import error:", error)
    return NextResponse.json({ error: "CSV import failed" }, { status: 500 })
  }
}
