import { type NextRequest, NextResponse } from "next/server"

const ADMIN_USERNAME = process.env.ADMIN_USERNAME || "admin"
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || "admin123"

export async function POST(request: NextRequest) {
  try {
    const { username, password, action } = await request.json()

    if (action === "login") {
      if (username === ADMIN_USERNAME && password === ADMIN_PASSWORD) {
        // In a real application, you would generate a JWT token
        return NextResponse.json({
          success: true,
          token: "admin-token-" + Date.now(),
          user: { username, role: "admin" },
        })
      } else {
        return NextResponse.json({ error: "Invalid credentials" }, { status: 401 })
      }
    }

    if (action === "verify") {
      // Simple token verification (in production, use proper JWT verification)
      const token = request.headers.get("authorization")?.replace("Bearer ", "")
      if (token && token.startsWith("admin-token-")) {
        return NextResponse.json({ valid: true, role: "admin" })
      } else {
        return NextResponse.json({ valid: false }, { status: 401 })
      }
    }

    return NextResponse.json({ error: "Invalid action" }, { status: 400 })
  } catch (error) {
    return NextResponse.json({ error: "Authentication failed" }, { status: 500 })
  }
}
