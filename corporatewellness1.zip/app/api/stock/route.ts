import { NextResponse } from "next/server"

// Mock database connection - replace with actual database query
const mockStockData = [
  { seq: 1, item_name: "허니버터칩", quantity: 45, barcode: "880101960" },
  { seq: 2, item_name: "초코파이", quantity: 32, barcode: "880111710" },
  { seq: 3, item_name: "바나나킥", quantity: 28, barcode: "880101960" },
  { seq: 4, item_name: "새우깡", quantity: 38, barcode: "880101960" },
  { seq: 5, item_name: "오징어땅콩", quantity: 22, barcode: "880101960" },
  { seq: 6, item_name: "포카칩", quantity: 35, barcode: "880101960" },
  { seq: 7, item_name: "치토스", quantity: 18, barcode: "880101960" },
  { seq: 8, item_name: "프링글스", quantity: 25, barcode: "880101960" },
  { seq: 9, item_name: "콘칩", quantity: 40, barcode: "880101960" },
  { seq: 10, item_name: "감자칩", quantity: 30, barcode: "880101960" },
]

export async function GET() {
  try {
    // TODO: Replace with actual database query
    // const result = await sql`SELECT item_name, quantity FROM stock_list ORDER BY seq`

    const stockItems = mockStockData.map((item) => ({
      seq: item.seq,
      item_name: item.item_name,
      quantity: item.quantity,
    }))

    return NextResponse.json(stockItems)
  } catch (error) {
    console.error("Database error:", error)
    return NextResponse.json({ error: "Failed to fetch stock data" }, { status: 500 })
  }
}

export async function POST(request: Request) {
  try {
    const { item_name, quantity, barcode } = await request.json()

    // TODO: Replace with actual database insert
    // const result = await sql`
    //   INSERT INTO stock_list (item_name, quantity, barcode)
    //   VALUES (${item_name}, ${quantity}, ${barcode})
    //   RETURNING *
    // `

    const newItem = {
      seq: mockStockData.length + 1,
      item_name,
      quantity,
      barcode,
    }

    mockStockData.push(newItem)

    return NextResponse.json(newItem)
  } catch (error) {
    console.error("Database error:", error)
    return NextResponse.json({ error: "Failed to create stock item" }, { status: 500 })
  }
}
