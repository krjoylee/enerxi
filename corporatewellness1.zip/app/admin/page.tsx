"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Progress } from "@/components/ui/progress"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  BarChart3,
  TrendingUp,
  TrendingDown,
  AlertTriangle,
  Package,
  DollarSign,
  Users,
  ArrowLeft,
  Download,
  Settings,
  Bell,
  ShoppingCart,
  Trash2,
  Eye,
  Filter,
} from "lucide-react"
import Link from "next/link"
import { ChartContainer } from "@/components/ui/chart"

interface SnackItem {
  id: string
  name: string
  brand: string
  category: string
  stock: number
  minStock: number
  price: number
  popularity: number
  consumedToday: number
  consumedWeek: number
  wasteRate: number
  lastRestocked: string
}

interface Employee {
  id: string
  name: string
  department: string
  consumptionToday: number
  consumptionWeek: number
  healthScore: number
  lastActive: string
}

export default function AdminDashboard() {
  const [selectedPeriod, setSelectedPeriod] = useState<"today" | "week" | "month">("week")
  const [selectedTab, setSelectedTab] = useState("overview")

  // Mock data
  const snackInventory: SnackItem[] = [
    {
      id: "1",
      name: "초코칩 쿠키",
      brand: "오리온",
      category: "과자",
      stock: 5,
      minStock: 20,
      price: 1500,
      popularity: 85,
      consumedToday: 12,
      consumedWeek: 67,
      wasteRate: 5,
      lastRestocked: "2024-01-15",
    },
    {
      id: "2",
      name: "바나나우유",
      brand: "빙그레",
      category: "음료",
      stock: 45,
      minStock: 30,
      price: 1200,
      popularity: 92,
      consumedToday: 18,
      consumedWeek: 89,
      wasteRate: 2,
      lastRestocked: "2024-01-18",
    },
    {
      id: "3",
      name: "견과류 믹스",
      brand: "롯데",
      category: "건강간식",
      stock: 8,
      minStock: 15,
      price: 3500,
      popularity: 68,
      consumedToday: 6,
      consumedWeek: 34,
      wasteRate: 8,
      lastRestocked: "2024-01-12",
    },
    {
      id: "4",
      name: "요구르트",
      brand: "다논",
      category: "유제품",
      stock: 25,
      minStock: 20,
      price: 800,
      popularity: 78,
      consumedToday: 14,
      consumedWeek: 72,
      wasteRate: 12,
      lastRestocked: "2024-01-17",
    },
  ]

  const employees: Employee[] = [
    {
      id: "1",
      name: "김직원",
      department: "개발팀",
      consumptionToday: 3,
      consumptionWeek: 15,
      healthScore: 75,
      lastActive: "2024-01-19 14:30",
    },
    {
      id: "2",
      name: "이매니저",
      department: "마케팅팀",
      consumptionToday: 2,
      consumptionWeek: 12,
      healthScore: 82,
      lastActive: "2024-01-19 16:45",
    },
    {
      id: "3",
      name: "박팀장",
      department: "영업팀",
      consumptionToday: 4,
      consumptionWeek: 18,
      healthScore: 68,
      lastActive: "2024-01-19 11:20",
    },
  ]

  const popularityData = snackInventory.map((item) => ({
    name: item.name,
    popularity: item.popularity,
    consumed: item.consumedWeek,
    waste: item.wasteRate,
  }))

  const consumptionTrend = [
    { date: "월", consumption: 45, cost: 67500 },
    { date: "화", consumption: 52, cost: 78000 },
    { date: "수", consumption: 38, cost: 57000 },
    { date: "목", consumption: 61, cost: 91500 },
    { date: "금", consumption: 48, cost: 72000 },
    { date: "토", consumption: 12, cost: 18000 },
    { date: "일", consumption: 8, cost: 12000 },
  ]

  const categoryData = [
    { name: "과자", value: 35, color: "#ec4899" },
    { name: "음료", value: 28, color: "#22d3ee" },
    { name: "건강간식", value: 20, color: "#a5f3fc" },
    { name: "유제품", value: 17, color: "#164e63" },
  ]

  const lowStockItems = snackInventory.filter((item) => item.stock <= item.minStock)
  const totalCostToday = consumptionTrend[4]?.cost || 0
  const totalConsumptionToday = consumptionTrend[4]?.consumption || 0
  const averageWasteRate = snackInventory.reduce((acc, item) => acc + item.wasteRate, 0) / snackInventory.length

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Link href="/">
                <Button variant="ghost" size="sm">
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  돌아가기
                </Button>
              </Link>
              <div className="flex items-center gap-3">
                <div className="flex items-center justify-center w-10 h-10 bg-primary rounded-lg">
                  <BarChart3 className="w-6 h-6 text-primary-foreground" />
                </div>
                <div>
                  <h1 className="text-xl font-bold text-card-foreground">관리자 대시보드</h1>
                  <p className="text-sm text-muted-foreground">탕비실 운영 현황 및 분석</p>
                </div>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Button variant="outline" size="sm">
                <Download className="w-4 h-4 mr-2" />
                리포트 다운로드
              </Button>
              <Button variant="outline" size="sm">
                <Settings className="w-4 h-4 mr-2" />
                설정
              </Button>
              <Badge variant="secondary" className="bg-accent text-accent-foreground">
                실시간
              </Badge>
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        <div className="max-w-7xl mx-auto space-y-8">
          {/* Alerts */}
          <div className="space-y-4">
            {lowStockItems.length > 0 && (
              <Alert variant="destructive">
                <AlertTriangle className="h-4 w-4" />
                <AlertDescription>
                  <strong>재고 부족 알림!</strong> {lowStockItems.length}개 상품의 재고가 부족합니다:{" "}
                  {lowStockItems.map((item) => item.name).join(", ")}
                </AlertDescription>
              </Alert>
            )}

            {averageWasteRate > 10 && (
              <Alert>
                <Bell className="h-4 w-4" />
                <AlertDescription>
                  <strong>폐기율 주의!</strong> 평균 폐기율이 {averageWasteRate.toFixed(1)}%입니다. 재고 관리를
                  검토해보세요.
                </AlertDescription>
              </Alert>
            )}
          </div>

          {/* KPI Cards */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium flex items-center gap-2">
                  <Users className="w-4 h-4 text-primary" />
                  활성 직원
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-1">
                  <div className="text-2xl font-bold text-foreground">{employees.length}</div>
                  <p className="text-xs text-muted-foreground">오늘 이용한 직원 수</p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium flex items-center gap-2">
                  <Package className="w-4 h-4 text-accent" />총 소비량
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-1">
                  <div className="text-2xl font-bold text-foreground">{totalConsumptionToday}</div>
                  <p className="text-xs text-muted-foreground">오늘 소비된 간식 수</p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium flex items-center gap-2">
                  <DollarSign className="w-4 h-4 text-chart-3" />
                  일일 비용
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-1">
                  <div className="text-2xl font-bold text-foreground">{totalCostToday.toLocaleString()}원</div>
                  <p className="text-xs text-muted-foreground">오늘 소비 비용</p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium flex items-center gap-2">
                  <Trash2 className="w-4 h-4 text-destructive" />
                  폐기율
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-1">
                  <div className="text-2xl font-bold text-foreground">{averageWasteRate.toFixed(1)}%</div>
                  <p className="text-xs text-muted-foreground">평균 폐기율</p>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Main Dashboard Tabs */}
          <Tabs value={selectedTab} onValueChange={setSelectedTab} className="w-full">
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="overview">개요</TabsTrigger>
              <TabsTrigger value="inventory">재고 관리</TabsTrigger>
              <TabsTrigger value="analytics">분석</TabsTrigger>
              <TabsTrigger value="employees">직원 현황</TabsTrigger>
            </TabsList>

            {/* Overview Tab */}
            <TabsContent value="overview" className="space-y-6">
              <div className="grid lg:grid-cols-2 gap-6">
                {/* Consumption Trend */}
                <Card>
                  <CardHeader>
                    <CardTitle className="text-card-foreground">주간 소비 추이</CardTitle>
                    <CardDescription>일별 간식 소비량 및 비용</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <ChartContainer
                      config={{
                        consumption: {
                          label: "소비량",
                          color: "hsl(var(--chart-1))",
                        },
                      }}
                      className="h-64"
                    >
                      <div className="space-y-2">
                        {consumptionTrend.map((day, index) => (
                          <div key={index} className="flex items-center justify-between p-2 bg-muted/50 rounded">
                            <span className="text-sm font-medium">{day.date}</span>
                            <div className="flex items-center gap-4">
                              <div className="flex items-center gap-2">
                                <div className="w-16 h-2 bg-muted rounded-full overflow-hidden">
                                  <div
                                    className="h-full bg-chart-1 rounded-full"
                                    style={{ width: `${(day.consumption / 70) * 100}%` }}
                                  />
                                </div>
                                <span className="text-sm text-muted-foreground">{day.consumption}개</span>
                              </div>
                              <span className="text-sm font-medium">{day.cost.toLocaleString()}원</span>
                            </div>
                          </div>
                        ))}
                      </div>
                    </ChartContainer>
                  </CardContent>
                </Card>

                {/* Category Distribution */}
                <Card>
                  <CardHeader>
                    <CardTitle className="text-card-foreground">카테고리별 소비 분포</CardTitle>
                    <CardDescription>간식 카테고리별 소비 비율</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <ChartContainer
                      config={{
                        value: {
                          label: "비율",
                          color: "hsl(var(--chart-1))",
                        },
                      }}
                      className="h-64"
                    >
                      <div className="space-y-4">
                        {categoryData.map((item, index) => (
                          <div key={index} className="space-y-2">
                            <div className="flex justify-between items-center">
                              <div className="flex items-center gap-2">
                                <div className="w-4 h-4 rounded-full" style={{ backgroundColor: item.color }} />
                                <span className="font-medium">{item.name}</span>
                              </div>
                              <span className="text-sm text-muted-foreground">{item.value}%</span>
                            </div>
                            <div className="w-full bg-muted rounded-full h-2">
                              <div
                                className="h-2 rounded-full"
                                style={{
                                  backgroundColor: item.color,
                                  width: `${item.value}%`,
                                }}
                              />
                            </div>
                          </div>
                        ))}
                      </div>
                    </ChartContainer>
                  </CardContent>
                </Card>
              </div>

              {/* Popular Items */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-card-foreground">인기 간식 순위</CardTitle>
                  <CardDescription>이번 주 가장 인기 있는 간식들</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {snackInventory
                      .sort((a, b) => b.popularity - a.popularity)
                      .slice(0, 5)
                      .map((item, index) => (
                        <div key={item.id} className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
                          <div className="flex items-center gap-4">
                            <div className="flex items-center justify-center w-8 h-8 bg-primary rounded-full text-primary-foreground font-bold text-sm">
                              {index + 1}
                            </div>
                            <div>
                              <h4 className="font-medium text-foreground">{item.name}</h4>
                              <p className="text-sm text-muted-foreground">
                                {item.brand} • 이번 주 {item.consumedWeek}개 소비
                              </p>
                            </div>
                          </div>
                          <div className="text-right">
                            <div className="text-lg font-bold text-accent">{item.popularity}%</div>
                            <div className="text-xs text-muted-foreground">인기도</div>
                          </div>
                        </div>
                      ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Inventory Tab */}
            <TabsContent value="inventory" className="space-y-6">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-semibold text-foreground">재고 현황</h3>
                <div className="flex items-center gap-2">
                  <Button variant="outline" size="sm">
                    <Filter className="w-4 h-4 mr-2" />
                    필터
                  </Button>
                  <Button size="sm" className="bg-primary hover:bg-primary/90 text-primary-foreground">
                    <ShoppingCart className="w-4 h-4 mr-2" />
                    구매 주문
                  </Button>
                </div>
              </div>

              <div className="grid gap-4">
                {snackInventory.map((item) => (
                  <Card key={item.id} className={item.stock <= item.minStock ? "border-destructive/50" : ""}>
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-4">
                          <div className="space-y-1">
                            <h4 className="font-medium text-foreground">{item.name}</h4>
                            <p className="text-sm text-muted-foreground">
                              {item.brand} • {item.category} • {item.price.toLocaleString()}원
                            </p>
                          </div>
                        </div>

                        <div className="flex items-center gap-6">
                          <div className="text-center">
                            <div className="text-lg font-bold text-foreground">{item.stock}</div>
                            <div className="text-xs text-muted-foreground">현재 재고</div>
                          </div>

                          <div className="text-center">
                            <div className="text-lg font-bold text-accent">{item.popularity}%</div>
                            <div className="text-xs text-muted-foreground">인기도</div>
                          </div>

                          <div className="text-center">
                            <div className="text-lg font-bold text-chart-3">{item.consumedWeek}</div>
                            <div className="text-xs text-muted-foreground">주간 소비</div>
                          </div>

                          <div className="flex items-center gap-2">
                            {item.stock <= item.minStock && (
                              <Badge variant="destructive" className="text-xs">
                                재고 부족
                              </Badge>
                            )}
                            {item.wasteRate > 10 && (
                              <Badge variant="secondary" className="text-xs bg-accent/10 text-accent">
                                폐기율 높음
                              </Badge>
                            )}
                          </div>
                        </div>
                      </div>

                      <div className="mt-4 space-y-2">
                        <div className="flex justify-between text-sm">
                          <span className="text-muted-foreground">재고 수준</span>
                          <span className="font-medium">
                            {item.stock} / {item.minStock} (최소)
                          </span>
                        </div>
                        <Progress value={Math.min((item.stock / item.minStock) * 100, 100)} className="h-2" />
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>

            {/* Analytics Tab */}
            <TabsContent value="analytics" className="space-y-6">
              <div className="grid lg:grid-cols-2 gap-6">
                {/* Popularity vs Waste */}
                <Card>
                  <CardHeader>
                    <CardTitle className="text-card-foreground">인기도 vs 폐기율</CardTitle>
                    <CardDescription>간식별 인기도와 폐기율 비교</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <ChartContainer
                      config={{
                        popularity: {
                          label: "인기도",
                          color: "hsl(var(--chart-1))",
                        },
                        waste: {
                          label: "폐기율",
                          color: "hsl(var(--chart-2))",
                        },
                      }}
                      className="h-64"
                    >
                      <div className="space-y-4">
                        {popularityData.map((item, index) => (
                          <div key={index} className="space-y-2">
                            <div className="flex justify-between items-center">
                              <span className="font-medium text-sm">{item.name}</span>
                              <div className="flex gap-4 text-sm">
                                <span className="text-chart-1">인기도: {item.popularity}%</span>
                                <span className="text-chart-2">폐기율: {item.waste}%</span>
                              </div>
                            </div>
                            <div className="flex gap-2">
                              <div className="flex-1 bg-muted rounded-full h-2">
                                <div className="h-2 rounded-full bg-chart-1" style={{ width: `${item.popularity}%` }} />
                              </div>
                              <div className="flex-1 bg-muted rounded-full h-2">
                                <div className="h-2 rounded-full bg-chart-2" style={{ width: `${item.waste * 5}%` }} />
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    </ChartContainer>
                  </CardContent>
                </Card>

                {/* Cost Analysis */}
                <Card>
                  <CardHeader>
                    <CardTitle className="text-card-foreground">비용 분석</CardTitle>
                    <CardDescription>일별 비용 추이</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <ChartContainer
                      config={{
                        cost: {
                          label: "비용",
                          color: "hsl(var(--chart-3))",
                        },
                      }}
                      className="h-64"
                    >
                      <div className="space-y-2">
                        {consumptionTrend.map((day, index) => (
                          <div key={index} className="flex items-center justify-between p-2 bg-muted/50 rounded">
                            <span className="text-sm font-medium">{day.date}</span>
                            <div className="flex items-center gap-2">
                              <div className="w-20 h-2 bg-muted rounded-full overflow-hidden">
                                <div
                                  className="h-full bg-chart-3 rounded-full"
                                  style={{ width: `${(day.cost / 100000) * 100}%` }}
                                />
                              </div>
                              <span className="text-sm text-muted-foreground">{day.cost.toLocaleString()}원</span>
                            </div>
                          </div>
                        ))}
                      </div>
                    </ChartContainer>
                  </CardContent>
                </Card>
              </div>

              {/* Recommendations */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-card-foreground">운영 개선 제안</CardTitle>
                  <CardDescription>데이터 기반 운영 최적화 권장사항</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-start gap-3 p-3 bg-accent/10 rounded-lg">
                      <TrendingUp className="w-5 h-5 text-accent mt-0.5" />
                      <div>
                        <h4 className="font-medium text-foreground">인기 상품 재고 증량</h4>
                        <p className="text-sm text-muted-foreground">
                          바나나우유(92% 인기도)의 재고를 30% 증량하여 품절을 방지하세요.
                        </p>
                      </div>
                    </div>

                    <div className="flex items-start gap-3 p-3 bg-destructive/10 rounded-lg">
                      <TrendingDown className="w-5 h-5 text-destructive mt-0.5" />
                      <div>
                        <h4 className="font-medium text-foreground">폐기율 높은 상품 검토</h4>
                        <p className="text-sm text-muted-foreground">
                          요구르트(12% 폐기율)의 주문량을 20% 감소시키거나 대체 상품을 고려하세요.
                        </p>
                      </div>
                    </div>

                    <div className="flex items-start gap-3 p-3 bg-primary/10 rounded-lg">
                      <DollarSign className="w-5 h-5 text-primary mt-0.5" />
                      <div>
                        <h4 className="font-medium text-foreground">비용 절감 기회</h4>
                        <p className="text-sm text-muted-foreground">
                          주간 평균 비용이 목표 대비 15% 초과입니다. 저가 대체 상품을 검토해보세요.
                        </p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Employees Tab */}
            <TabsContent value="employees" className="space-y-6">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-semibold text-foreground">직원 이용 현황</h3>
                <Select defaultValue="all">
                  <SelectTrigger className="w-40">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">전체 부서</SelectItem>
                    <SelectItem value="dev">개발팀</SelectItem>
                    <SelectItem value="marketing">마케팅팀</SelectItem>
                    <SelectItem value="sales">영업팀</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="grid gap-4">
                {employees.map((employee) => (
                  <Card key={employee.id}>
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-4">
                          <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center">
                            <Users className="w-6 h-6 text-primary" />
                          </div>
                          <div>
                            <h4 className="font-medium text-foreground">{employee.name}</h4>
                            <p className="text-sm text-muted-foreground">
                              {employee.department} • 마지막 활동: {employee.lastActive}
                            </p>
                          </div>
                        </div>

                        <div className="flex items-center gap-6">
                          <div className="text-center">
                            <div className="text-lg font-bold text-foreground">{employee.consumptionToday}</div>
                            <div className="text-xs text-muted-foreground">오늘 소비</div>
                          </div>

                          <div className="text-center">
                            <div className="text-lg font-bold text-accent">{employee.consumptionWeek}</div>
                            <div className="text-xs text-muted-foreground">주간 소비</div>
                          </div>

                          <div className="text-center">
                            <div className="text-lg font-bold text-chart-3">{employee.healthScore}</div>
                            <div className="text-xs text-muted-foreground">건강 점수</div>
                          </div>

                          <Button variant="outline" size="sm">
                            <Eye className="w-4 h-4 mr-2" />
                            상세보기
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </main>
    </div>
  )
}
