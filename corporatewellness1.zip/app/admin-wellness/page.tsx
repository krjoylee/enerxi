import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { Heart, Plus, Edit, Users, Calendar, ArrowLeft } from "lucide-react"
import Link from "next/link"

export default function AdminWellnessPage() {
  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Link href="/admin-dashboard">
                <Button variant="ghost" size="sm">
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  돌아가기
                </Button>
              </Link>
              <div className="flex items-center justify-center w-10 h-10 bg-primary rounded-lg">
                <Heart className="w-6 h-6 text-primary-foreground" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-card-foreground">웰니스 프로그램 관리</h1>
                <p className="text-sm text-muted-foreground">건강 프로그램 추가 및 수정</p>
              </div>
            </div>
            <Badge variant="secondary" className="bg-chart-2 text-chart-2-foreground">
              관리자 모드
            </Badge>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          {/* Add New Program */}
          <Card className="mb-8">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Plus className="w-5 h-5" />새 웰니스 프로그램 추가
              </CardTitle>
              <CardDescription>직원들이 참여할 수 있는 건강 프로그램을 추가하세요</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="program-title">프로그램 제목</Label>
                  <Input id="program-title" placeholder="예: 금연 관리 프로그램" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="max-participants">참여 가능 인원</Label>
                  <Input id="max-participants" type="number" placeholder="20" />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="program-overview">프로그램 개요</Label>
                <Textarea
                  id="program-overview"
                  placeholder="프로그램의 목적, 내용, 기대 효과 등을 설명해주세요"
                  className="min-h-[100px]"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="program-image">프로그램 이미지</Label>
                <Input id="program-image" type="file" accept="image/*" />
                <p className="text-sm text-muted-foreground">권장 크기: 400x300px</p>
              </div>

              <Button className="w-full bg-primary hover:bg-primary/90">
                <Plus className="w-4 h-4 mr-2" />
                프로그램 추가
              </Button>
            </CardContent>
          </Card>

          {/* Existing Programs */}
          <div className="space-y-6">
            <h3 className="text-2xl font-bold text-foreground">기존 프로그램 관리</h3>

            <div className="grid gap-6">
              {/* Program 1 */}
              <Card>
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div>
                      <CardTitle className="text-lg">금연 관리 프로그램</CardTitle>
                      <CardDescription>전문 상담사와 함께하는 체계적인 금연 지원</CardDescription>
                    </div>
                    <div className="flex gap-2">
                      <Button variant="outline" size="sm">
                        <Edit className="w-4 h-4 mr-2" />
                        수정
                      </Button>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center gap-4 text-sm text-muted-foreground">
                    <div className="flex items-center gap-1">
                      <Users className="w-4 h-4" />
                      <span>15/20명 참여</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Calendar className="w-4 h-4" />
                      <span>4주 프로그램</span>
                    </div>
                    <Badge variant="secondary" className="bg-chart-3 text-chart-3-foreground">
                      진행중
                    </Badge>
                  </div>
                </CardContent>
              </Card>

              {/* Program 2 */}
              <Card>
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div>
                      <CardTitle className="text-lg">당뇨 관리 프로그램</CardTitle>
                      <CardDescription>혈당 관리와 식단 조절을 위한 맞춤형 프로그램</CardDescription>
                    </div>
                    <div className="flex gap-2">
                      <Button variant="outline" size="sm">
                        <Edit className="w-4 h-4 mr-2" />
                        수정
                      </Button>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center gap-4 text-sm text-muted-foreground">
                    <div className="flex items-center gap-1">
                      <Users className="w-4 h-4" />
                      <span>8/15명 참여</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Calendar className="w-4 h-4" />
                      <span>8주 프로그램</span>
                    </div>
                    <Badge variant="secondary" className="bg-primary text-primary-foreground">
                      모집중
                    </Badge>
                  </div>
                </CardContent>
              </Card>

              {/* Program 3 */}
              <Card>
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div>
                      <CardTitle className="text-lg">불면 테라피</CardTitle>
                      <CardDescription>수면의 질 개선을 위한 인지행동치료 기반 프로그램</CardDescription>
                    </div>
                    <div className="flex gap-2">
                      <Button variant="outline" size="sm">
                        <Edit className="w-4 h-4 mr-2" />
                        수정
                      </Button>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center gap-4 text-sm text-muted-foreground">
                    <div className="flex items-center gap-1">
                      <Users className="w-4 h-4" />
                      <span>12/25명 참여</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Calendar className="w-4 h-4" />
                      <span>6주 프로그램</span>
                    </div>
                    <Badge variant="secondary" className="bg-accent text-accent-foreground">
                      모집중
                    </Badge>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </main>
    </div>
  )
}
