"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Progress } from "@/components/ui/progress"
import {
  Scan,
  User,
  CheckCircle,
  AlertCircle,
  Camera,
  Zap,
  Apple,
  ArrowLeft,
  RefreshCw,
  Clock,
  Utensils,
} from "lucide-react"
import Link from "next/link"

interface ScannedItem {
  id: string
  name: string
  brand: string
  calories: number
  protein: number
  carbs: number
  fat: number
  sugar: number
  sodium: number
  barcode: string
}

interface Employee {
  id: string
  name: string
  department: string
  dailyCalories: number
  dailyCaloriesLimit: number
}

export default function ScanPage() {
  const [scanStep, setScanStep] = useState<"auth" | "scan" | "confirm" | "complete">("auth")
  const [employee, setEmployee] = useState<Employee | null>(null)
  const [scannedItem, setScannedItem] = useState<ScannedItem | null>(null)
  const [isScanning, setIsScanning] = useState(false)
  const [scanError, setScanError] = useState<string | null>(null)
  const [employeeId, setEmployeeId] = useState("")

  // Mock employee authentication
  const authenticateEmployee = (id: string) => {
    // Simulate API call
    setTimeout(() => {
      if (id) {
        setEmployee({
          id: id,
          name: "김직원",
          department: "개발팀",
          dailyCalories: 850,
          dailyCaloriesLimit: 2000,
        })
        setScanStep("scan")
        setScanError(null)
      } else {
        setScanError("유효하지 않은 사번입니다.")
      }
    }, 1000)
  }

  // Mock barcode scanning
  const simulateBarcodeScan = () => {
    setIsScanning(true)
    setScanError(null)

    // Simulate scanning delay
    setTimeout(() => {
      const mockItems: ScannedItem[] = [
        {
          id: "1",
          name: "새우깡",
          brand: "농심",
          calories: 155,
          protein: 2.8,
          carbs: 18,
          fat: 8.2,
          sugar: 2,
          sodium: 220,
          barcode: "8801043001234",
        },
        {
          id: "2",
          name: "바나나킥",
          brand: "농심",
          calories: 142,
          protein: 2.1,
          carbs: 16,
          fat: 7.8,
          sugar: 6,
          sodium: 125,
          barcode: "8801043005678",
        },
        {
          id: "3",
          name: "초코파이",
          brand: "오리온",
          calories: 168,
          protein: 2.5,
          carbs: 24,
          fat: 7.5,
          sugar: 15,
          sodium: 95,
          barcode: "8801117009012",
        },
        {
          id: "4",
          name: "허니버터칩",
          brand: "해태",
          calories: 230,
          protein: 3.2,
          carbs: 28,
          fat: 12,
          sugar: 8,
          sodium: 180,
          barcode: "8801019003456",
        },
        {
          id: "5",
          name: "초코칩 쿠키",
          brand: "오리온",
          calories: 180,
          protein: 2.5,
          carbs: 24,
          fat: 8.5,
          sugar: 12,
          sodium: 95,
          barcode: "8801117123456",
        },
        {
          id: "6",
          name: "바나나우유",
          brand: "빙그레",
          calories: 130,
          protein: 3,
          carbs: 22,
          fat: 3.5,
          sugar: 20,
          sodium: 45,
          barcode: "8801117654321",
        },
      ]

      const randomItem = mockItems[Math.floor(Math.random() * mockItems.length)]
      setScannedItem(randomItem)
      setIsScanning(false)
      setScanStep("confirm")
    }, 2000)
  }

  // Confirm consumption
  const confirmConsumption = () => {
    if (scannedItem && employee) {
      // Update daily calories
      setEmployee((prev) =>
        prev
          ? {
              ...prev,
              dailyCalories: prev.dailyCalories + scannedItem.calories,
            }
          : null,
      )
      setScanStep("complete")

      // Auto-reset after 3 seconds
      setTimeout(() => {
        setScanStep("scan")
        setScannedItem(null)
      }, 3000)
    }
  }

  const resetScan = () => {
    setScanStep("scan")
    setScannedItem(null)
    setScanError(null)
    setIsScanning(false)
  }

  const caloriePercentage = employee ? (employee.dailyCalories / employee.dailyCaloriesLimit) * 100 : 0

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Link href="/">
                <Button variant="ghost" size="sm">
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  돌아가기
                </Button>
              </Link>
              <div className="flex items-center gap-3">
                <div className="flex items-center justify-center w-10 h-10 bg-primary rounded-lg">
                  <Scan className="w-6 h-6 text-primary-foreground" />
                </div>
                <div>
                  <h1 className="text-xl font-bold text-card-foreground">간식 스캔</h1>
                  <p className="text-sm text-muted-foreground">바코드 스캔으로 섭취 기록</p>
                </div>
              </div>
            </div>
            {employee && (
              <Badge variant="secondary" className="bg-accent/10 text-accent">
                {employee.name} ({employee.department})
              </Badge>
            )}
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        <div className="max-w-md mx-auto space-y-6">
          {/* Employee Authentication */}
          {scanStep === "auth" && (
            <Card>
              <CardHeader className="text-center">
                <CardTitle className="flex items-center justify-center gap-2 text-card-foreground">
                  <User className="w-5 h-5 text-primary" />
                  직원 인증
                </CardTitle>
                <CardDescription>사번을 입력하거나 사원증을 스캔하세요</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="employee-id">사번</Label>
                  <Input
                    id="employee-id"
                    placeholder="사번을 입력하세요"
                    value={employeeId}
                    onChange={(e) => setEmployeeId(e.target.value)}
                    className="bg-input"
                  />
                </div>

                <Button
                  className="w-full bg-primary hover:bg-primary/90 text-primary-foreground"
                  onClick={() => authenticateEmployee(employeeId)}
                  disabled={!employeeId}
                >
                  인증하기
                </Button>

                <div className="relative">
                  <div className="absolute inset-0 flex items-center">
                    <span className="w-full border-t border-border" />
                  </div>
                  <div className="relative flex justify-center text-xs uppercase">
                    <span className="bg-background px-2 text-muted-foreground">또는</span>
                  </div>
                </div>

                <Button variant="outline" className="w-full bg-transparent">
                  <Camera className="w-4 h-4 mr-2" />
                  사원증 스캔
                </Button>

                {scanError && (
                  <Alert variant="destructive">
                    <AlertCircle className="h-4 w-4" />
                    <AlertDescription>{scanError}</AlertDescription>
                  </Alert>
                )}
              </CardContent>
            </Card>
          )}

          {/* Daily Calorie Status */}
          {employee && scanStep !== "auth" && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center justify-between text-card-foreground">
                  <span className="flex items-center gap-2">
                    <Zap className="w-5 h-5 text-accent" />
                    오늘의 칼로리
                  </span>
                  <Badge variant={caloriePercentage > 80 ? "destructive" : "secondary"}>
                    {Math.round(caloriePercentage)}%
                  </Badge>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">섭취량</span>
                    <span className="font-medium">
                      {employee.dailyCalories} / {employee.dailyCaloriesLimit} kcal
                    </span>
                  </div>
                  <Progress value={caloriePercentage} className="h-2" />
                  {caloriePercentage > 80 && (
                    <p className="text-xs text-destructive">일일 권장 칼로리의 80%를 초과했습니다.</p>
                  )}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Barcode Scanning */}
          {scanStep === "scan" && (
            <Card>
              <CardHeader className="text-center">
                <CardTitle className="flex items-center justify-center gap-2 text-card-foreground">
                  <Apple className="w-5 h-5 text-accent" />
                  간식 스캔
                </CardTitle>
                <CardDescription>간식 포장지의 바코드를 스캔하세요</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="text-center">
                  <div className="w-32 h-32 mx-auto bg-muted rounded-lg flex items-center justify-center mb-4">
                    {isScanning ? (
                      <RefreshCw className="w-12 h-12 text-primary animate-spin" />
                    ) : (
                      <Scan className="w-12 h-12 text-muted-foreground" />
                    )}
                  </div>

                  {isScanning ? (
                    <div>
                      <p className="font-medium text-foreground">스캔 중...</p>
                      <p className="text-sm text-muted-foreground">바코드를 카메라에 맞춰주세요</p>
                    </div>
                  ) : (
                    <div>
                      <p className="font-medium text-foreground">바코드 스캔 준비</p>
                      <p className="text-sm text-muted-foreground">아래 버튼을 눌러 스캔을 시작하세요</p>
                    </div>
                  )}
                </div>

                <Button
                  className="w-full bg-accent hover:bg-accent/90 text-accent-foreground"
                  onClick={simulateBarcodeScan}
                  disabled={isScanning}
                >
                  <Camera className="w-4 h-4 mr-2" />
                  {isScanning ? "스캔 중..." : "바코드 스캔 시작"}
                </Button>

                {scanError && (
                  <Alert variant="destructive">
                    <AlertCircle className="h-4 w-4" />
                    <AlertDescription>
                      {scanError}
                      <Button variant="ghost" size="sm" className="ml-2" onClick={resetScan}>
                        다시 시도
                      </Button>
                    </AlertDescription>
                  </Alert>
                )}
              </CardContent>
            </Card>
          )}

          {/* Scan Confirmation */}
          {scanStep === "confirm" && scannedItem && (
            <Card>
              <CardHeader className="text-center">
                <CardTitle className="flex items-center justify-center gap-2 text-card-foreground">
                  <CheckCircle className="w-5 h-5 text-accent" />
                  스캔 완료
                </CardTitle>
                <CardDescription>스캔된 간식 정보를 확인하세요</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="text-center">
                  <h3 className="text-lg font-bold text-foreground">{scannedItem.name}</h3>
                  <p className="text-sm text-muted-foreground">{scannedItem.brand}</p>
                  <Badge variant="outline" className="mt-2">
                    {scannedItem.barcode}
                  </Badge>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="text-center p-3 bg-muted rounded-lg">
                    <div className="text-2xl font-bold text-accent">{scannedItem.calories}</div>
                    <div className="text-xs text-muted-foreground">칼로리</div>
                  </div>
                  <div className="text-center p-3 bg-muted rounded-lg">
                    <div className="text-2xl font-bold text-primary">{scannedItem.protein}g</div>
                    <div className="text-xs text-muted-foreground">단백질</div>
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-2 text-center text-sm">
                  <div>
                    <div className="font-medium text-foreground">{scannedItem.carbs}g</div>
                    <div className="text-muted-foreground">탄수화물</div>
                  </div>
                  <div>
                    <div className="font-medium text-foreground">{scannedItem.fat}g</div>
                    <div className="text-muted-foreground">지방</div>
                  </div>
                  <div>
                    <div className="font-medium text-foreground">{scannedItem.sodium}mg</div>
                    <div className="text-muted-foreground">나트륨</div>
                  </div>
                </div>

                <div className="flex gap-3">
                  <Button variant="outline" className="flex-1 bg-transparent" onClick={resetScan}>
                    취소
                  </Button>
                  <Button
                    className="flex-1 bg-primary hover:bg-primary/90 text-primary-foreground"
                    onClick={confirmConsumption}
                  >
                    <Utensils className="w-4 h-4 mr-2" />
                    섭취 확인
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Completion */}
          {scanStep === "complete" && scannedItem && (
            <Card className="border-accent/20">
              <CardHeader className="text-center">
                <CardTitle className="flex items-center justify-center gap-2 text-card-foreground">
                  <CheckCircle className="w-5 h-5 text-accent" />
                  기록 완료
                </CardTitle>
                <CardDescription>간식 섭취가 성공적으로 기록되었습니다</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="text-center p-4 bg-accent/10 rounded-lg">
                  <p className="font-medium text-accent">
                    {scannedItem.name} (+{scannedItem.calories} kcal)
                  </p>
                  <p className="text-sm text-muted-foreground mt-1">
                    <Clock className="w-4 h-4 inline mr-1" />
                    {new Date().toLocaleTimeString("ko-KR", {
                      hour: "2-digit",
                      minute: "2-digit",
                    })}{" "}
                    기록됨
                  </p>
                </div>

                <div className="text-center text-sm text-muted-foreground">
                  3초 후 자동으로 스캔 화면으로 돌아갑니다...
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </main>
    </div>
  )
}
