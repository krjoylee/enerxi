import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Calendar, TrendingUp, TrendingDown, Package, Clock, ArrowLeft } from "lucide-react"
import Link from "next/link"

// Sample diary data
const monthlyData = [
  { month: "1월", items: 45, calories: 18500, cost: 67500 },
  { month: "2월", items: 52, calories: 21200, cost: 78000 },
  { month: "3월", items: 38, calories: 15800, cost: 57000 },
  { month: "4월", items: 61, calories: 24800, cost: 91500 },
  { month: "5월", items: 48, calories: 19600, cost: 72000 },
  { month: "6월", items: 55, calories: 22400, cost: 82500 },
]

const recentConsumption = [
  { date: "2024-06-15", time: "14:30", item: "허니버터칩", calories: 555, category: "과자류", cost: 1500 },
  { date: "2024-06-15", time: "10:15", item: "아메리카노", calories: 5, category: "음료", cost: 1200 },
  { date: "2024-06-14", time: "15:45", item: "초코파이", calories: 168, category: "과자류", cost: 800 },
  { date: "2024-06-14", time: "11:20", item: "바나나킥", calories: 478, category: "과자류", cost: 1000 },
  { date: "2024-06-13", time: "16:10", item: "오레오", calories: 234, category: "과자류", cost: 1200 },
  { date: "2024-06-13", time: "13:30", item: "녹차", calories: 2, category: "음료", cost: 800 },
  { date: "2024-06-12", time: "14:20", item: "견과류 믹스", calories: 312, category: "견과류", cost: 2000 },
  { date: "2024-06-12", time: "10:45", item: "아메리카노", calories: 5, category: "음료", cost: 1200 },
]

const categoryStats = [
  { category: "과자류", count: 28, percentage: 51, color: "#0891b2" },
  { category: "음료", count: 15, percentage: 27, color: "#ec4899" },
  { category: "견과류", count: 8, percentage: 15, color: "#10b981" },
  { category: "초콜릿", count: 4, percentage: 7, color: "#f59e0b" },
]

export default function DiaryPage() {
  return (
    <div className="min-h-screen bg-background p-6">
      <div className="max-w-6xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Link href="/employee-dashboard">
              <Button variant="outline" size="sm">
                <ArrowLeft className="w-4 h-4 mr-2" />
                홈으로
              </Button>
            </Link>
            <div>
              <h1 className="text-3xl font-bold text-foreground">간식 다이어리</h1>
              <p className="text-muted-foreground mt-1">탕비실에서 가져간 간식 현황을 확인하세요</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Calendar className="w-5 h-5 text-muted-foreground" />
            <span className="text-sm text-muted-foreground">2024년 6월</span>
          </div>
        </div>

        {/* Summary Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">이번 달 총 간식</CardTitle>
              <Package className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">55개</div>
              <p className="text-xs text-muted-foreground">
                <span className="text-primary">+14.6%</span> 전월 대비
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">총 칼로리</CardTitle>
              <TrendingUp className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">22,400</div>
              <p className="text-xs text-muted-foreground">
                <span className="text-primary">+14.3%</span> 전월 대비
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">일평균 칼로리</CardTitle>
              <TrendingDown className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">747</div>
              <p className="text-xs text-muted-foreground">
                <span className="text-destructive">-2.1%</span> 전월 대비
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">총 비용</CardTitle>
              <TrendingUp className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">₩82,500</div>
              <p className="text-xs text-muted-foreground">
                <span className="text-primary">+14.6%</span> 전월 대비
              </p>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="recent" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="recent">최근 기록</TabsTrigger>
            <TabsTrigger value="monthly">월별 현황</TabsTrigger>
            <TabsTrigger value="categories">카테고리별</TabsTrigger>
            <TabsTrigger value="analysis">분석</TabsTrigger>
          </TabsList>

          <TabsContent value="recent" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>최근 간식 섭취 기록</CardTitle>
                <CardDescription>지난 7일간의 상세 섭취 내역</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {recentConsumption.map((item, index) => (
                    <div key={index} className="flex items-center justify-between p-4 bg-muted/50 rounded-lg">
                      <div className="flex items-center gap-4">
                        <div className="text-center">
                          <p className="text-sm font-medium">{item.date.split("-")[2]}</p>
                          <p className="text-xs text-muted-foreground">6월</p>
                        </div>
                        <div className="flex items-center gap-2 text-sm text-muted-foreground">
                          <Clock className="w-4 h-4" />
                          {item.time}
                        </div>
                        <div>
                          <p className="font-medium">{item.item}</p>
                          <div className="flex items-center gap-2 mt-1">
                            <Badge variant="secondary" className="text-xs">
                              {item.category}
                            </Badge>
                            <span className="text-sm text-muted-foreground">{item.calories} kcal</span>
                          </div>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="font-medium">₩{item.cost.toLocaleString()}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="monthly" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>월별 소비 추이</CardTitle>
                <CardDescription>최근 6개월간 간식 소비 패턴</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="grid grid-cols-6 gap-4">
                    {monthlyData.map((data, index) => (
                      <div key={index} className="text-center">
                        <div className="mb-2">
                          <div
                            className="w-full bg-primary rounded-t-lg mx-auto"
                            style={{ height: `${(data.items / 70) * 200}px`, minHeight: "20px" }}
                          />
                          <div
                            className="w-full bg-chart-2 rounded-b-lg mx-auto"
                            style={{ height: `${(data.calories / 25000) * 100}px`, minHeight: "10px" }}
                          />
                        </div>
                        <p className="text-xs font-medium">{data.month}</p>
                        <p className="text-xs text-muted-foreground">{data.items}개</p>
                        <p className="text-xs text-muted-foreground">{data.calories.toLocaleString()}kcal</p>
                      </div>
                    ))}
                  </div>
                  <div className="flex justify-center gap-6 mt-4">
                    <div className="flex items-center gap-2">
                      <div className="w-3 h-3 bg-primary rounded"></div>
                      <span className="text-sm">간식 개수</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="w-3 h-3 bg-chart-2 rounded"></div>
                      <span className="text-sm">총 칼로리</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="categories" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>카테고리별 소비량</CardTitle>
                  <CardDescription>이번 달 간식 종류별 분포</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {categoryStats.map((category) => (
                      <div key={category.category} className="space-y-2">
                        <div className="flex justify-between items-center">
                          <span className="font-medium">{category.category}</span>
                          <span className="text-sm text-muted-foreground">
                            {category.count}개 ({category.percentage}%)
                          </span>
                        </div>
                        <div className="w-full bg-muted rounded-full h-2">
                          <div
                            className="h-2 rounded-full bg-primary"
                            style={{
                              width: `${category.percentage}%`,
                            }}
                          />
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>일별 소비 패턴</CardTitle>
                  <CardDescription>요일별 평균 간식 소비량</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {[
                      { day: "월", count: 8.2 },
                      { day: "화", count: 9.1 },
                      { day: "수", count: 7.8 },
                      { day: "목", count: 8.9 },
                      { day: "금", count: 6.4 },
                      { day: "토", count: 2.1 },
                      { day: "일", count: 1.8 },
                    ].map((item) => (
                      <div key={item.day} className="flex items-center gap-4">
                        <div className="w-8 text-sm font-medium">{item.day}</div>
                        <div className="flex-1 bg-muted rounded-full h-6 relative">
                          <div
                            className="bg-primary h-6 rounded-full flex items-center justify-end pr-2"
                            style={{ width: `${(item.count / 10) * 100}%` }}
                          >
                            <span className="text-xs text-primary-foreground font-medium">{item.count}</span>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="analysis" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>건강 지표 분석</CardTitle>
                  <CardDescription>간식 섭취로 인한 영양소 분석</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex justify-between items-center p-3 bg-primary/10 rounded-lg">
                      <div>
                        <p className="font-medium">일평균 칼로리</p>
                        <p className="text-sm text-muted-foreground">권장량 대비 49.8%</p>
                      </div>
                      <div className="text-right">
                        <p className="text-2xl font-bold text-primary">747</p>
                        <p className="text-sm text-primary">양호</p>
                      </div>
                    </div>
                    <div className="flex justify-between items-center p-3 bg-accent/10 rounded-lg">
                      <div>
                        <p className="font-medium">당분 섭취량</p>
                        <p className="text-sm text-muted-foreground">권장량 대비 78.2%</p>
                      </div>
                      <div className="text-right">
                        <p className="text-2xl font-bold text-accent">39.1g</p>
                        <p className="text-sm text-accent">주의</p>
                      </div>
                    </div>
                    <div className="flex justify-between items-center p-3 bg-chart-3/10 rounded-lg">
                      <div>
                        <p className="font-medium">나트륨 섭취량</p>
                        <p className="text-sm text-muted-foreground">권장량 대비 32.1%</p>
                      </div>
                      <div className="text-right">
                        <p className="text-2xl font-bold text-chart-3">642mg</p>
                        <p className="text-sm text-chart-3">양호</p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>개선 제안</CardTitle>
                  <CardDescription>더 건강한 간식 선택을 위한 추천</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="p-3 border-l-4 border-primary bg-primary/10">
                      <p className="font-medium text-primary">견과류 섭취 증가</p>
                      <p className="text-sm text-muted-foreground">
                        단백질과 건강한 지방 공급을 위해 견과류 섭취를 늘려보세요.
                      </p>
                    </div>
                    <div className="p-3 border-l-4 border-chart-3 bg-chart-3/10">
                      <p className="font-medium text-chart-3">수분 섭취 권장</p>
                      <p className="text-sm text-muted-foreground">단 음료 대신 물이나 무가당 차를 선택해보세요.</p>
                    </div>
                    <div className="p-3 border-l-4 border-accent bg-accent/10">
                      <p className="font-medium text-accent">간식 시간 조절</p>
                      <p className="text-sm text-muted-foreground">
                        오후 3-4시 사이 간식 섭취를 줄이고 점심 후 산책을 권장합니다.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
