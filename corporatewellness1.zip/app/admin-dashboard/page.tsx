"use client"

import { Button } from "@/components/ui/button"
import { Slider } from "@/components/ui/slider"
import {
  TrendingUp,
  Settings,
  Package,
  Users,
  Bell,
  ShoppingCart,
  LogOut,
  DollarSign,
  Target,
  Calculator,
  Search,
  BarChart3,
  Building,
} from "lucide-react"
import Image from "next/image"
import { useState } from "react"
import { useRouter } from "next/navigation"

export default function AdminDashboard() {
  const router = useRouter()
  const [selectedTab, setSelectedTab] = useState("overview")
  const [users, setUsers] = useState([
    { id: "1", name: "김철수", employeeId: "EMP001", team: "개발팀", status: "활성" },
    { id: "2", name: "이영희", employeeId: "EMP002", team: "마케팅팀", status: "활성" },
    { id: "3", name: "박민수", employeeId: "EMP003", team: "인사팀", status: "활성" },
  ])
  const [showSettings, setShowSettings] = useState(false)
  const [showOrderModal, setShowOrderModal] = useState(false)
  const [selectedNotification, setSelectedNotification] = useState(null)
  const [orderQuantity, setOrderQuantity] = useState(1)
  const [consumptionAdjustment, setConsumptionAdjustment] = useState(0)
  const [showFloorModal, setShowFloorModal] = useState(false)
  const [selectedFloor, setSelectedFloor] = useState(null)
  const [usageTrendTab, setUsageTrendTab] = useState("monthly")
  const [notificationFilter, setNotificationFilter] = useState("전체")
  const [notificationSearch, setNotificationSearch] = useState("")

  const budgetData = {
    annual: 50000000,
    spent: 32500000,
    remaining: 17500000,
    monthlyForecast: 4200000,
  }

  const floorInventoryData = [
    {
      floor: "1층",
      machines: 3,
      totalCapacity: 180,
      currentStock: 142,
      dailyConsumption: 28,
      stockLevel: Math.round((142 / 180) * 100),
      topItems: [
        { name: "초코파이", stock: 15, capacity: 20, consumption: 8 },
        { name: "새우깡", stock: 12, capacity: 15, consumption: 6 },
        { name: "허니버터칩", stock: 8, capacity: 12, consumption: 5 },
      ],
    },
    {
      floor: "2층",
      machines: 2,
      totalCapacity: 120,
      currentStock: 95,
      dailyConsumption: 22,
      stockLevel: Math.round((95 / 120) * 100),
      topItems: [
        { name: "바나나킥", stock: 10, capacity: 15, consumption: 7 },
        { name: "닥터유 단백질바", stock: 8, capacity: 10, consumption: 4 },
        { name: "하루견과", stock: 6, capacity: 8, consumption: 3 },
      ],
    },
    {
      floor: "3층",
      machines: 2,
      totalCapacity: 120,
      currentStock: 88,
      dailyConsumption: 19,
      stockLevel: Math.round((88 / 120) * 100),
      topItems: [
        { name: "곤약젤리", stock: 12, capacity: 15, consumption: 6 },
        { name: "블루다이아몬드 아몬드", stock: 9, capacity: 12, consumption: 4 },
        { name: "불가리스", stock: 7, capacity: 10, consumption: 3 },
      ],
    },
  ]

  const notificationData = [
    {
      item: "닥터유 단백질바",
      stock: 12,
      minStock: 20,
      location: "1층",
      urgency: "보통",
      orderMode: "수동",
      message: "재고가 부족합니다. 발주를 진행해주세요.",
      time: "10분 전",
      estimatedStockout: "내일 오후",
      unitPrice: 2500,
      supplier: "헬스푸드코리아",
      category: "단백질바",
    },
    {
      item: "하루견과",
      stock: 8,
      minStock: 15,
      location: "2층",
      urgency: "긴급",
      orderMode: "수동",
      message: "재고가 부족합니다. 발주를 진행해주세요.",
      time: "15분 전",
      estimatedStockout: "오늘 오후",
      unitPrice: 3000,
      supplier: "견과류마켓",
      category: "견과류",
    },
    {
      item: "곤약젤리 (헬로네이처)",
      stock: 5,
      minStock: 10,
      location: "3층",
      urgency: "긴급",
      orderMode: "수동",
      message: "재고가 부족합니다. 발주를 진행해주세요.",
      time: "20분 전",
      estimatedStockout: "오늘 오전",
      unitPrice: 1800,
      supplier: "헬로네이처",
      category: "젤리",
    },
    {
      item: "초코파이",
      stock: 6,
      minStock: 12,
      location: "1층",
      urgency: "보통",
      orderMode: "수동",
      message: "재고가 부족합니다. 발주를 진행해주세요.",
      time: "25분 전",
      estimatedStockout: "내일 오전",
      unitPrice: 1500,
      supplier: "오리온",
      category: "과자",
    },
    {
      item: "새우깡",
      stock: 4,
      minStock: 10,
      location: "2층",
      urgency: "긴급",
      orderMode: "수동",
      message: "재고가 부족합니다. 발주를 진행해주세요.",
      time: "30분 전",
      estimatedStockout: "오늘 저녁",
      unitPrice: 2000,
      supplier: "농심",
      category: "스낵",
    },
  ]

  const usageTrendData = {
    monthly: [
      { period: "1월", usage: 2340, revenue: 4680000 },
      { period: "2월", usage: 2180, revenue: 4360000 },
      { period: "3월", usage: 2520, revenue: 5040000 },
      { period: "4월", usage: 2890, revenue: 5780000 },
      { period: "5월", usage: 3120, revenue: 6240000 },
      { period: "6월", usage: 2950, revenue: 5900000 },
    ],
    daily: [
      { period: "월", usage: 520, peak: "14:00" },
      { period: "화", usage: 480, peak: "15:30" },
      { period: "수", usage: 510, peak: "14:30" },
      { period: "목", usage: 490, peak: "15:00" },
      { period: "금", usage: 460, peak: "16:00" },
      { period: "토", usage: 180, peak: "12:00" },
      { period: "일", usage: 120, peak: "13:00" },
    ],
    hourly: [
      { period: "06", usage: 12, items: ["커피", "에너지바"] },
      { period: "07", usage: 28, items: ["커피", "샌드위치"] },
      { period: "08", usage: 45, items: ["커피", "베이글"] },
      { period: "09", usage: 68, items: ["커피", "과자"] },
      { period: "10", usage: 82, items: ["커피", "초콜릿"] },
      { period: "11", usage: 95, items: ["음료", "과자"] },
      { period: "12", usage: 120, items: ["도시락", "음료"] },
      { period: "13", usage: 110, items: ["도시락", "과자"] },
      { period: "14", usage: 135, items: ["커피", "초콜릿"] },
      { period: "15", usage: 125, items: ["커피", "과자"] },
      { period: "16", usage: 98, items: ["음료", "초콜릿"] },
      { period: "17", usage: 75, items: ["커피", "과자"] },
      { period: "18", usage: 52, items: ["음료", "샐러드"] },
    ],
  }

  const GlassCard = ({ children, className = "", onClick }: any) => (
    <div
      className={`backdrop-blur-md bg-white/70 border border-white/20 rounded-2xl shadow-xl hover:shadow-2xl transition-all duration-300 ${className}`}
      onClick={onClick}
    >
      {children}
    </div>
  )

  const KPICard = ({ title, value, icon: Icon, color = "#0A1F44", trend }: any) => (
    <GlassCard className="p-6 cursor-pointer hover:scale-105">
      <div className="flex items-center justify-between">
        <div>
          <p className="text-sm font-medium text-gray-600 mb-1">{title}</p>
          <p className="text-3xl font-bold" style={{ color }}>
            {value}
          </p>
          {trend && <p className="text-xs text-gray-500 mt-1">{trend}</p>}
        </div>
        <div className="p-3 rounded-xl bg-white/50">
          <Icon className="w-8 h-8" style={{ color }} />
        </div>
      </div>
    </GlassCard>
  )

  const renderUsageTrendChart = () => {
    const data = usageTrendData[usageTrendTab as keyof typeof usageTrendData]
    const maxUsage = Math.max(...data.map((d) => d.usage))
    const minUsage = Math.min(...data.map((d) => d.usage))
    const range = maxUsage - minUsage || 1

    const yAxisValues = [
      maxUsage,
      Math.round(maxUsage * 0.75),
      Math.round(maxUsage * 0.5),
      Math.round(maxUsage * 0.25),
      minUsage,
    ]

    const points = data
      .map((item, index) => {
        const x = (index / (data.length - 1)) * 85 + 10
        const y = 90 - ((item.usage - minUsage) / range) * 70
        return `${x},${y}`
      })
      .join(" ")

    return (
      <div className="relative h-80 w-full">
        <div className="absolute left-0 top-0 h-full flex flex-col justify-between text-xs text-gray-600 pr-2 z-10">
          {yAxisValues.map((value, index) => (
            <span key={index} className="text-right font-medium">
              {value}
            </span>
          ))}
        </div>

        <div className="ml-12 h-full">
          <svg viewBox="0 0 100 100" className="w-full h-full">
            {yAxisValues.map((_, index) => (
              <line
                key={index}
                x1="10"
                y1={10 + (index * 70) / 4}
                x2="95"
                y2={10 + (index * 70) / 4}
                stroke="#e5e7eb"
                strokeWidth="0.2"
              />
            ))}

            <defs>
              <linearGradient id="usageGradient" x1="0%" y1="0%" x2="0%" y2="100%">
                <stop offset="0%" stopColor="#10B981" stopOpacity="0.3" />
                <stop offset="100%" stopColor="#10B981" stopOpacity="0.1" />
              </linearGradient>
            </defs>

            <polygon
              points={`10,90 ${points} ${data
                .map((_, index) => `${(index / (data.length - 1)) * 85 + 10},90`)
                .reverse()
                .join(" ")}`}
              fill="url(#usageGradient)"
            />

            <polyline
              points={points}
              fill="none"
              stroke="#10B981"
              strokeWidth="3"
              strokeLinecap="round"
              strokeLinejoin="round"
            />

            {data.map((item, index) => {
              const x = (index / (data.length - 1)) * 85 + 10
              const y = 90 - ((item.usage - minUsage) / range) * 70

              let tooltipContent = `${item.period}: ${item.usage}회`
              if ("revenue" in item) tooltipContent += `, ${(item.revenue / 1000000).toFixed(1)}M원`
              if ("peak" in item) tooltipContent += `, 피크: ${item.peak}`
              if ("items" in item) tooltipContent += `, 인기: ${item.items.join(", ")}`

              return (
                <circle
                  key={index}
                  cx={x}
                  cy={y}
                  r="4"
                  fill="#10B981"
                  className="hover:r-6 transition-all duration-200 cursor-pointer"
                >
                  <title>{tooltipContent}</title>
                </circle>
              )
            })}
          </svg>
        </div>

        <div className="ml-12 flex justify-between text-xs text-gray-600 mt-2">
          {data.map((item, index) => (
            <span key={index} className="font-medium">
              {usageTrendTab === "hourly" ? `${item.period}시` : item.period}
            </span>
          ))}
        </div>
      </div>
    )
  }

  const renderDualLineChart = () => {
    const actualData = [
      { month: "1월", actual: 3800000 },
      { month: "2월", actual: 4100000 },
      { month: "3월", actual: 3900000 },
      { month: "4월", actual: 4300000 },
      { month: "5월", actual: 4000000 },
      { month: "6월", actual: 4200000 },
    ]

    const forecastData = [
      ...actualData.map((d) => ({ month: d.month, forecast: d.actual })),
      { month: "7월", forecast: budgetData.monthlyForecast * (1 + consumptionAdjustment / 100) },
      { month: "8월", forecast: budgetData.monthlyForecast * (1 + consumptionAdjustment / 100) * 1.1 },
    ]

    const allValues = [...actualData.map((d) => d.actual), ...forecastData.map((d) => d.forecast)]
    const maxValue = Math.max(...allValues)
    const minValue = Math.min(...allValues)
    const range = maxValue - minValue || 1

    const yAxisValues = [
      maxValue,
      Math.round(maxValue * 0.75),
      Math.round(maxValue * 0.5),
      Math.round(maxValue * 0.25),
      minValue,
    ]

    return (
      <div className="relative h-80 w-full">
        <div className="absolute left-0 top-0 h-full flex flex-col justify-between text-xs text-gray-600 pr-2 z-10">
          {yAxisValues.map((value, index) => (
            <span key={index} className="text-right font-medium">
              {(value / 1000000).toFixed(1)}M
            </span>
          ))}
        </div>

        <div className="ml-12 h-full">
          <svg viewBox="0 0 100 100" className="w-full h-full">
            {yAxisValues.map((_, index) => (
              <line
                key={index}
                x1="10"
                y1={10 + (index * 70) / 4}
                x2="95"
                y2={10 + (index * 70) / 4}
                stroke="#e5e7eb"
                strokeWidth="0.2"
              />
            ))}

            <defs>
              <linearGradient id="actualGradient" x1="0%" y1="0%" x2="0%" y2="100%">
                <stop offset="0%" stopColor="#0A1F44" stopOpacity="0.3" />
                <stop offset="100%" stopColor="#0A1F44" stopOpacity="0.1" />
              </linearGradient>
            </defs>

            <polyline
              points={actualData
                .map((item, index) => {
                  const x = (index / (forecastData.length - 1)) * 85 + 10
                  const y = 90 - ((item.actual - minValue) / range) * 70
                  return `${x},${y}`
                })
                .join(" ")}
              fill="none"
              stroke="#0A1F44"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
            />

            <polyline
              points={forecastData
                .map((item, index) => {
                  const x = (index / (forecastData.length - 1)) * 85 + 10
                  const y = 90 - ((item.forecast - minValue) / range) * 70
                  return `${x},${y}`
                })
                .join(" ")}
              fill="none"
              stroke="#10B981"
              strokeWidth="2"
              strokeDasharray="4,4"
              strokeLinecap="round"
              strokeLinejoin="round"
              opacity="0.8"
            />
          </svg>
        </div>

        <div className="ml-12 flex justify-between text-xs text-gray-600 mt-2">
          {forecastData.map((item, index) => (
            <span key={index} className={index % 2 === 0 ? "font-medium" : "opacity-70"}>
              {item.month}
            </span>
          ))}
        </div>

        <div className="flex justify-center mt-4 space-x-6">
          <div className="flex items-center space-x-2">
            <div className="w-4 h-0.5 bg-[#0A1F44]"></div>
            <span className="text-sm text-gray-700 font-medium">실제 집행액</span>
          </div>
          <div className="flex items-center space-x-2">
            <div className="w-4 h-0.5 bg-[#10B981] opacity-80"></div>
            <span className="text-gray-700 font-medium">예상 집행액</span>
          </div>
        </div>
      </div>
    )
  }

  const handleOrderClick = (notification: any) => {
    console.log(`[v0] Opening order modal for ${notification.item}`)
    setSelectedNotification(notification)
    setOrderQuantity(Math.max(1, notification.minStock - notification.stock))
    setShowOrderModal(true)
  }

  const handleOrderSubmit = () => {
    if (selectedNotification) {
      const totalCost = orderQuantity * selectedNotification.unitPrice
      console.log(`[v0] Submitting order:`, {
        item: selectedNotification.item,
        quantity: orderQuantity,
        location: selectedNotification.location,
        supplier: selectedNotification.supplier,
        unitPrice: selectedNotification.unitPrice,
        totalCost: totalCost,
      })

      alert(
        `${selectedNotification.item} ${orderQuantity}개 발주가 완료되었습니다.\n총 비용: ${totalCost.toLocaleString()}원\n공급업체: ${selectedNotification.supplier}`,
      )
      setShowOrderModal(false)
      setSelectedNotification(null)
      setOrderQuantity(1)
    }
  }

  const filteredNotifications = notificationData.filter((item) => {
    const matchesSearch = item.item.toLowerCase().includes(notificationSearch.toLowerCase())
    const matchesFilter = notificationFilter === "전체" || item.urgency === notificationFilter
    return matchesSearch && matchesFilter
  })

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50">
      <div className="max-w-7xl mx-auto p-6">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center space-x-4">
            <Image
              src="/images/enerxizer-logo.png"
              alt="enerXIzer Logo"
              width={200}
              height={60}
              className="h-10 w-auto"
            />
            <div>
              <h1 className="text-3xl font-bold text-[#0A1F44]">enerXIzer 관리자</h1>
              <p className="text-gray-600">스마트 오피스 스낵바 관리 시스템</p>
            </div>
          </div>
          <div className="flex items-center space-x-4">
            <Button
              onClick={() => setShowSettings(true)}
              className="bg-white/80 hover:bg-white text-[#0A1F44] border border-gray-200"
            >
              <Settings className="w-4 h-4 mr-2" />
              설정
            </Button>
            <Button onClick={() => router.push("/")} className="bg-[#0A1F44] hover:bg-[#0A1F44]/90 text-white">
              <LogOut className="w-4 h-4 mr-2" />
              로그아웃
            </Button>
          </div>
        </div>

        {/* KPI Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <KPICard title="총 사용자" value={users.length} icon={Users} color="#0A1F44" trend="전월 대비 +12%" />
          <KPICard title="일일 평균 이용" value="847회" icon={TrendingUp} color="#10B981" trend="전일 대비 +5.2%" />
          <KPICard title="재고 알림" value="5건" icon={Package} color="#F59E0B" trend="긴급 2건 포함" />
          <KPICard title="주문 대기" value="12건" icon={ShoppingCart} color="#EF4444" trend="처리 필요" />
        </div>

        {/* Budget Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <KPICard title="연간 예산" value="5,000만원" icon={DollarSign} color="#0A1F44" />
          <KPICard title="집행 금액" value="3,250만원" icon={Target} color="#10B981" trend="65% 집행" />
          <KPICard title="잔여 예산" value="1,750만원" icon={Calculator} color="#6366F1" trend="35% 잔여" />
          <KPICard title="월 예상 집행" value="420만원" icon={TrendingUp} color="#F59E0B" />
        </div>

        {/* Main Dashboard Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
          {/* Floor-by-Floor Snack Status */}
          <GlassCard className="p-6">
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center space-x-3">
                <div className="p-2 bg-[#0A1F44]/10 rounded-lg">
                  <Building className="w-6 h-6 text-[#0A1F44]" />
                </div>
                <h2 className="text-xl font-bold text-[#0A1F44]">층별 스낵 현황</h2>
              </div>
              <Button
                onClick={() => setShowFloorModal(true)}
                className="bg-[#0A1F44] hover:bg-[#0A1F44]/90 text-white text-sm px-4 py-2"
              >
                상세보기
              </Button>
            </div>

            <div className="space-y-4">
              {floorInventoryData.map((floor) => (
                <div key={floor.floor} className="bg-white/50 rounded-xl p-4">
                  <div className="flex items-center justify-between mb-3">
                    <h3 className="font-semibold text-[#0A1F44]">{floor.floor}</h3>
                    <span className="text-sm text-gray-600">{floor.machines}대 운영 중</span>
                  </div>

                  <div className="grid grid-cols-2 gap-4 mb-3">
                    <div className="text-center">
                      <p className="text-xs text-gray-600 mb-1">재고율</p>
                      <p className="text-lg font-bold text-[#10B981]">{floor.stockLevel}%</p>
                    </div>
                    <div className="text-center">
                      <p className="text-xs text-gray-600 mb-1">일일 소비</p>
                      <p className="text-lg font-bold text-[#0A1F44]">{floor.dailyConsumption}개</p>
                    </div>
                  </div>

                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div
                      className="bg-gradient-to-r from-[#10B981] to-[#0A1F44] h-2 rounded-full transition-all duration-300"
                      style={{ width: `${floor.stockLevel}%` }}
                    ></div>
                  </div>
                </div>
              ))}
            </div>
          </GlassCard>

          {/* Snack Bar Usage Trends */}
          <GlassCard className="p-6">
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center space-x-3">
                <div className="p-2 bg-[#10B981]/10 rounded-lg">
                  <BarChart3 className="w-6 h-6 text-[#10B981]" />
                </div>
                <h2 className="text-xl font-bold text-[#0A1F44]">스낵바 이용 추이</h2>
              </div>
            </div>

            <div className="flex space-x-1 mb-6 bg-gray-100 rounded-lg p-1">
              {[
                { key: "monthly", label: "월별" },
                { key: "daily", label: "요일별" },
                { key: "hourly", label: "시간대별" },
              ].map((tab) => (
                <button
                  key={tab.key}
                  onClick={() => setUsageTrendTab(tab.key)}
                  className={`flex-1 py-2 px-4 rounded-md text-sm font-medium transition-all duration-200 ${
                    usageTrendTab === tab.key
                      ? "bg-white text-[#0A1F44] shadow-sm"
                      : "text-gray-600 hover:text-[#0A1F44]"
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>

            <div className="grid grid-cols-3 gap-4 mb-6">
              <div className="bg-white/50 rounded-xl p-3 text-center">
                <p className="text-xs text-gray-600 mb-1">평균 이용</p>
                <p className="text-lg font-bold text-[#0A1F44]">
                  {Math.round(
                    usageTrendData[usageTrendTab as keyof typeof usageTrendData].reduce(
                      (sum, item) => sum + item.usage,
                      0,
                    ) / usageTrendData[usageTrendTab as keyof typeof usageTrendData].length,
                  )}
                  {usageTrendTab === "monthly" ? "회/월" : usageTrendTab === "daily" ? "회/일" : "회/시"}
                </p>
              </div>
              <div className="bg-white/50 rounded-xl p-3 text-center">
                <p className="text-xs text-gray-600 mb-1">최고 이용</p>
                <p className="text-lg font-bold text-[#10B981]">
                  {Math.max(...usageTrendData[usageTrendTab as keyof typeof usageTrendData].map((d) => d.usage))}회
                </p>
              </div>
              <div className="bg-white/50 rounded-xl p-3 text-center">
                <p className="text-xs text-gray-600 mb-1">증감률</p>
                <p className="text-lg font-bold text-[#F59E0B]">+12.5%</p>
              </div>
            </div>

            {renderUsageTrendChart()}
          </GlassCard>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Budget Simulation */}
          <GlassCard className="p-6">
            <div className="flex items-center space-x-3 mb-6">
              <div className="p-2 bg-[#6366F1]/10 rounded-lg">
                <Calculator className="w-6 h-6 text-[#6366F1]" />
              </div>
              <h2 className="text-xl font-bold text-[#0A1F44]">예산 시뮬레이션</h2>
            </div>

            <div className="mb-6">
              <div className="flex items-center justify-between mb-3">
                <label className="text-sm font-medium text-gray-700">소비량 조정</label>
                <span className="text-sm font-bold text-[#0A1F44]">
                  {consumptionAdjustment > 0 ? "+" : ""}
                  {consumptionAdjustment}%
                </span>
              </div>
              <Slider
                value={[consumptionAdjustment]}
                onValueChange={(value) => setConsumptionAdjustment(value[0])}
                max={50}
                min={-50}
                step={5}
                className="w-full"
              />
              <div className="flex justify-between text-xs text-gray-500 mt-1">
                <span>-50%</span>
                <span>0%</span>
                <span>+50%</span>
              </div>
            </div>

            <div className="bg-white/50 rounded-xl p-4 mb-6">
              <p className="text-sm text-gray-600 mb-1">월말 예상 집행액</p>
              <p className="text-2xl font-bold text-[#0A1F44]">
                {(budgetData.monthlyForecast * (1 + consumptionAdjustment / 100)).toLocaleString()}원
              </p>
              <p className="text-sm text-gray-500">
                기준 대비 {consumptionAdjustment > 0 ? "+" : ""}
                {((budgetData.monthlyForecast * consumptionAdjustment) / 100).toLocaleString()}원
              </p>
            </div>

            {renderDualLineChart()}
          </GlassCard>

          {/* Real-time Notifications */}
          <GlassCard className="p-6">
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center space-x-3">
                <div className="p-2 bg-[#EF4444]/10 rounded-lg">
                  <Bell className="w-6 h-6 text-[#EF4444]" />
                </div>
                <h2 className="text-xl font-bold text-[#0A1F44]">실시간 알림</h2>
              </div>
            </div>

            <div className="flex items-center space-x-3 mb-4">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
                <input
                  type="text"
                  placeholder="알림 검색..."
                  value={notificationSearch}
                  onChange={(e) => setNotificationSearch(e.target.value)}
                  className="w-full pl-10 pr-4 py-2 bg-white/50 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#0A1F44]/20"
                />
              </div>
            </div>

            <div className="flex flex-wrap gap-2 mb-4">
              {["전체", "긴급", "보통", "낮음"].map((filter) => (
                <button
                  key={filter}
                  onClick={() => setNotificationFilter(filter)}
                  className={`px-3 py-1 rounded-full text-xs font-medium transition-all duration-200 ${
                    notificationFilter === filter
                      ? "bg-[#0A1F44] text-white"
                      : "bg-white/50 text-gray-600 hover:bg-white/80"
                  }`}
                >
                  {filter}
                </button>
              ))}
            </div>

            <div className="space-y-3 max-h-96 overflow-y-auto">
              {filteredNotifications.map((notification, index) => (
                <div
                  key={`${notification.item}-${index}`}
                  className="bg-white/50 rounded-xl p-4 border-l-4"
                  style={{
                    borderLeftColor:
                      notification.urgency === "긴급"
                        ? "#EF4444"
                        : notification.urgency === "보통"
                          ? "#F59E0B"
                          : "#10B981",
                  }}
                >
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center space-x-2 mb-2">
                        <span className="font-semibold text-[#0A1F44]">{notification.location}</span>
                        <span
                          className={`px-2 py-1 rounded-full text-xs font-medium ${
                            notification.urgency === "긴급"
                              ? "bg-red-100 text-red-800"
                              : notification.urgency === "보통"
                                ? "bg-yellow-100 text-yellow-800"
                                : "bg-green-100 text-green-800"
                          }`}
                        >
                          {notification.urgency}
                        </span>
                      </div>
                      <div className="mb-2">
                        <p className="font-medium text-[#0A1F44]">{notification.item}</p>
                        <p className="text-sm text-gray-600">
                          현재 재고: {notification.stock}개 / 최소 재고: {notification.minStock}개
                        </p>
                      </div>
                      <p className="text-sm text-gray-700 mb-2">{notification.message}</p>
                      <div className="flex items-center justify-between text-xs text-gray-500">
                        <span>{notification.time}</span>
                        <span>예상 소진: {notification.estimatedStockout}</span>
                      </div>
                    </div>

                    <Button
                      onClick={() => handleOrderClick(notification)}
                      className="ml-4 bg-[#0A1F44] hover:bg-[#0A1F44]/90 text-white text-sm px-3 py-1 transition-all duration-200 hover:scale-105"
                    >
                      발주하기
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </GlassCard>
        </div>

        {showOrderModal && selectedNotification && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
            <GlassCard className="p-6 w-full max-w-md mx-4">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-bold text-[#0A1F44]">개별 상품 발주</h3>
                <Button onClick={() => setShowOrderModal(false)} className="text-gray-500 hover:text-gray-700 p-1">
                  ✕
                </Button>
              </div>

              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">상품명</label>
                  <p className="text-lg font-semibold text-[#0A1F44]">{selectedNotification.item}</p>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">위치</label>
                    <p className="text-gray-600">{selectedNotification.location}</p>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">카테고리</label>
                    <p className="text-gray-600">{selectedNotification.category}</p>
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">공급업체</label>
                  <p className="text-gray-600">{selectedNotification.supplier}</p>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">현재 재고</label>
                    <p className="text-red-600 font-semibold">{selectedNotification.stock}개</p>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">최소 재고</label>
                    <p className="text-gray-600">{selectedNotification.minStock}개</p>
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">단가</label>
                  <p className="text-[#0A1F44] font-semibold">{selectedNotification.unitPrice?.toLocaleString()}원</p>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">발주 수량</label>
                  <div className="flex items-center space-x-3">
                    <Button
                      onClick={() => setOrderQuantity(Math.max(1, orderQuantity - 1))}
                      className="w-8 h-8 p-0 bg-gray-200 hover:bg-gray-300 text-gray-700"
                    >
                      -
                    </Button>
                    <input
                      type="number"
                      value={orderQuantity}
                      onChange={(e) => setOrderQuantity(Math.max(1, Number.parseInt(e.target.value) || 1))}
                      className="w-20 text-center py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#0A1F44]/20"
                      min="1"
                    />
                    <Button
                      onClick={() => setOrderQuantity(orderQuantity + 1)}
                      className="w-8 h-8 p-0 bg-gray-200 hover:bg-gray-300 text-gray-700"
                    >
                      +
                    </Button>
                  </div>
                  <p className="text-xs text-gray-500 mt-1">
                    권장 수량: {selectedNotification.minStock - selectedNotification.stock}개
                  </p>
                </div>

                <div className="bg-gray-50 rounded-lg p-3">
                  <div className="flex justify-between text-sm">
                    <span>상품 비용:</span>
                    <span className="font-semibold">
                      {(orderQuantity * (selectedNotification.unitPrice || 2000)).toLocaleString()}원
                    </span>
                  </div>
                  <div className="flex justify-between text-sm text-gray-600">
                    <span>배송비:</span>
                    <span>무료</span>
                  </div>
                  <hr className="my-2" />
                  <div className="flex justify-between font-semibold">
                    <span>총 금액:</span>
                    <span className="text-[#0A1F44]">
                      {(orderQuantity * (selectedNotification.unitPrice || 2000)).toLocaleString()}원
                    </span>
                  </div>
                </div>

                <div className="flex space-x-3">
                  <Button
                    onClick={() => setShowOrderModal(false)}
                    className="flex-1 bg-gray-200 hover:bg-gray-300 text-gray-700"
                  >
                    취소
                  </Button>
                  <Button onClick={handleOrderSubmit} className="flex-1 bg-[#0A1F44] hover:bg-[#0A1F44]/90 text-white">
                    발주 요청
                  </Button>
                </div>
              </div>
            </GlassCard>
          </div>
        )}
      </div>
    </div>
  )
}
