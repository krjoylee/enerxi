"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Progress } from "@/components/ui/progress"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  TrendingUp,
  AlertTriangle,
  CheckCircle,
  Calendar,
  Target,
  Activity,
  ArrowLeft,
  Bell,
  Heart,
  Zap,
  Droplets,
  Wheat,
  Beef,
} from "lucide-react"
import Link from "next/link"
import { ChartContainer } from "@/components/ui/chart"

interface NutritionData {
  date: string
  calories: number
  protein: number
  carbs: number
  fat: number
  sugar: number
  sodium: number
}

interface DailyLimits {
  calories: number
  protein: number
  carbs: number
  fat: number
  sugar: number
  sodium: number
}

interface ConsumedItem {
  time: string
  name: string
  calories: number
  protein: number
  carbs: number
  fat: number
  sugar: number
  sodium: number
}

export default function NutritionPage() {
  const [selectedPeriod, setSelectedPeriod] = useState<"today" | "week" | "month">("today")

  // Mock data
  const dailyLimits: DailyLimits = {
    calories: 2000,
    protein: 150,
    carbs: 250,
    fat: 65,
    sugar: 50,
    sodium: 2300,
  }

  const todayConsumed = {
    calories: 1250,
    protein: 45,
    carbs: 180,
    fat: 35,
    sugar: 65,
    sodium: 1800,
  }

  const consumedItems: ConsumedItem[] = [
    { time: "09:30", name: "바나나우유", calories: 130, protein: 3, carbs: 22, fat: 3.5, sugar: 20, sodium: 45 },
    { time: "11:15", name: "초코칩 쿠키", calories: 180, protein: 2.5, carbs: 24, fat: 8.5, sugar: 12, sodium: 95 },
    { time: "14:20", name: "견과류 믹스", calories: 220, protein: 8, carbs: 12, fat: 18, sugar: 4, sodium: 120 },
    { time: "16:45", name: "요구르트", calories: 120, protein: 5, carbs: 18, fat: 2.5, sugar: 15, sodium: 65 },
    { time: "18:30", name: "프로틴바", calories: 200, protein: 20, carbs: 25, fat: 6, sugar: 8, sodium: 180 },
    { time: "20:10", name: "아이스크림", calories: 250, protein: 4, carbs: 32, fat: 12, sugar: 28, sodium: 85 },
    { time: "21:00", name: "과자", calories: 150, protein: 2, carbs: 20, fat: 7, sugar: 10, sodium: 200 },
  ]

  const weeklyData: NutritionData[] = [
    { date: "월", calories: 1800, protein: 120, carbs: 220, fat: 60, sugar: 45, sodium: 2100 },
    { date: "화", calories: 2100, protein: 140, carbs: 250, fat: 70, sugar: 55, sodium: 2400 },
    { date: "수", calories: 1900, protein: 130, carbs: 230, fat: 65, sugar: 50, sodium: 2200 },
    { date: "목", calories: 2200, protein: 150, carbs: 260, fat: 75, sugar: 60, sodium: 2500 },
    { date: "금", calories: 1250, protein: 45, carbs: 180, fat: 35, sugar: 65, sodium: 1800 },
    { date: "토", calories: 0, protein: 0, carbs: 0, fat: 0, sugar: 0, sodium: 0 },
    { date: "일", calories: 0, protein: 0, carbs: 0, fat: 0, sugar: 0, sodium: 0 },
  ]

  const macroData = [
    { name: "탄수화물", value: todayConsumed.carbs, color: "#22d3ee", limit: dailyLimits.carbs },
    { name: "단백질", value: todayConsumed.protein, color: "#ec4899", limit: dailyLimits.protein },
    { name: "지방", value: todayConsumed.fat, color: "#a5f3fc", limit: dailyLimits.fat },
  ]

  const getAlertLevel = (consumed: number, limit: number) => {
    const percentage = (consumed / limit) * 100
    if (percentage >= 100) return "danger"
    if (percentage >= 80) return "warning"
    return "normal"
  }

  const getProgressColor = (consumed: number, limit: number) => {
    const percentage = (consumed / limit) * 100
    if (percentage >= 100) return "bg-destructive"
    if (percentage >= 80) return "bg-accent"
    return "bg-primary"
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Link href="/">
                <Button variant="ghost" size="sm">
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  돌아가기
                </Button>
              </Link>
              <div className="flex items-center gap-3">
                <div className="flex items-center justify-center w-10 h-10 bg-accent rounded-lg">
                  <Activity className="w-6 h-6 text-accent-foreground" />
                </div>
                <div>
                  <h1 className="text-xl font-bold text-card-foreground">영양 추적</h1>
                  <p className="text-sm text-muted-foreground">일일 영양소 섭취 현황</p>
                </div>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Select value={selectedPeriod} onValueChange={(value: any) => setSelectedPeriod(value)}>
                <SelectTrigger className="w-32">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="today">오늘</SelectItem>
                  <SelectItem value="week">이번 주</SelectItem>
                  <SelectItem value="month">이번 달</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        <div className="max-w-6xl mx-auto space-y-8">
          {/* Alerts Section */}
          <div className="space-y-4">
            {getAlertLevel(todayConsumed.sugar, dailyLimits.sugar) === "danger" && (
              <Alert variant="destructive">
                <AlertTriangle className="h-4 w-4" />
                <AlertDescription>
                  <strong>당분 섭취 초과!</strong> 일일 권장량을{" "}
                  {Math.round((todayConsumed.sugar / dailyLimits.sugar - 1) * 100)}% 초과했습니다. 당분 섭취를 줄이는
                  것을 권장합니다.
                </AlertDescription>
              </Alert>
            )}

            {getAlertLevel(todayConsumed.sodium, dailyLimits.sodium) === "warning" && (
              <Alert>
                <Bell className="h-4 w-4" />
                <AlertDescription>
                  <strong>나트륨 주의!</strong> 일일 권장량의{" "}
                  {Math.round((todayConsumed.sodium / dailyLimits.sodium) * 100)}%를 섭취했습니다. 짠 음식 섭취를
                  줄여보세요.
                </AlertDescription>
              </Alert>
            )}
          </div>

          {/* Daily Overview Cards */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium flex items-center gap-2">
                  <Zap className="w-4 h-4 text-accent" />
                  칼로리
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <div className="flex items-baseline gap-2">
                    <span className="text-2xl font-bold text-foreground">{todayConsumed.calories}</span>
                    <span className="text-sm text-muted-foreground">/ {dailyLimits.calories}</span>
                  </div>
                  <Progress value={(todayConsumed.calories / dailyLimits.calories) * 100} className="h-2" />
                  <p className="text-xs text-muted-foreground">
                    {Math.round((todayConsumed.calories / dailyLimits.calories) * 100)}% 달성
                  </p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium flex items-center gap-2">
                  <Beef className="w-4 h-4 text-primary" />
                  단백질
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <div className="flex items-baseline gap-2">
                    <span className="text-2xl font-bold text-foreground">{todayConsumed.protein}g</span>
                    <span className="text-sm text-muted-foreground">/ {dailyLimits.protein}g</span>
                  </div>
                  <Progress value={(todayConsumed.protein / dailyLimits.protein) * 100} className="h-2" />
                  <p className="text-xs text-muted-foreground">
                    {Math.round((todayConsumed.protein / dailyLimits.protein) * 100)}% 달성
                  </p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium flex items-center gap-2">
                  <Wheat className="w-4 h-4 text-chart-3" />
                  탄수화물
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <div className="flex items-baseline gap-2">
                    <span className="text-2xl font-bold text-foreground">{todayConsumed.carbs}g</span>
                    <span className="text-sm text-muted-foreground">/ {dailyLimits.carbs}g</span>
                  </div>
                  <Progress value={(todayConsumed.carbs / dailyLimits.carbs) * 100} className="h-2" />
                  <p className="text-xs text-muted-foreground">
                    {Math.round((todayConsumed.carbs / dailyLimits.carbs) * 100)}% 달성
                  </p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium flex items-center gap-2">
                  <Droplets className="w-4 h-4 text-chart-2" />
                  지방
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <div className="flex items-baseline gap-2">
                    <span className="text-2xl font-bold text-foreground">{todayConsumed.fat}g</span>
                    <span className="text-sm text-muted-foreground">/ {dailyLimits.fat}g</span>
                  </div>
                  <Progress value={(todayConsumed.fat / dailyLimits.fat) * 100} className="h-2" />
                  <p className="text-xs text-muted-foreground">
                    {Math.round((todayConsumed.fat / dailyLimits.fat) * 100)}% 달성
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Critical Nutrients Alert */}
          <div className="grid md:grid-cols-2 gap-4">
            <Card className={todayConsumed.sugar > dailyLimits.sugar ? "border-destructive/50" : ""}>
              <CardHeader>
                <CardTitle className="text-sm font-medium flex items-center justify-between">
                  <span className="flex items-center gap-2">
                    <Heart className="w-4 h-4 text-destructive" />
                    당분
                  </span>
                  {todayConsumed.sugar > dailyLimits.sugar && <Badge variant="destructive">초과</Badge>}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <div className="flex items-baseline gap-2">
                    <span className="text-2xl font-bold text-foreground">{todayConsumed.sugar}g</span>
                    <span className="text-sm text-muted-foreground">/ {dailyLimits.sugar}g</span>
                  </div>
                  <Progress value={Math.min((todayConsumed.sugar / dailyLimits.sugar) * 100, 100)} className="h-2" />
                  <p className="text-xs text-muted-foreground">
                    {Math.round((todayConsumed.sugar / dailyLimits.sugar) * 100)}% 달성
                  </p>
                </div>
              </CardContent>
            </Card>

            <Card className={todayConsumed.sodium > dailyLimits.sodium * 0.8 ? "border-accent/50" : ""}>
              <CardHeader>
                <CardTitle className="text-sm font-medium flex items-center justify-between">
                  <span className="flex items-center gap-2">
                    <Target className="w-4 h-4 text-accent" />
                    나트륨
                  </span>
                  {todayConsumed.sodium > dailyLimits.sodium * 0.8 && (
                    <Badge variant="secondary" className="bg-accent/10 text-accent">
                      주의
                    </Badge>
                  )}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <div className="flex items-baseline gap-2">
                    <span className="text-2xl font-bold text-foreground">{todayConsumed.sodium}mg</span>
                    <span className="text-sm text-muted-foreground">/ {dailyLimits.sodium}mg</span>
                  </div>
                  <Progress value={(todayConsumed.sodium / dailyLimits.sodium) * 100} className="h-2" />
                  <p className="text-xs text-muted-foreground">
                    {Math.round((todayConsumed.sodium / dailyLimits.sodium) * 100)}% 달성
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Charts and Details */}
          <div className="grid lg:grid-cols-2 gap-8">
            {/* Macro Distribution */}
            <Card>
              <CardHeader>
                <CardTitle className="text-card-foreground">오늘의 영양소 분포</CardTitle>
                <CardDescription>주요 영양소별 섭취 현황</CardDescription>
              </CardHeader>
              <CardContent>
                <ChartContainer
                  config={{
                    value: {
                      label: "비율",
                      color: "hsl(var(--chart-1))",
                    },
                  }}
                  className="h-64"
                >
                  <div className="space-y-4">
                    {macroData.map((item, index) => (
                      <div key={index} className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <div className="w-4 h-4 rounded-full" style={{ backgroundColor: item.color }} />
                          <span className="text-sm font-medium">{item.name}</span>
                        </div>
                        <div className="text-right">
                          <div className="text-lg font-bold">{item.value}g</div>
                          <div className="text-xs text-muted-foreground">/ {item.limit}g</div>
                        </div>
                      </div>
                    ))}
                  </div>
                </ChartContainer>
              </CardContent>
            </Card>

            {/* Weekly Trend */}
            <Card>
              <CardHeader>
                <CardTitle className="text-card-foreground">주간 칼로리 추이</CardTitle>
                <CardDescription>이번 주 일별 칼로리 섭취량</CardDescription>
              </CardHeader>
              <CardContent>
                <ChartContainer
                  config={{
                    calories: {
                      label: "칼로리",
                      color: "hsl(var(--chart-1))",
                    },
                  }}
                  className="h-64"
                >
                  <div className="space-y-2">
                    {weeklyData.map((day, index) => (
                      <div key={index} className="flex items-center justify-between p-2 bg-muted/50 rounded">
                        <span className="text-sm font-medium">{day.date}</span>
                        <div className="flex items-center gap-2">
                          <div className="w-20 h-2 bg-muted rounded-full overflow-hidden">
                            <div
                              className="h-full bg-chart-1 rounded-full"
                              style={{ width: `${(day.calories / 2500) * 100}%` }}
                            />
                          </div>
                          <span className="text-sm text-muted-foreground">{day.calories} kcal</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </ChartContainer>
              </CardContent>
            </Card>
          </div>

          {/* Today's Consumption Log */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-card-foreground">
                <Calendar className="w-5 h-5 text-primary" />
                오늘의 섭취 기록
              </CardTitle>
              <CardDescription>시간별 간식 섭취 내역</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {consumedItems.map((item, index) => (
                  <div key={index} className="flex items-center justify-between p-4 bg-muted/50 rounded-lg">
                    <div className="flex items-center gap-4">
                      <div className="text-sm font-medium text-accent">{item.time}</div>
                      <div>
                        <h4 className="font-medium text-foreground">{item.name}</h4>
                        <p className="text-sm text-muted-foreground">
                          {item.calories} kcal • 단백질 {item.protein}g • 탄수화물 {item.carbs}g • 지방 {item.fat}g
                        </p>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="text-lg font-bold text-accent">{item.calories}</div>
                      <div className="text-xs text-muted-foreground">kcal</div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Recommendations */}
          <Card className="border-primary/20">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-card-foreground">
                <TrendingUp className="w-5 h-5 text-primary" />
                맞춤형 건강 권장사항
              </CardTitle>
              <CardDescription>개인 건강 프로필을 바탕으로 한 추천</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-start gap-3 p-3 bg-accent/10 rounded-lg">
                  <CheckCircle className="w-5 h-5 text-accent mt-0.5" />
                  <div>
                    <h4 className="font-medium text-foreground">단백질 섭취 부족</h4>
                    <p className="text-sm text-muted-foreground">
                      목표 단백질 섭취량에 70% 부족합니다. 견과류, 요구르트, 프로틴바 등을 추천합니다.
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-3 p-3 bg-destructive/10 rounded-lg">
                  <AlertTriangle className="w-5 h-5 text-destructive mt-0.5" />
                  <div>
                    <h4 className="font-medium text-foreground">당분 섭취 초과</h4>
                    <p className="text-sm text-muted-foreground">
                      일일 권장 당분량을 30% 초과했습니다. 당분이 적은 간식을 선택해보세요.
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-3 p-3 bg-primary/10 rounded-lg">
                  <Heart className="w-5 h-5 text-primary mt-0.5" />
                  <div>
                    <h4 className="font-medium text-foreground">균형 잡힌 식단</h4>
                    <p className="text-sm text-muted-foreground">
                      탄수화물과 지방 섭취가 적절합니다. 이 패턴을 유지하시기 바랍니다.
                    </p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  )
}
