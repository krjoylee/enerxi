"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import Image from "next/image"
import { useState, useRef, useEffect } from "react"
import { useRouter } from "next/navigation"

export default function HomePage() {
  const [employeeId, setEmployeeId] = useState("")
  const [adminEmail, setAdminEmail] = useState("")
  const [adminPassword, setAdminPassword] = useState("")
  const [showCamera, setShowCamera] = useState(false)
  const [cameraError, setCameraError] = useState("")
  const videoRef = useRef<HTMLVideoElement>(null)
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const streamRef = useRef<MediaStream | null>(null)
  const router = useRouter()

  const startCamera = async () => {
    try {
      setCameraError("")
      console.log("[v0] Starting camera access...")

      let stream: MediaStream | null = null

      // Try with preferred constraints first
      try {
        stream = await navigator.mediaDevices.getUserMedia({
          video: {
            facingMode: "environment",
            width: { ideal: 1280, min: 640 },
            height: { ideal: 720, min: 480 },
          },
        })
        console.log("[v0] Camera started with environment facing mode")
      } catch (envError) {
        console.log("[v0] Environment camera failed, trying user facing...")
        // Fallback to front camera
        try {
          stream = await navigator.mediaDevices.getUserMedia({
            video: {
              facingMode: "user",
              width: { ideal: 1280, min: 640 },
              height: { ideal: 720, min: 480 },
            },
          })
          console.log("[v0] Camera started with user facing mode")
        } catch (userError) {
          console.log("[v0] User camera failed, trying basic constraints...")
          // Final fallback with minimal constraints
          stream = await navigator.mediaDevices.getUserMedia({
            video: true,
          })
          console.log("[v0] Camera started with basic constraints")
        }
      }

      if (stream && videoRef.current) {
        videoRef.current.srcObject = stream
        streamRef.current = stream

        const video = videoRef.current
        const handleVideoLoad = () => {
          console.log("[v0] Video loaded successfully")
          setShowCamera(true)
          video.removeEventListener("loadedmetadata", handleVideoLoad)
        }

        video.addEventListener("loadedmetadata", handleVideoLoad)

        setTimeout(() => {
          if (!showCamera) {
            console.log("[v0] Video metadata timeout, showing camera anyway")
            setShowCamera(true)
          }
        }, 3000)
      } else {
        throw new Error("Failed to get video stream or video element not available")
      }
    } catch (error) {
      console.error("[v0] Camera access error:", error)
      if (error instanceof Error) {
        if (error.name === "NotAllowedError") {
          setCameraError("카메라 접근이 거부되었습니다. 브라우저 설정에서 카메라 권한을 허용해주세요.")
        } else if (error.name === "NotFoundError") {
          setCameraError("카메라를 찾을 수 없습니다. 카메라가 연결되어 있는지 확인해주세요.")
        } else if (error.name === "NotReadableError") {
          setCameraError("카메라가 다른 앱에서 사용 중입니다. 다른 앱을 종료하고 다시 시도해주세요.")
        } else {
          setCameraError("카메라에 접근할 수 없습니다. 브라우저 설정을 확인해주세요.")
        }
      } else {
        setCameraError("카메라에 접근할 수 없습니다. 브라우저 설정을 확인해주세요.")
      }
    }
  }

  const stopCamera = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((track) => track.stop())
      streamRef.current = null
    }
    setShowCamera(false)
    setCameraError("")
  }

  const captureImage = () => {
    if (videoRef.current && canvasRef.current) {
      const canvas = canvasRef.current
      const video = videoRef.current
      const context = canvas.getContext("2d")

      if (context && video.readyState >= 2) {
        console.log("[v0] Capturing image from video")
        canvas.width = video.videoWidth
        canvas.height = video.videoHeight
        context.drawImage(video, 0, 0)

        // Simulate ID card recognition (in real app, you'd use OCR/barcode scanning)
        setTimeout(() => {
          console.log("[v0] Simulating ID card recognition")
          stopCamera()
          // Mock employee ID detection
          const mockEmployeeId = "1" // In real app, extract from scanned image
          router.push(`/employee-dashboard?userId=${mockEmployeeId}`)
        }, 1000)
      } else {
        console.log("[v0] Video not ready for capture")
        setCameraError("비디오가 준비되지 않았습니다. 잠시 후 다시 시도해주세요.")
      }
    }
  }

  useEffect(() => {
    return () => {
      // Cleanup camera stream on component unmount
      if (streamRef.current) {
        streamRef.current.getTracks().forEach((track) => track.stop())
      }
    }
  }, [])

  const handleEmployeeLogin = () => {
    if (employeeId.trim()) {
      router.push(`/employee-dashboard?userId=${employeeId}`)
    } else {
      alert("사번을 입력해주세요.")
    }
  }

  const handleAdminLogin = () => {
    if (adminEmail.trim() && adminPassword.trim()) {
      router.push("/admin-dashboard")
    } else {
      alert("이메일과 비밀번호를 입력해주세요.")
    }
  }

  return (
    <div className="min-h-screen bg-background flex items-center justify-center">
      <div className="w-full max-w-md mx-auto px-4">
        <div className="text-center mb-8">
          <div className="flex items-center justify-center mb-4">
            <Image
              src="/images/enerxizer-logo.png"
              alt="enerXIzer Logo"
              width={200}
              height={60}
              className="h-12 w-auto"
            />
          </div>
          <p className="text-muted-foreground">건강을 지키는 에너지 충전소</p>
          <Badge variant="secondary" className="bg-accent text-accent-foreground mt-2">
            Beta v1.0
          </Badge>
        </div>

        <Tabs defaultValue="employee" className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="employee" className="flex items-center gap-2">
              <span className="text-sm">👤</span>
              직원 로그인
            </TabsTrigger>
            <TabsTrigger value="admin" className="flex items-center gap-2">
              <span className="text-sm">🛡️</span>
              관리자
            </TabsTrigger>
          </TabsList>

          {/* Employee Login */}
          <TabsContent value="employee">
            <Card>
              <CardHeader className="text-center">
                <CardTitle className="text-card-foreground">직원 인증</CardTitle>
                <CardDescription>사원증을 스캔하거나 사번을 입력하여 로그인하세요</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Badge Scan Option */}
                <div className="text-center">
                  <Button
                    size="lg"
                    className="w-full bg-primary hover:bg-primary/90 text-primary-foreground"
                    onClick={startCamera}
                  >
                    <span className="mr-2">📱</span>
                    사원증 스캔하기
                  </Button>
                  <p className="text-sm text-muted-foreground mt-2">카메라로 사원증 바코드를 스캔하세요</p>
                  {cameraError && <p className="text-sm text-red-500 mt-2">{cameraError}</p>}
                </div>

                <div className="relative">
                  <div className="absolute inset-0 flex items-center">
                    <span className="w-full border-t border-border" />
                  </div>
                  <div className="relative flex justify-center text-xs uppercase">
                    <span className="bg-background px-2 text-muted-foreground">또는</span>
                  </div>
                </div>

                {/* Manual Entry */}
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="employee-id">사번</Label>
                    <Input
                      id="employee-id"
                      placeholder="사번을 입력하세요"
                      className="bg-input"
                      value={employeeId}
                      onChange={(e) => setEmployeeId(e.target.value)}
                      onKeyPress={(e) => e.key === "Enter" && handleEmployeeLogin()}
                    />
                  </div>
                  <Button
                    className="w-full bg-primary hover:bg-primary/90 text-primary-foreground"
                    onClick={handleEmployeeLogin}
                  >
                    로그인
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Admin Login */}
          <TabsContent value="admin">
            <Card>
              <CardHeader className="text-center">
                <CardTitle className="text-card-foreground">관리자 로그인</CardTitle>
                <CardDescription>관리자 계정으로 대시보드에 접근하세요</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="admin-email">이메일</Label>
                  <Input
                    id="admin-email"
                    type="email"
                    placeholder="admin@company.com"
                    className="bg-input"
                    value={adminEmail}
                    onChange={(e) => setAdminEmail(e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="admin-password">비밀번호</Label>
                  <Input
                    id="admin-password"
                    type="password"
                    placeholder="••••••••"
                    className="bg-input"
                    value={adminPassword}
                    onChange={(e) => setAdminPassword(e.target.value)}
                    onKeyPress={(e) => e.key === "Enter" && handleAdminLogin()}
                  />
                </div>
                <Button
                  className="w-full bg-primary hover:bg-primary/90 text-primary-foreground"
                  onClick={handleAdminLogin}
                >
                  관리자 로그인
                </Button>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        <Dialog open={showCamera} onOpenChange={stopCamera}>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>사원증 스캔</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div className="relative bg-black rounded-lg overflow-hidden">
                <video ref={videoRef} autoPlay playsInline className="w-full h-64 object-cover" />
                <div className="absolute inset-0 border-2 border-white/50 m-8 rounded-lg">
                  <div className="absolute top-0 left-0 w-6 h-6 border-t-2 border-l-2 border-white"></div>
                  <div className="absolute top-0 right-0 w-6 h-6 border-t-2 border-r-2 border-white"></div>
                  <div className="absolute bottom-0 left-0 w-6 h-6 border-b-2 border-l-2 border-white"></div>
                  <div className="absolute bottom-0 right-0 w-6 h-6 border-b-2 border-r-2 border-white"></div>
                </div>
                <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 text-white text-sm bg-black/50 px-3 py-1 rounded">
                  사원증을 프레임 안에 맞춰주세요
                </div>
              </div>
              <canvas ref={canvasRef} className="hidden" />
              <div className="flex gap-2">
                <Button onClick={captureImage} className="flex-1">
                  <span className="mr-2">📸</span>
                  스캔하기
                </Button>
                <Button variant="outline" onClick={stopCamera} className="flex-1 bg-transparent">
                  취소
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  )
}
