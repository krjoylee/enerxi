# 데이터 테이블 설계 문서

## 개요
enerXIzer 기업 웰니스 시스템에서 관리하는 모든 데이터 테이블의 구조와 스키마를 정리한 문서입니다.

## 데이터 저장 방식
- **클라이언트 측**: localStorage를 통한 브라우저 로컬 저장
- **서버 측**: JSON 파일 기반 저장 및 SQL 데이터베이스 지원
- **하이브리드**: localStorage 우선, 서버 백업 방식

---

## 1. 사용자(Users) 테이블

### 기본 구조
\`\`\`json
{
  "id": "string",
  "name": "string", 
  "employeeId": "string",
  "team": "string",
  "position": "string",
  "email": "string",
  "phone": "string",
  "status": "활성|비활성",
  "createdAt": "ISO 8601 timestamp",
  "updatedAt": "ISO 8601 timestamp"
}
\`\`\`

### 건강 정보 확장
\`\`\`json
{
  "height": "number (cm)",
  "weight": "number (kg)", 
  "age": "number",
  "gender": "male|female|other",
  "birthYear": "number",
  "activityLevel": "정적|보통|활발",
  "bloodPressure": {
    "systolic": "number",
    "diastolic": "number"
  },
  "bloodSugar": {
    "value": "number",
    "unit": "mg/dL"
  },
  "diabetes": "boolean",
  "hypertension": "boolean", 
  "allergies": "string[]",
  "bmi": "number (계산값)"
}
\`\`\`

### 저장 위치
- **localStorage**: `user_data_{id}` 키로 개별 저장
- **서버**: `/data/users.json` 파일
- **API**: `/api/users` 엔드포인트

---

## 2. 제품(Products) 테이블

### 기본 구조
\`\`\`json
{
  "id": "string",
  "name": "string",
  "category": "string",
  "barcode": "string",
  "brand": "string",
  "description": "string",
  "image": "string (URL)",
  "status": "활성|비활성"
}
\`\`\`

### 영양 정보
\`\`\`json
{
  "nutrition": {
    "calories": "number (kcal/100g)",
    "protein": "number (g/100g)",
    "fat": "number (g/100g)",
    "carbohydrates": "number (g/100g)",
    "sugar": "number (g/100g)",
    "sodium": "number (mg/100g)",
    "fiber": "number (g/100g)"
  },
  "servingSize": {
    "amount": "number",
    "unit": "string"
  },
  "allergens": "string[]",
  "healthRating": "A|B|C|D|E"
}
\`\`\`

### 저장 위치
- **서버**: `/data/products.json` 파일
- **API**: `/api/products` 엔드포인트

---

## 3. 재고(Inventory) 테이블

### 기본 구조
\`\`\`json
{
  "id": "string",
  "productId": "string (FK)",
  "location": "string",
  "floor": "number",
  "section": "string",
  "currentStock": "number",
  "minThreshold": "number",
  "maxThreshold": "number",
  "reorderPoint": "number",
  "lastUpdated": "ISO 8601 timestamp"
}
\`\`\`

### 비용 및 공급업체 정보
\`\`\`json
{
  "supplier": {
    "name": "string",
    "contact": "string",
    "email": "string"
  },
  "pricing": {
    "unitCost": "number",
    "currency": "KRW",
    "lastPriceUpdate": "ISO 8601 timestamp"
  },
  "expiryDate": "ISO 8601 date",
  "batchNumber": "string"
}
\`\`\`

### 저장 위치
- **서버**: `/data/inventory.json` 파일
- **API**: `/api/inventory` 엔드포인트

---

## 4. 주문(Orders) 테이블

### 기본 구조
\`\`\`json
{
  "id": "string",
  "orderNumber": "string",
  "supplierId": "string",
  "orderDate": "ISO 8601 timestamp",
  "expectedDelivery": "ISO 8601 date",
  "actualDelivery": "ISO 8601 date",
  "status": "대기|처리중|배송중|완료|취소",
  "totalAmount": "number",
  "currency": "KRW"
}
\`\`\`

### 주문 상세 항목
\`\`\`json
{
  "items": [
    {
      "productId": "string",
      "productName": "string",
      "quantity": "number",
      "unitPrice": "number",
      "totalPrice": "number"
    }
  ],
  "notes": "string",
  "createdBy": "string (사용자 ID)",
  "approvedBy": "string (관리자 ID)"
}
\`\`\`

### 저장 위치
- **서버**: `/data/orders.json` 파일
- **API**: `/api/orders` 엔드포인트

---

## 5. SQL 데이터베이스 스키마

### 사용자 테이블 (SQL)
\`\`\`sql
CREATE TABLE users (
    id VARCHAR(50) PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    employee_id VARCHAR(50) UNIQUE,
    team VARCHAR(100),
    position VARCHAR(100),
    email VARCHAR(255),
    phone VARCHAR(20),
    height DECIMAL(5,2),
    weight DECIMAL(5,2),
    age INT,
    gender ENUM('male', 'female', 'other'),
    birth_year INT,
    activity_level ENUM('정적', '보통', '활발'),
    systolic_bp INT,
    diastolic_bp INT,
    blood_sugar DECIMAL(5,2),
    diabetes BOOLEAN DEFAULT FALSE,
    hypertension BOOLEAN DEFAULT FALSE,
    allergies JSON,
    bmi DECIMAL(4,2) GENERATED ALWAYS AS (weight / ((height/100) * (height/100))),
    status ENUM('활성', '비활성') DEFAULT '활성',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);
\`\`\`

### 제품 테이블 (SQL)
\`\`\`sql
CREATE TABLE products (
    id VARCHAR(50) PRIMARY KEY,
    name VARCHAR(200) NOT NULL,
    category VARCHAR(100),
    barcode VARCHAR(50) UNIQUE,
    brand VARCHAR(100),
    description TEXT,
    image_url VARCHAR(500),
    calories DECIMAL(6,2),
    protein DECIMAL(5,2),
    fat DECIMAL(5,2),
    carbohydrates DECIMAL(5,2),
    sugar DECIMAL(5,2),
    sodium DECIMAL(7,2),
    fiber DECIMAL(5,2),
    serving_amount DECIMAL(6,2),
    serving_unit VARCHAR(20),
    allergens JSON,
    health_rating ENUM('A', 'B', 'C', 'D', 'E'),
    status ENUM('활성', '비활성') DEFAULT '활성',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);
\`\`\`

### 재고 테이블 (SQL)
\`\`\`sql
CREATE TABLE inventory (
    id VARCHAR(50) PRIMARY KEY,
    product_id VARCHAR(50),
    location VARCHAR(100),
    floor INT,
    section VARCHAR(50),
    current_stock INT NOT NULL DEFAULT 0,
    min_threshold INT DEFAULT 10,
    max_threshold INT DEFAULT 100,
    reorder_point INT DEFAULT 20,
    supplier_name VARCHAR(200),
    supplier_contact VARCHAR(100),
    supplier_email VARCHAR(255),
    unit_cost DECIMAL(10,2),
    expiry_date DATE,
    batch_number VARCHAR(100),
    last_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (product_id) REFERENCES products(id)
);
\`\`\`

---

## 6. localStorage 저장 구조

### 키 명명 규칙
- `user_data_{userId}`: 개별 사용자 데이터
- `admin_settings`: 관리자 설정
- `app_config`: 애플리케이션 설정

### 데이터 형식
\`\`\`json
{
  "data": "실제 데이터 객체",
  "timestamp": "저장 시간",
  "version": "데이터 버전",
  "source": "데이터 출처 (local|server)"
}
\`\`\`

---

## 7. API 엔드포인트 매핑

| 테이블 | GET | POST | PUT | DELETE |
|--------|-----|------|-----|--------|
| Users | `/api/users` | `/api/users` | `/api/users` | `/api/users/{id}` |
| Products | `/api/products` | `/api/products` | `/api/products/{id}` | `/api/products/{id}` |
| Inventory | `/api/inventory` | `/api/inventory` | `/api/inventory/{id}` | `/api/inventory/{id}` |
| Orders | `/api/orders` | `/api/orders` | `/api/orders/{id}` | `/api/orders/{id}` |

---

## 8. 데이터 관계도

\`\`\`
Users (1) ←→ (N) Orders
Products (1) ←→ (1) Inventory  
Orders (1) ←→ (N) OrderItems ←→ (1) Products
Users (1) ←→ (N) ConsumptionLogs ←→ (1) Products
\`\`\`

---

## 9. 백업 및 복구

### CSV 내보내기 형식
- **사용자**: `id,name,employeeId,team,position,email,phone,status`
- **제품**: `id,name,category,brand,calories,protein,fat,carbohydrates`
- **재고**: `productId,location,currentStock,minThreshold,maxThreshold`

### 데이터 마이그레이션
1. localStorage → 서버: 주기적 동기화
2. JSON → SQL: 스크립트 기반 마이그레이션
3. CSV → 시스템: 일괄 업로드 지원

---

## 10. 보안 및 접근 제어

### 데이터 접근 권한
- **관리자**: 모든 테이블 읽기/쓰기
- **직원**: 개인 데이터만 읽기/쓰기
- **게스트**: 제품 정보만 읽기

### 데이터 검증
- 입력 데이터 타입 검증
- 필수 필드 검증
- 비즈니스 로직 검증 (예: BMI 계산)

---

*마지막 업데이트: 2024년 12월*
