-- Create user_list table for employee health information
CREATE TABLE IF NOT EXISTS user_list (
    seq INTEGER PRIMARY KEY AUTOINCREMENT,
    id TEXT NOT NULL UNIQUE,
    name TEXT NOT NULL,
    height INTEGER NOT NULL,
    weight INTEGER NOT NULL,
    diabetes TEXT NOT NULL CHECK (diabetes IN ('O', 'X')),
    hypertension TEXT NOT NULL CHECK (hypertension IN ('O', 'X'))
);

-- Create index on id for faster lookups
CREATE INDEX IF NOT EXISTS idx_user_list_id ON user_list(id);
