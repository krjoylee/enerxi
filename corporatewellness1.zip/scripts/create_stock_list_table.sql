-- Create stock_list table for inventory management
CREATE TABLE IF NOT EXISTS stock_list (
    seq SERIAL PRIMARY KEY,
    item_name VARCHAR(255) NOT NULL,
    quantity INTEGER NOT NULL DEFAULT 0,
    barcode VARCHAR(50) UNIQUE NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Insert sample data
INSERT INTO stock_list (item_name, quantity, barcode) VALUES
('허니버터칩', 45, '8801019606267'),
('초코파이', 32, '8801117100100'),
('바나나킥', 28, '8801019607011'),
('새우깡', 38, '8801019600012'),
('오징어땅콩', 22, '8801019601200'),
('포카칩', 35, '8801019602300'),
('치토스', 18, '8801019603400'),
('프링글스', 25, '8801019604500'),
('콘칩', 40, '8801019605600'),
('감자칩', 30, '8801019606700');

-- Create index for faster barcode lookups
CREATE INDEX IF NOT EXISTS idx_stock_barcode ON stock_list(barcode);
