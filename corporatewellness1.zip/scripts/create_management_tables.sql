-- 사용자 관리 테이블
CREATE TABLE IF NOT EXISTS users (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    employee_id VARCHAR(50) UNIQUE NOT NULL,
    department VARCHAR(100),
    position VARCHAR(100),
    email VARCHAR(255),
    phone VARCHAR(20),
    birth_date DATE,
    gender VARCHAR(10),
    height DECIMAL(5,2),
    weight DECIMAL(5,2),
    bmi DECIMAL(4,2) GENERATED ALWAYS AS (
        CASE 
            WHEN height > 0 THEN ROUND((weight / POWER(height/100, 2))::numeric, 2)
            ELSE NULL
        END
    ) STORED,
    diabetes BOOLEAN DEFAULT FALSE,
    hypertension BOOLEAN DEFAULT FALSE,
    allergies TEXT,
    dietary_restrictions TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 품목 관리 테이블
CREATE TABLE IF NOT EXISTS products (
    id SERIAL PRIMARY KEY,
    name VARCHAR(200) NOT NULL,
    category VARCHAR(100),
    brand VARCHAR(100),
    barcode VARCHAR(50) UNIQUE,
    price DECIMAL(10,2),
    calories_per_100g INTEGER,
    protein_per_100g DECIMAL(5,2),
    fat_per_100g DECIMAL(5,2),
    carbs_per_100g DECIMAL(5,2),
    sodium_per_100g DECIMAL(7,2),
    sugar_per_100g DECIMAL(5,2),
    serving_size DECIMAL(6,2),
    calories_per_serving INTEGER GENERATED ALWAYS AS (
        CASE 
            WHEN serving_size > 0 AND calories_per_100g > 0 
            THEN ROUND((calories_per_100g * serving_size / 100)::numeric)
            ELSE NULL
        END
    ) STORED,
    protein_percentage DECIMAL(5,2) GENERATED ALWAYS AS (
        CASE 
            WHEN calories_per_100g > 0 AND protein_per_100g > 0
            THEN ROUND(((protein_per_100g * 4 * 100) / calories_per_100g)::numeric, 2)
            ELSE NULL
        END
    ) STORED,
    fat_percentage DECIMAL(5,2) GENERATED ALWAYS AS (
        CASE 
            WHEN calories_per_100g > 0 AND fat_per_100g > 0
            THEN ROUND(((fat_per_100g * 9 * 100) / calories_per_100g)::numeric, 2)
            ELSE NULL
        END
    ) STORED,
    carbs_percentage DECIMAL(5,2) GENERATED ALWAYS AS (
        CASE 
            WHEN calories_per_100g > 0 AND carbs_per_100g > 0
            THEN ROUND(((carbs_per_100g * 4 * 100) / calories_per_100g)::numeric, 2)
            ELSE NULL
        END
    ) STORED,
    health_rating VARCHAR(20),
    allergens TEXT,
    ingredients TEXT,
    image_url VARCHAR(500),
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 재고/주문 관리 테이블
CREATE TABLE IF NOT EXISTS inventory (
    id SERIAL PRIMARY KEY,
    product_id INTEGER REFERENCES products(id),
    current_stock INTEGER DEFAULT 0,
    minimum_stock INTEGER DEFAULT 10,
    maximum_stock INTEGER DEFAULT 100,
    reorder_point INTEGER DEFAULT 20,
    last_restock_date DATE,
    last_restock_quantity INTEGER,
    total_consumed INTEGER DEFAULT 0,
    location VARCHAR(100),
    expiry_date DATE,
    supplier VARCHAR(200),
    cost_per_unit DECIMAL(10,2),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 주문 로그 테이블
CREATE TABLE IF NOT EXISTS order_logs (
    id SERIAL PRIMARY KEY,
    product_id INTEGER REFERENCES products(id),
    order_type VARCHAR(50), -- 'manual', 'automatic', 'emergency'
    quantity_ordered INTEGER,
    order_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    expected_delivery DATE,
    actual_delivery DATE,
    status VARCHAR(50) DEFAULT 'pending', -- 'pending', 'confirmed', 'delivered', 'cancelled'
    supplier VARCHAR(200),
    total_cost DECIMAL(12,2),
    notes TEXT,
    ordered_by VARCHAR(100)
);

-- 소비 로그 테이블
CREATE TABLE IF NOT EXISTS consumption_logs (
    id SERIAL PRIMARY KEY,
    product_id INTEGER REFERENCES products(id),
    user_id INTEGER REFERENCES users(id),
    quantity_consumed INTEGER DEFAULT 1,
    consumption_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    calories_consumed INTEGER,
    method VARCHAR(50) -- 'scan', 'manual', 'vending'
);
