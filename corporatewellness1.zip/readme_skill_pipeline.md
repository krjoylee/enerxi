# enerXIzer 기업 웰니스 시스템 - 기술 구현 및 데이터 파이프라인

## 🏗️ 시스템 아키텍처

### Frontend Architecture
- **Framework**: Next.js 15 (App Router)
- **UI Library**: React 18 with TypeScript
- **Styling**: Tailwind CSS v4 with Glassmorphism Design System
- **Component Library**: shadcn/ui + Custom Components
- **State Management**: React Hooks + SWR for data fetching + localStorage persistence
- **Design Pattern**: Apple-inspired Glassmorphism with responsive design

### Backend Architecture
- **Runtime**: Next.js API Routes (Server-side)
- **Data Storage**: Hybrid localStorage + File-based JSON storage system
- **Authentication**: Simple credential-based admin auth
- **API Integration**: MISO API for AI chatbot functionality

## 📊 데이터 파이프라인

### 1. 하이브리드 데이터 저장 계층
\`\`\`
Client-side (localStorage)
├── user_data_1         # 사용자 1 개인 건강 정보
├── user_data_2         # 사용자 2 개인 건강 정보
├── user_data_3         # 사용자 3 개인 건강 정보
└── user_data_[n]       # 동적 추가 사용자 데이터

Server-side (/data)
├── users.json          # 기본 사용자 프로필 정보
├── products.json       # 제품 정보 및 영양성분
├── inventory.json      # 재고 관리 및 주문 내역
└── orders.json         # 발주 및 배송 추적
\`\`\`

### 2. 데이터 흐름 아키텍처
\`\`\`
사용자 입력 → localStorage 우선 저장 → API Route → 서버 동기화 → 응답
                ↓
        영구 데이터 지속성 보장
\`\`\`

### 3. 실시간 데이터 처리
- **자동 계산 엔진**: BMI, 칼로리, 영양성분 비율 실시간 계산
- **재고 모니터링**: 실시간 재고 수준 추적 및 알림 시스템
- **예산 시뮬레이션**: 동적 예산 계산 및 그래프 업데이트
- **데이터 동기화**: localStorage ↔ 서버 간 양방향 동기화

## 🔧 핵심 기술 스택

### Frontend Technologies
- **React Components**: 함수형 컴포넌트 + Hooks 패턴
- **TypeScript**: 강타입 시스템으로 런타임 오류 방지
- **Tailwind CSS**: Utility-first CSS 프레임워크
- **Chart.js/Recharts**: 데이터 시각화 라이브러리
- **SWR**: 데이터 페칭 및 캐싱 최적화
- **localStorage API**: 클라이언트 사이드 영구 데이터 저장

### Backend Technologies
- **Next.js API Routes**: RESTful API 엔드포인트
- **File System API**: Node.js fs 모듈 기반 데이터 저장
- **CSV Processing**: 파일 업로드/다운로드 및 데이터 변환
- **MISO API Integration**: 외부 AI 서비스 연동

### Data Processing Pipeline
- **입력 검증**: Zod 스키마 기반 데이터 유효성 검사
- **자동 계산**: 영양성분, BMI, 예산 집행률 실시간 계산
- **데이터 변환**: CSV ↔ JSON 양방향 변환
- **파일 관리**: 이미지 업로드 및 정적 파일 서빙
- **Korean IME 처리**: 한글 입력 최적화 및 composition 이벤트 핸들링

## 🔄 API 설계 패턴

### RESTful API Structure
\`\`\`
GET    /api/users          # 사용자 목록 조회 (localStorage + 서버 병합)
POST   /api/users          # 새 사용자 등록
PUT    /api/users          # 사용자 정보 수정 (ID 기반)
DELETE /api/users/[id]     # 사용자 삭제

GET    /api/products       # 제품 목록 조회
POST   /api/products       # 새 제품 등록
PUT    /api/products/[id]  # 제품 정보 수정

GET    /api/inventory      # 재고 현황 조회
POST   /api/inventory      # 재고 업데이트
PUT    /api/inventory/[id] # 재고 수정

POST   /api/csv            # CSV 데이터 처리
GET    /api/csv?type=users # CSV 데이터 내보내기

POST   /api/chat           # MISO AI 챗봇 통신
\`\`\`

### localStorage Integration Pattern
\`\`\`typescript
// 하이브리드 데이터 로딩
const loadUserData = async (userId: string) => {
  // 1. localStorage에서 우선 조회
  const storedData = getUserDataFromStorage(userId);
  if (storedData) {
    setCurrentUser(storedData);
    return storedData;
  }
  
  // 2. 서버 API 호출
  const serverData = await fetch(`/api/users?userId=${userId}`);
  return serverData;
};

// 데이터 저장 (이중 저장)
const saveUserData = async (userData: UserData) => {
  // 1. localStorage에 즉시 저장
  saveUserDataToStorage(userData.id, userData);
  
  // 2. 서버에 백그라운드 동기화
  try {
    await fetch('/api/users', {
      method: 'PUT',
      body: JSON.stringify(userData)
    });
  } catch (error) {
    console.log('Server sync failed, localStorage data preserved');
  }
};
\`\`\`

## 📈 데이터 시각화 파이프라인

### Chart Rendering System
- **Line Charts**: 사용량 트렌드 및 시계열 데이터
- **Donut Charts**: 재고 충족률 및 비율 데이터
- **Bar Charts**: 제품별 소비량 및 예산 분석
- **Stacked Charts**: 누적 예산 분석 및 카테고리별 분류

### Real-time Updates
\`\`\`typescript
// 실시간 데이터 업데이트 패턴
const { data, mutate } = useSWR('/api/inventory', fetcher);

const updateInventory = async (newData) => {
  await mutate(updateInventoryAPI(newData), false);
  // 낙관적 업데이트로 즉시 UI 반영
};
\`\`\`

## 🤖 AI 통합 시스템

### MISO API Integration
- **Streaming Response**: 실시간 AI 응답 스트리밍
- **Health Knowledge Base**: 건강 관련 규칙 기반 응답 시스템
- **Fallback System**: API 실패 시 로컬 응답 제공

### Chatbot Architecture
\`\`\`typescript
// 하이브리드 응답 시스템
const generateResponse = async (message: string) => {
  // 1. 건강 키워드 검사
  const healthResponse = checkHealthKeywords(message);
  if (healthResponse) return healthResponse;
  
  // 2. MISO API 호출
  try {
    return await callMISOAPI(message);
  } catch (error) {
    // 3. 기본 응답 제공
    return getDefaultResponse();
  }
};
\`\`\`

## 🔐 보안 및 데이터 관리

### Hybrid Storage Security
- **클라이언트 사이드**: localStorage 기반 개인 데이터 보호
- **서버 사이드**: 파일 기반 시스템 데이터 관리
- **데이터 격리**: 사용자별 독립적 데이터 저장
- **백업 시스템**: JSON + localStorage 이중 백업

### Admin Authentication
\`\`\`typescript
// 환경변수 기반 인증
const adminAuth = {
  username: process.env.ADMIN_USERNAME || 'admin',
  password: process.env.ADMIN_PASSWORD || 'admin123'
};
\`\`\`

## 🌐 국제화 및 입력 처리

### Korean IME Support
\`\`\`typescript
// 한글 입력 최적화
const [isComposing, setIsComposing] = useState(false);

const handleCompositionStart = () => setIsComposing(true);
const handleCompositionEnd = (e: React.CompositionEvent) => {
  setIsComposing(false);
  setValue(e.currentTarget.value);
};

const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
  if (!isComposing) {
    setValue(e.target.value);
  }
};
\`\`\`

### Input Optimization
- **Focus Management**: 입력 중 포커스 유지
- **Composition Events**: 한글 조합 상태 추적
- **Real-time Validation**: 입력과 동시에 유효성 검사

## 📱 반응형 디자인 시스템

### Glassmorphism Implementation
\`\`\`css
/* 글래스모피즘 카드 스타일 */
.glass-card {
  background: rgba(255, 255, 255, 0.1);
  backdrop-filter: blur(10px);
  border: 1px solid rgba(255, 255, 255, 0.2);
  border-radius: 16px;
  box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
}
\`\`\`

### Responsive Grid System
- **Mobile First**: 모바일 우선 반응형 디자인
- **Breakpoint System**: sm, md, lg, xl 브레이크포인트
- **Flexible Layouts**: CSS Grid + Flexbox 하이브리드

## 🚀 성능 최적화

### Frontend Optimization
- **Code Splitting**: Next.js 자동 코드 분할
- **Image Optimization**: Next.js Image 컴포넌트
- **SWR Caching**: 클라이언트 사이드 캐싱
- **Lazy Loading**: 컴포넌트 지연 로딩
- **localStorage Caching**: 오프라인 데이터 접근

### Backend Optimization
- **File I/O Optimization**: 비동기 파일 읽기/쓰기
- **Memory Management**: 대용량 CSV 스트리밍 처리
- **Error Recovery**: 견고한 에러 핸들링 시스템
- **Hybrid Storage**: localStorage + 서버 이중화

## 📋 개발 워크플로우

### Development Pipeline
1. **설계**: 사용자 요구사항 → 기능 명세
2. **구현**: 컴포넌트 단위 개발 → API 연동 → localStorage 통합
3. **테스트**: 기능 검증 → 사용자 시나리오 테스트 → 데이터 지속성 검증
4. **배포**: Vercel 플랫폼 자동 배포

### Code Quality
- **TypeScript**: 컴파일 타임 타입 검사
- **ESLint**: 코드 품질 및 일관성 유지
- **Prettier**: 코드 포맷팅 자동화

## 🔮 확장 가능성

### Scalability Considerations
- **Database Migration**: localStorage → IndexedDB → 외부 DB 마이그레이션 경로
- **API Versioning**: RESTful API 버전 관리 체계
- **Microservices**: 기능별 서비스 분리 가능성
- **Cloud Integration**: AWS/GCP 클라우드 서비스 연동
- **Multi-language Support**: 국제화 확장 준비

### Data Migration Strategy
\`\`\`typescript
// localStorage → Database 마이그레이션 준비
const migrateLocalStorageToDatabase = async () => {
  const localUsers = getAllUsersFromStorage();
  for (const user of localUsers) {
    await createUserInDatabase(user);
  }
  // localStorage 백업 유지
};
\`\`\`

---

**개발 환경**: Next.js 15 + TypeScript + Tailwind CSS  
**배포 플랫폼**: Vercel  
**개발 방식**: 바이브 코딩 (Vibe Coding)  
**아키텍처**: JAMstack + Hybrid Storage (localStorage + File-based)  
**특별 기능**: Korean IME 최적화, 데이터 영구 지속성, CSV 일괄 관리
