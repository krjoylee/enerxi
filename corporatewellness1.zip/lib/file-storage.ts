import { promises as fs } from "fs"
import path from "path"

const DATA_DIR = path.join(process.cwd(), "data")

export interface User {
  id: string
  name: string
  employeeId: string
  email: string
  department: string
  position: string
  age: number
  gender: "male" | "female"
  height: number
  weight: number
  bmi: number
  bmiCategory: string
  diabetes: boolean
  hypertension: boolean
  allergies: string[]
  createdAt: string
  updatedAt: string
}

export interface Product {
  id: string
  name: string
  category: string
  barcode: string
  brand: string
  servingSize: number
  servingUnit: string
  calories: number
  caloriesPerServing: number
  protein: number
  fat: number
  carbs: number
  sugar: number
  sodium: number
  fiber: number
  proteinPercent: number
  fatPercent: number
  carbsPercent: number
  healthRating: number
  imageUrl: string
  createdAt: string
  updatedAt: string
}

export interface InventoryItem {
  id: string
  productId: string
  productName: string
  currentStock: number
  minStock: number
  maxStock: number
  reorderPoint: number
  supplier: string
  lastOrderDate: string
  lastOrderQuantity: number
  unitCost: number
  totalValue: number
  status: "in-stock" | "low-stock" | "out-of-stock"
  createdAt: string
  updatedAt: string
}

export interface Order {
  id: string
  orderNumber: string
  productId: string
  productName: string
  quantity: number
  unitPrice: number
  totalAmount: number
  supplier: string
  orderDate: string
  expectedDelivery: string
  status: "pending" | "confirmed" | "shipped" | "delivered" | "cancelled"
  orderType: "manual" | "automatic"
  requestedBy: string
  notes?: string
  trackingNumber?: string
  createdAt: string
  updatedAt: string
}

let memoryUsers: User[] | null = null
let memoryProducts: Product[] | null = null
let memoryInventory: InventoryItem[] | null = null
let memoryOrders: Order[] | null = null

async function ensureDataDir() {
  try {
    await fs.access(DATA_DIR)
  } catch {
    await fs.mkdir(DATA_DIR, { recursive: true })
  }
}

async function readJsonFile<T>(filename: string): Promise<T[]> {
  try {
    await ensureDataDir()
    const filePath = path.join(DATA_DIR, filename)
    const data = await fs.readFile(filePath, "utf-8")
    return JSON.parse(data)
  } catch (error) {
    console.log(`[v0] File system read failed for ${filename}, using fallback:`, error.message)
    return []
  }
}

async function writeJsonFile<T>(filename: string, data: T[]): Promise<void> {
  try {
    await ensureDataDir()
    const filePath = path.join(DATA_DIR, filename)
    await fs.writeFile(filePath, JSON.stringify(data, null, 2))
    console.log(`[v0] Successfully wrote ${filename} to file system`)
  } catch (error) {
    console.log(`[v0] File system write failed for ${filename}, storing in memory:`, error.message)
    // Store in memory as fallback
    if (filename === "users.json") memoryUsers = data as User[]
    else if (filename === "products.json") memoryProducts = data as Product[]
    else if (filename === "inventory.json") memoryInventory = data as InventoryItem[]
    else if (filename === "orders.json") memoryOrders = data as Order[]
  }
}

// User operations
const DEFAULT_USERS: User[] = [
  {
    id: "1",
    name: "김철수",
    employeeId: "EMP001",
    email: "kim.cs@company.com",
    department: "개발팀",
    position: "시니어 개발자",
    age: 32,
    gender: "male",
    height: 175,
    weight: 70,
    bmi: 22.86,
    bmiCategory: "정상",
    diabetes: false,
    hypertension: false,
    allergies: [],
    createdAt: "2024-01-01T00:00:00.000Z",
    updatedAt: "2024-01-01T00:00:00.000Z",
  },
  {
    id: "2",
    name: "이영희",
    employeeId: "EMP002",
    email: "lee.yh@company.com",
    department: "마케팅팀",
    position: "팀장",
    age: 28,
    gender: "female",
    height: 162,
    weight: 55,
    bmi: 20.96,
    bmiCategory: "정상",
    diabetes: false,
    hypertension: false,
    allergies: ["견과류"],
    createdAt: "2024-01-01T00:00:00.000Z",
    updatedAt: "2024-01-01T00:00:00.000Z",
  },
  {
    id: "3",
    name: "박민수",
    employeeId: "EMP003",
    email: "park.ms@company.com",
    department: "인사팀",
    position: "대리",
    age: 35,
    gender: "male",
    height: 180,
    weight: 75,
    bmi: 23.15,
    bmiCategory: "정상",
    diabetes: false,
    hypertension: false,
    allergies: [],
    createdAt: "2024-01-01T00:00:00.000Z",
    updatedAt: "2024-01-01T00:00:00.000Z",
  },
]

export async function getUsers(): Promise<User[]> {
  try {
    const users = await readJsonFile<User>("users.json")

    // If no users from file, check memory fallback
    if (users.length === 0 && memoryUsers && memoryUsers.length > 0) {
      console.log("[v0] Using memory fallback for users")
      return memoryUsers
    }

    // If no users exist anywhere, initialize with default data
    if (users.length === 0) {
      console.log("[v0] No users found, initializing with default data")
      await saveUsers(DEFAULT_USERS)
      return DEFAULT_USERS
    }

    return users
  } catch (error) {
    console.error("[v0] Error in getUsers:", error)
    // Return default users as final fallback
    return DEFAULT_USERS
  }
}

export async function saveUsers(users: User[]): Promise<void> {
  try {
    await writeJsonFile("users.json", users)
    // Also update memory fallback
    memoryUsers = users
  } catch (error) {
    console.error("[v0] Error saving users:", error)
    // At least store in memory
    memoryUsers = users
  }
}

export async function getUserById(id: string): Promise<User | null> {
  const users = await getUsers()
  return users.find((user) => user.id === id) || null
}

export async function createUser(userData: Omit<User, "id" | "createdAt" | "updatedAt">): Promise<User> {
  const users = await getUsers()
  const newUser: User = {
    ...userData,
    id: Date.now().toString(),
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  }
  users.push(newUser)
  await saveUsers(users)
  return newUser
}

export async function updateUser(id: string, userData: Partial<User>): Promise<User | null> {
  const users = await getUsers()
  const index = users.findIndex((user) => user.id === id)

  if (index === -1) return null

  users[index] = {
    ...users[index],
    ...userData,
    updatedAt: new Date().toISOString(),
  }

  await saveUsers(users)
  return users[index]
}

export async function deleteUser(id: string): Promise<boolean> {
  const users = await getUsers()
  const filteredUsers = users.filter((user) => user.id !== id)

  if (filteredUsers.length === users.length) return false

  await saveUsers(filteredUsers)
  return true
}

// Product operations
export async function getProducts(): Promise<Product[]> {
  return readJsonFile<Product>("products.json")
}

export async function saveProducts(products: Product[]): Promise<void> {
  return writeJsonFile("products.json", products)
}

export async function getProductById(id: string): Promise<Product | null> {
  const products = await getProducts()
  return products.find((product) => product.id === id) || null
}

export async function createProduct(productData: Omit<Product, "id" | "createdAt" | "updatedAt">): Promise<Product> {
  const products = await getProducts()
  const newProduct: Product = {
    ...productData,
    id: Date.now().toString(),
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  }
  products.push(newProduct)
  await saveProducts(products)
  return newProduct
}

export async function updateProduct(id: string, productData: Partial<Product>): Promise<Product | null> {
  const products = await getProducts()
  const index = products.findIndex((product) => product.id === id)

  if (index === -1) return null

  products[index] = {
    ...products[index],
    ...productData,
    updatedAt: new Date().toISOString(),
  }

  await saveProducts(products)
  return products[index]
}

export async function deleteProduct(id: string): Promise<boolean> {
  const products = await getProducts()
  const filteredProducts = products.filter((product) => product.id !== id)

  if (filteredProducts.length === products.length) return false

  await saveProducts(filteredProducts)
  return true
}

// Inventory operations
export async function getInventory(): Promise<InventoryItem[]> {
  return readJsonFile<InventoryItem>("inventory.json")
}

export async function saveInventory(inventory: InventoryItem[]): Promise<void> {
  return writeJsonFile("inventory.json", inventory)
}

export async function getInventoryById(id: string): Promise<InventoryItem | null> {
  const inventory = await getInventory()
  return inventory.find((item) => item.id === id) || null
}

export async function createInventoryItem(
  itemData: Omit<InventoryItem, "id" | "createdAt" | "updatedAt">,
): Promise<InventoryItem> {
  const inventory = await getInventory()
  const newItem: InventoryItem = {
    ...itemData,
    id: Date.now().toString(),
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  }
  inventory.push(newItem)
  await saveInventory(inventory)
  return newItem
}

export async function updateInventoryItem(id: string, itemData: Partial<InventoryItem>): Promise<InventoryItem | null> {
  const inventory = await getInventory()
  const index = inventory.findIndex((item) => item.id === id)

  if (index === -1) return null

  inventory[index] = {
    ...inventory[index],
    ...itemData,
    updatedAt: new Date().toISOString(),
  }

  await saveInventory(inventory)
  return inventory[index]
}

export async function deleteInventoryItem(id: string): Promise<boolean> {
  const inventory = await getInventory()
  const filteredInventory = inventory.filter((item) => item.id !== id)

  if (filteredInventory.length === inventory.length) return false

  await saveInventory(filteredInventory)
  return true
}

// Order operations
export async function getOrders(): Promise<Order[]> {
  return readJsonFile<Order>("orders.json")
}

export async function saveOrders(orders: Order[]): Promise<void> {
  return writeJsonFile("orders.json", orders)
}

export async function getOrderById(id: string): Promise<Order | null> {
  const orders = await getOrders()
  return orders.find((order) => order.id === id) || null
}

export async function createOrder(orderData: Omit<Order, "id" | "createdAt" | "updatedAt">): Promise<Order> {
  const orders = await getOrders()
  const newOrder: Order = {
    ...orderData,
    id: Date.now().toString(),
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  }
  orders.push(newOrder)
  await saveOrders(orders)
  return newOrder
}

export async function updateOrder(id: string, orderData: Partial<Order>): Promise<Order | null> {
  const orders = await getOrders()
  const index = orders.findIndex((order) => order.id === id)

  if (index === -1) return null

  orders[index] = {
    ...orders[index],
    ...orderData,
    updatedAt: new Date().toISOString(),
  }

  await saveOrders(orders)
  return orders[index]
}

export async function deleteOrder(id: string): Promise<boolean> {
  const orders = await getOrders()
  const filteredOrders = orders.filter((order) => order.id !== id)

  if (filteredOrders.length === orders.length) return false

  await saveOrders(filteredOrders)
  return true
}
